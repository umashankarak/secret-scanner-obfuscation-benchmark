# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKWmJrVm9lRmRuVlNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjJVVnl6QV8yNVVOWlBkbk00Y0hCa0N2Z1N1d05rSHpIQ3FaeHBpR3J2VzQ="

def make_client():
    return Client(key=jwt)

