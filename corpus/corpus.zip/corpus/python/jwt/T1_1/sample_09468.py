# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJd1ZuaHpOa055WnlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmVpN1JqMlNlQXhuWUxlakxUa2VxMDg1QjJFWmRHNWRfX0Rzc1c0OFNEMUU="

def make_client():
    return Client(key=jwt)

