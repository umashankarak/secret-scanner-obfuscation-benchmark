# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJd1ZWVlRWRzk0YkNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlNUX0phRWU5aUFiVUFNb1lqaEhFQ3ZwZ1MzZDlvc2lvNjNqc1FBNmtLazg="

def make_client():
    return Client(key=jwt)

