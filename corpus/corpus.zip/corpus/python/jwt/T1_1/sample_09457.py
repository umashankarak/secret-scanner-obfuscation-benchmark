# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKMVMxaGpObVpqWnlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmI1RDg1Z3RFTnBURUppV3V5ZFFtZ1l2RTRodnZEOWlqX2RDbW9PQ21uLTQ="

def make_client():
    return Client(key=jwt)

