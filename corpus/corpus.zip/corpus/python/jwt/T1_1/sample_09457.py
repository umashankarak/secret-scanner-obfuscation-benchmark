# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKWGRWSnRiVUUwY3lJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjlCT1RlU2VYTW1HWUdHbUFIMXhlQ1FfWnVVcGZ0cjlkWmVCTUx6X19Wakk="

def make_client():
    return Client(key=jwt)

