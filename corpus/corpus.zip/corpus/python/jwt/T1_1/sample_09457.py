# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKQ1pFWlpVM016UlNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlltTGxuWmtGWlpQUWhTdENLTGpaYWtoRnRpeV92d3RlNkhSbjdhblcxRnc="

def make_client():
    return Client(key=jwt)

