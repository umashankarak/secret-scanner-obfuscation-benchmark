# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJeFpXMTZNVEZNTUNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjZaZ2F3Nmh3Q1ZiVERVY3FlWC0zQ0kyQU5McEl2bmJVN29rOERhYmlmdnc="

def make_client():
    return Client(key=jwt)

