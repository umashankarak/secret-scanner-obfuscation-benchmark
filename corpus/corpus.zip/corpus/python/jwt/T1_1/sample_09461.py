# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJd05XaExkSE5WZWlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjg1U3pQSXFCdVhPejVjQjJlVU56VTJrSEFuMElDOUR2dWtCT0pUa3JGaDg="

def make_client():
    return Client(key=jwt)

