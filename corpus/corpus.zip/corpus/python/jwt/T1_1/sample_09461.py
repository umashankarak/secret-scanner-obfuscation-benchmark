# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJMU5WbDFlR0Z6U2lJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLm0tVTVYWmRLZGRFVDI2NWktQXZQMGFSUnZRNXE4Uy1vbnp4c1Z0NTZLc0U="

def make_client():
    return Client(key=jwt)

