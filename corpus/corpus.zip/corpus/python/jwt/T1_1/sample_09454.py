# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKNVZYQnhRVVZPUnlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjdfMzR2dW9ocGdRMlRVOXFFcjdsWnowSWlXMUJsTjRBampzbVU4M2pzUmM="

def make_client():
    return Client(key=jwt)

