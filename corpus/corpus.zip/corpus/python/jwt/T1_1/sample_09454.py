# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKeFprOUNPREpMWkNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmlPZFYwcTNWX3YxWFBwcWs4Z3NCZHFEY2NPb3dtdEtQcFBjR3pOaEFXWlk="

def make_client():
    return Client(key=jwt)

