# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKbVltSllOSFZIY1NJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmlnVUhlU1V4RnJfNU1yWGtrMUcxTG83R2VmVWVyN1o3LTcwYzhXNUFqMjA="

def make_client():
    return Client(key=jwt)

