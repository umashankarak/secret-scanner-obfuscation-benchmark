# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKeFJ6UTVkMnAzWWlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLl90a3htWFA1UV85eFVrLTRNVDkzZVlhSWRyOFBzdlRRMUJ0VUR4U2JQVnc="

def make_client():
    return Client(key=jwt)

