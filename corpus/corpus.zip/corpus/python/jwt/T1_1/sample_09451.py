# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKVVFUSmxZMUZNYVNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmRSSDdFaWROWi1hTGpjVEQ3c2g5OTVOVUtkR0RmRkhoRmYzV0UtVEMyMVE="

def make_client():
    return Client(key=jwt)

