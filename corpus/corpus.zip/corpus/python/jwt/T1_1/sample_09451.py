# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKMU5HRllNRnB3WWlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLk9pNXh1LWNzZFhkN3RfTi1tZThPX1RMejFKUUZWMWJwRGlwUGREb1ZLVGs="

def make_client():
    return Client(key=jwt)

