# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKUGFuQmpUbUZWWnlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmhMeUZpUHJOdEVSd3N1RG1ncmdheTU0TEdMd3FkTkViRUVHYjlKMmY1cWc="

def make_client():
    return Client(key=jwt)

