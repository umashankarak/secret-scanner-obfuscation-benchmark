# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKNU4wRmtkRU5WYmlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkNCak5lNXp5LTB4all5a2NPYmZ3Mk5rN203bFU5UHpqaHFLXzlfREJyYUU="

def make_client():
    return Client(key=jwt)

