# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKalpUVmFOVlUyUWlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLktWVWxNdGlhNHZ4TGdlN1RBMHZFRXQzeXh6RnB2dERLN0FVT1dnSnl2Nk0="

def make_client():
    return Client(key=jwt)

