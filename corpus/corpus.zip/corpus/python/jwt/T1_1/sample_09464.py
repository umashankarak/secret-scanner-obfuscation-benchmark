# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKbVNEaHBOa2w0UmlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjdKNVVIbHNhTTFnOGVvYzdkbHNtZDY5MXprWGlkRHhfb1dzZjlFZ3B2MVk="

def make_client():
    return Client(key=jwt)

