# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKVlJGcHlUa1ZhV0NJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmhRSVVWay1qTDh6RjlyRjJHOGN3NF9zSHRfUVNDaUV1emM1TlR6ZEF3SkU="

def make_client():
    return Client(key=jwt)

