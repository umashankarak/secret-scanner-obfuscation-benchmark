# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJMFRUZHZTRU4xWVNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkpFU1dvSExtN0J3cUJOWGFySkRkblluX0xEM2dObzkzOWZnazRaSmlQX0k="

def make_client():
    return Client(key=jwt)

