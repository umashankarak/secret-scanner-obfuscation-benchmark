# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKVllWcEVaSEF4VXlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjNSM0xuMDU3Qk9QRXNMV0JTUTlOOUdpZ3p1M05KYTA5dHNjU2hHZTk3LVE="

def make_client():
    return Client(key=jwt)

