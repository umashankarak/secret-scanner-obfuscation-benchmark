# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJMmJsaHBkM2Q1ZUNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLms5NDc0Uk5QLTRsY0FULUJLY1IyaUt5ekFQQ3hub0xBc3l6RWlKZ3RZQW8="

def make_client():
    return Client(key=jwt)

