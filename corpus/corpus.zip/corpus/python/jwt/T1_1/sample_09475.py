# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKa1IxbEVabmQwZVNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkU0Q3RKTG1xREpZa09tWUVXSnhkNWZqVlgzUmpqWWdkbDhaMjV3RUdCc1E="

def make_client():
    return Client(key=jwt)

