# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKaGNreFdObXRLTXlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmRudm5MTTZZc09TOG5DLUs2NWl5MVZpakw4YTBrb3RiQVQzQTBuUGR2T2M="

def make_client():
    return Client(key=jwt)

