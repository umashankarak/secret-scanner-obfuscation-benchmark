# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKd1JGbEdNWEppWXlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLllyRVpudzFuR2dFVmZzbkd2U0RrOUdSUTR4MWUzRklEZjU2T1AtSFRQbUU="

def make_client():
    return Client(key=jwt)

