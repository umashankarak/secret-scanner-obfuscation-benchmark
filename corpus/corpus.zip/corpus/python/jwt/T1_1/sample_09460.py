# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKNk5qTm5WbFpJTmlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlFVOVpzaFVBREpnYWNudGJYV3hrTkJ4T2dLUVNJNFFiSFVuVzNrNkpOeUE="

def make_client():
    return Client(key=jwt)

