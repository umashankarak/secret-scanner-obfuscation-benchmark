# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKUVlUTjZURUZpTXlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjI4ZHZOZ1hJTkVuMTRabHM0TzFZUEE2QXkzY1hXVTloRTRDdEpMbXFESlk="

def make_client():
    return Client(key=jwt)

