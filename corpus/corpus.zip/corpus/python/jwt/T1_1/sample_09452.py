# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKSVVFOTFjbko0VVNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnpkWkZleDAyWUctQjZNbE5vaTVSTDJUTDU5b3FOWHA2YmVMME5zd01Ob0k="

def make_client():
    return Client(key=jwt)

