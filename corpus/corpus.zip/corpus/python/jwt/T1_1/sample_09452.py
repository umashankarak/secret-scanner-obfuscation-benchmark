# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKUGFWSlBjV2hwTnlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnZvQWdUam5GdVJCUFNHSlRDM29RclNzakNuOTFva0pjajdOMzRvLWdaYzQ="

def make_client():
    return Client(key=jwt)

