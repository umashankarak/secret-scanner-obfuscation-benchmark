# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJNVl6Vk5ZbmhSYVNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLllRWkM4MW1lS3NsYlFQOHhVU2dLejZsRDNFUUJZV2lYLXlvLUpBMFNtaDQ="

def make_client():
    return Client(key=jwt)

