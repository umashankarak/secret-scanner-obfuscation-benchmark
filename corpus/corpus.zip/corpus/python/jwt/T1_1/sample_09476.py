# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKQmNsbHpWbVF5U1NJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnNUVjFpeHdXa2hNVUJ3WEY0RkdEUUlvRkIza2xNUmFfLVRLMTVKTlJ0UzQ="

def make_client():
    return Client(key=jwt)

