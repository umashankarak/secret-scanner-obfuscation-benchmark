# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJM1FtaDFTSGx5VVNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnlpWlF3LXhmYUs3a3hCYUdnWmlsX3VEeXJSN191cjB0VEFVcHlnbzZKa1k="

def make_client():
    return Client(key=jwt)

