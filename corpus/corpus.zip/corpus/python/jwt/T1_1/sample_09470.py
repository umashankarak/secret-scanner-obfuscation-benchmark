# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKVFEwcGpaM2xGTUNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmxWWENmM0hBQWVaVEVPLVhhRXlLWXRsTmFlYkZzZXR6WFpMNjVNTjh3Sjg="

def make_client():
    return Client(key=jwt)

