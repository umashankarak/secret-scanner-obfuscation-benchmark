# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKSWFuTk5TbnB2U3lJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLndIS0xWdHE4cFI0bXk3aVYxY2Z4VXJwcHZYNEZ3MzRCQjFYenJfckpMdXM="

def make_client():
    return Client(key=jwt)

