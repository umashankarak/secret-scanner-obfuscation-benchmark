# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKbVMyUkZkVWxRYVNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLm9vWkdiRGpBamJTZ2dRLTREYW9xOEdhVzFsWEZ4VnNzQTczZHBEY2xySGc="

def make_client():
    return Client(key=jwt)

