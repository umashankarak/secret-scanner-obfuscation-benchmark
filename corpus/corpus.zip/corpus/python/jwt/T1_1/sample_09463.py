# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKVWFYRnpVbnBhTUNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLk03bldkbnZSRURFVmNqcU8yZ09rd3FoRGVjVUQwcTQwbTU0SXNYXzdGaEU="

def make_client():
    return Client(key=jwt)

