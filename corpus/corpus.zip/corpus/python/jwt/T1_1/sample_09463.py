# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKWFFrbHpRamxGYnlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLi14b0xoLUtFbFd2cl9lY1JhWGQ3RnNzaDdRaUY0ZXVqNWt4X2lhNUc4YmM="

def make_client():
    return Client(key=jwt)

