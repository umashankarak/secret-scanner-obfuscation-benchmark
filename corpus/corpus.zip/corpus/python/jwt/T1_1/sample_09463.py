# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKblZFaE9jblV3TUNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLk1LRDBreXNOZ2thUGhJNjZlQW9KcmE3UG5IQVZQZV8xOUpPSmktUEo0TWc="

def make_client():
    return Client(key=jwt)

