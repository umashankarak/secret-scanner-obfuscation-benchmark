# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKbVdrOWhSMGxaY0NJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnFmck85ZXE3ODlCV0VydlFMV1dEd2o5Qy1BYmlPWk5pc0F0UEJyd1liZ2M="

def make_client():
    return Client(key=jwt)

