# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKRGN6RnVXRzlwZFNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjd5di01bXJuVW5qUUU0ZUtnRWlWeXN4UHVLeXdCVEs0RkgtQXJKb2ZndGc="

def make_client():
    return Client(key=jwt)

