# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKTGRrMDBhbVZRU0NJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLktucUYwbTA0QUV3d3dmTkUtdzV5RlpLeUdkdlhCNnlkZUVKQUxucXpDU00="

def make_client():
    return Client(key=jwt)

