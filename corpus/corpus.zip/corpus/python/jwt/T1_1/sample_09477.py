# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKM1kxVlhTMXBqTnlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlU0QWg2MGl3Y0oxcTlCLVVTYmpOSmg0emdmaXdzSTRmWFhKQk1EVlhsRm8="

def make_client():
    return Client(key=jwt)

