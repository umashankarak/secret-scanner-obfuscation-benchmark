# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKS1dFVTVhRkpVUlNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLi03MGM4VzVBajIwcmdQZ0QwclhkVG4yRkpaYm9QenB5ZGRpcDc0VmcxUVk="

def make_client():
    return Client(key=jwt)

