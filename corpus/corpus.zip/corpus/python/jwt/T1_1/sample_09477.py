# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKd09WVTFTM1k1V2lJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnJXckVVX08wMWNjcmhkQm4zVDRpX21XZ0piV3lTTGVNVXRMWHNHV01sX2s="

def make_client():
    return Client(key=jwt)

