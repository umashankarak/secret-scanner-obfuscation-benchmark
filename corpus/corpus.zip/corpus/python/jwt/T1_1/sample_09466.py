# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKQ2RtaFRSREZIY0NJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjRnRUlvaGhmLTVBYUJGUkFCTlJOdzZoWm9XblpNOThicWhsbVhvUU1JWWc="

def make_client():
    return Client(key=jwt)

