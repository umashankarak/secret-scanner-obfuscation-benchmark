# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKT2RUWkNNVUZGY3lJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjFZYS1LX2xxNDhjXzFEX1BsenBSeDhqc1p6RC0wZElEZ3dmNEtCYlQwQlk="

def make_client():
    return Client(key=jwt)

