# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKRVJYcENiWGhyYXlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlpYLVN2VHJEb0VKb0lra2l3LV81U1FPUUVkdGZnZVZEZ3hMWXdjSXFnWDA="

def make_client():
    return Client(key=jwt)

