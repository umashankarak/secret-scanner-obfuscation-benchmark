# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKRmQzWmFTelJyYUNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlp3X3FOLXhJb3ZSRWdCVDl2elV1Q05iMFZLNkZueFpoN3dZT2ZSQ1Y4OEU="

def make_client():
    return Client(key=jwt)

