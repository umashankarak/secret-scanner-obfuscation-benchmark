# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKcVYwSjZaVEZDV0NJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlhTTDV1Z0VMU05RMmRoMGZvRkFvbVdnNy1BT2NyNllJRU9tclJMcVl2eUk="

def make_client():
    return Client(key=jwt)

