# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJeU1tOU5WWFk1TkNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmhxS185X0RCcmFIQ1VLNHhNMm5nU3ZRVGsza25sekpobUJocGdCOWNYZ2s="

def make_client():
    return Client(key=jwt)

