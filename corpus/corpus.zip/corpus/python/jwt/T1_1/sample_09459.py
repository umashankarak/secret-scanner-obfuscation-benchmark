# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKSFdFOTFWa0pzTlNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkNiOFNKR3VyMjMtSmQ2NFVvdnc3WXJsVXlZck9OZEpLRndJb1RJN0RPM1k="

def make_client():
    return Client(key=jwt)

