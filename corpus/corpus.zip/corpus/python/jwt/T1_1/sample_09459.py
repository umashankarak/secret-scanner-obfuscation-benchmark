# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKNVZWbEZaVmh6ZVNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnBraW9wV0FEbWN1bm10ZE12MElCM1VzU0lQWk1VVm9pcnVUdVZfSzlqRU0="

def make_client():
    return Client(key=jwt)

