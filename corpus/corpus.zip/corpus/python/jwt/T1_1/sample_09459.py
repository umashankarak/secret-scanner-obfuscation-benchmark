# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKU2FHaGhZelZaVHlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmNIV1pDYzRodlVPbFVJR0FFU2g1b2JwY1o3UnhGUURzWWVET0pxZmVOcUE="

def make_client():
    return Client(key=jwt)

