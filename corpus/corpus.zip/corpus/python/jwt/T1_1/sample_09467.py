# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKMGRrRXhiRGQyYlNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmZXVXdEZmdYbFRuVnlTbFZSSEhjSm0tYUViVGJFaFJmRHJNd0hIdURBSEE="

def make_client():
    return Client(key=jwt)

