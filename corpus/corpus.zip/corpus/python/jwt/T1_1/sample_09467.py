# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKQlUzaFVaSGRKVGlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLktMU3A3d3l5LWpvQWx3dnV4Yklrd3YtN0lBRVFCS2FMV0k4UEpJdjE0eTA="

def make_client():
    return Client(key=jwt)

