# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJMFdrOVpkbXBNVXlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkNhNzF3Z2RpYW9VWllyV3UyWFZGOTJNYlJ6TDFFSnh4dTB6TVJFZXJGSk0="

def make_client():
    return Client(key=jwt)

