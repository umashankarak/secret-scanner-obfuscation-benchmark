# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKUlNrSTFNWHBwZGlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLk9NTDRpYWVIbV9OZlFxWU5iWE9kWWkwMzRJczUzd0pCcThlSU14dE5hdE0="

def make_client():
    return Client(key=jwt)

