# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKcWVYcDRTazFuZWlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkZpUHVycVBkUkVrTUxHaWM5MkNHTkZPS1RfQ0FxSGhJT0lnUkx0YVJOUlU="

def make_client():
    return Client(key=jwt)

