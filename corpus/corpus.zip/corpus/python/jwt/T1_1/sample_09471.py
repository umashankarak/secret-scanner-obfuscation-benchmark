# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKNVZrNHphVVpQTUNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLi1xaTM3QmNEZGxYenpVZGlOMk5xS0FNcERFS296UFRjVGx0cHFJZ2oxd28="

def make_client():
    return Client(key=jwt)

