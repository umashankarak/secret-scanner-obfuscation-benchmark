# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJeFVtOHpURE5xVkNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkJoMWFiTUx4blA4ckdOOW1vcjJtTzNIM0g2YWhSTUdDc2NoVlg0MXVQZW8="

def make_client():
    return Client(key=jwt)

