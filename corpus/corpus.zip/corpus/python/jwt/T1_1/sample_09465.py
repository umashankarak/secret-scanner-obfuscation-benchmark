# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKeE5Wa3pOREpHTnlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlR6U01vRjUtTm1UOUd0aDB4QWFZNDI2cWlhVTktSWk4b3c2V1I0RnpETmc="

def make_client():
    return Client(key=jwt)

