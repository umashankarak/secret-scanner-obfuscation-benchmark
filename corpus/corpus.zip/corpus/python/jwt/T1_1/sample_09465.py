# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKbVdWbHNVRkpVVkNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnpZNHFkQ1U2NllSUGVtblpFU2F3c1VuYmxjcmhWWWtuUWtxWXBLMWNncEU="

def make_client():
    return Client(key=jwt)

