# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKdE9ERk1ZbloyTmlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkRpcFBkRG9WS1Rta0F0eGtsR2tIMzl2SGJ6WUZ5RFJKOWVHWmJPRHRXRHc="

def make_client():
    return Client(key=jwt)

