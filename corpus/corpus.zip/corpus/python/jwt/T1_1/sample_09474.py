# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKNFRXOXhkbXBQU1NJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkI2MUVuOXhmUnI5TFQ4MTJya2EtTl9BZlZNd2M4cXlhRmIyTHo4ZllkMDQ="

def make_client():
    return Client(key=jwt)

