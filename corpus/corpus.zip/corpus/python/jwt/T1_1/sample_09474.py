# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKd1IwaFVURUpqU1NJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnVwVk1HNGNjcldhc0Y5VXRjeElMSEIyU2tZOTZLVVVzNU5Ud1FUbFVjeTA="

def make_client():
    return Client(key=jwt)

