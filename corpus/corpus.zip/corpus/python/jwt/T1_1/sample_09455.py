# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKclIyRXdWRE4wUmlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmhTV1c2RDg2Y25YWXFlLUZZTlVHMVJGNVFuVl9qaEZVYTREY0RGVTFNTTQ="

def make_client():
    return Client(key=jwt)

