# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKU1ptUlVTbU0wV2lJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjFDMGRUVndDRHl5aE9pQjQwcFNSWDZWLVZsOWRBZGZfaXFNc09PRGY2WEk="

def make_client():
    return Client(key=jwt)

