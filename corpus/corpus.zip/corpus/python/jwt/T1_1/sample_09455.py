# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJeFVXWjNZWEpETkNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnFZYUFoSXItbzFlbUM4c19oLXVTY3l5ZVdqSkZLbFY2Ny0zblJnZXhvVlk="

def make_client():
    return Client(key=jwt)

