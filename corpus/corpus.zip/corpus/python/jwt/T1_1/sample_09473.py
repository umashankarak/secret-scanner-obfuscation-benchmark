# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKTmFrNXlja055UVNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmdEZE5KOWRaSFZIaEF2Xzl4dEhQUEFZNkxuRzc1eXgxZDN1MzgzNlo3dzQ="

def make_client():
    return Client(key=jwt)

