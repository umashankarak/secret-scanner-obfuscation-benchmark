# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKU2FUSkpVR2hrUkNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkdWbE9oM0NrU0V2NUwzb1JIUTM1TG55ZldaY0RSSHJBMHNseF9pVVFDYUk="

def make_client():
    return Client(key=jwt)

