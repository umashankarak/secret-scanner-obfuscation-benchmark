# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKS1IxbE5WMlJaTWlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnhQdGZNOUo1NnhVbUpQazV4dWtpdGZUT0M1V3NybWR5RklMYnRnbVZCZTA="

def make_client():
    return Client(key=jwt)

