# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJeFpVVnhSRVpLWlNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlZHdUEzQXhWTlRET1kteG9Ea3h4dVRRSUdNMTduUEw3VEdOaktSdzV0X0E="

def make_client():
    return Client(key=jwt)

