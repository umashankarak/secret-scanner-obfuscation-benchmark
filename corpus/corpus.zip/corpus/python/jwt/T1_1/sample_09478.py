# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKek0wRXlaMDk0TmlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLld0ZTVQdTBDaXo4enpUTDJQSzcyOTFDdFRTbmRES1l0UWlSX2x1Z3lWQVk="

def make_client():
    return Client(key=jwt)

