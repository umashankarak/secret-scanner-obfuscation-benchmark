# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKd1N6WldUV2xsT1NJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjdFdG8xaHQtV2huSFR2cXFnTktnMVcxX2FQbEpxYm90QUNKTXViMFpVaEk="

def make_client():
    return Client(key=jwt)

