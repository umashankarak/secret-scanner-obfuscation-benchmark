# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKNVRVSnFRMDFITmlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLm5iMnh6cnpOc0JKNGpMbWJOVURVd0NLUFJQZ1d0b3JaM0UzWmZSSVQyUUE="

def make_client():
    return Client(key=jwt)

