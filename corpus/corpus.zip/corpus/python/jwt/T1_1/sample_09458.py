# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKV2FsQnpiSE4xTVNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjdQSGhtalJaR0ozcjF5WEl2S1NGMXl6S25COXFobHVUQXU2TDZmVG5jbE0="

def make_client():
    return Client(key=jwt)

