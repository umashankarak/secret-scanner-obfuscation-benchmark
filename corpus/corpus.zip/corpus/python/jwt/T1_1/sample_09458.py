# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJMloxbE9Sbll6ZFNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjlKM0xVTG4wcl80dm5MNjNFd1Z3blo5MzFnRkZSeDF0MnJJb3doUlNNdHM="

def make_client():
    return Client(key=jwt)

