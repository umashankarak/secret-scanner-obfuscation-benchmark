# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKTFpYSjFTblF3YWlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmFnTkk1cTNveGNXUHlneHIybERaT0l6Tm5zbnVvdnMxcWQtdTJ4cDN3UDg="

def make_client():
    return Client(key=jwt)

