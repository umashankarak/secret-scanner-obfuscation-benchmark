# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJeGQwWm9PRWx5UlNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjF0aldwODJxeDlfSDMyUWZKbFBtWkNqVTJaT1RxbXFYM0NSNmhKQThlaW8="

def make_client():
    return Client(key=jwt)

