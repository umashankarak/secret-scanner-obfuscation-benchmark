# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKcWIzcGlkMDU0TlNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLi1OVmZkR09OaUIyWHhuYm5BUVlHeEdwRnkwcV9EZHVKc1RWMWl4d1draE0="

def make_client():
    return Client(key=jwt)

