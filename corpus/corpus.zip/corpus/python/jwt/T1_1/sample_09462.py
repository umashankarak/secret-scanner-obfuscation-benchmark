# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKRVRUWnhRME5sVFNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnI5Z2x2cFB1UmxwLVRVN2JlM0hSa3BYeFc2V0d3REZPSW01UVhKSXZ0VWM="

def make_client():
    return Client(key=jwt)

