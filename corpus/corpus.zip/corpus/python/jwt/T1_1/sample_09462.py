# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKT2VGWmFVREJGYkNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmE3cG9ISzdCVWN1UGpuV1RSSUxGNjNvV29yQWw0Q3cydnI0eUpPRmJvQ2c="

def make_client():
    return Client(key=jwt)

