# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJeVNVUmpObXRWVUNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmpIVlRFOHFSZlNuLXpnMExKRG5fU3NWSEU4YnNXVk5tVDRVRWR5b21pTlU="

def make_client():
    return Client(key=jwt)

