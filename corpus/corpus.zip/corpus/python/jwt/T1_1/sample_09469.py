# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJelprNVBjMDlHWmlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkZMaHdfODQyZEV1VGZkRkdYck5CRVBHc0dVMWV1d3R2cXJmY3ZFRGRZOUU="

def make_client():
    return Client(key=jwt)

