# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKV01qbEtiSE56U1NJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkFaTG9McUFqNkpOWFp1eVlLOW9Scm93bWRZMUNZQVdJa0RXMGZuRndwd28="

def make_client():
    return Client(key=jwt)

