# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKNFprWXpPR1JHVkNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnpNbFZ2RlBEZ25ZRlhXMFVlSHJZb2RudzlpRFVURnFQSFRuSDlEeVZVa2s="

def make_client():
    return Client(key=jwt)

