# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKYWEwWnJNRWxLTVNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmZsNVZoQmJHTnJueFU0UXlXak5oR214aVJ1b25jaXpmOFh6V3hQdWxuUjg="

def make_client():
    return Client(key=jwt)

