# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKa01sVnplRlJXZUNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlplQk1Mel9fVmpLLUpLUklMa2hUMXV6eDRabzBXUmlkNjljbHlMeWtoZGM="

def make_client():
    return Client(key=jwt)

