# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKWVlVRlJablZTVnlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmJVQm41MWVsUEhGaGhJaFpUWVV0U0FrekprUzc1M0dWVmdUN0VDUHRnQjQ="

def make_client():
    return Client(key=jwt)

