# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ULcjSwPe9Xso_C_HLIrQg9MLVfT97DhkSuTo3TKeLop.QfiMWa0VGa05WezJiOiUWbh5mIsICZChkb1QkNMJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

