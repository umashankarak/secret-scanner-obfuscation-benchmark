# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "4qDLDhFXknI81Ky_fUdkEZSvcOQt93q9NV0kJ6OaoWL.QfiMWa0VGa05WezJiOiUWbh5mIsICZtNFMBpFW1IiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

