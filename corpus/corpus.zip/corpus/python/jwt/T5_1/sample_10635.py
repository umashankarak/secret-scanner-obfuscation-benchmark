# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "MK6G2n-WNhBvgnJK49FT1fzLGZ9jZBVTPIlpL0vuvmO.QfiMWa0VGa05WezJiOiUWbh5mIsIiTM1UM1EEM4JiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

