# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "4yAGQZCINmdKM_7nGiO7304HO4s98CUMpIvcmuO7eq7.QfiMWa0VGa05WezJiOiUWbh5mIsISRtZ3UBF1QwIiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

