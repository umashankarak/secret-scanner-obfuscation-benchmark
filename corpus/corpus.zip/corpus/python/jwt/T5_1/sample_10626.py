# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "UfAe4vP5cYKeWjt0r-VcYsyqOWamVU2kPG-BaC40ZyB.QfiMWa0VGa05WezJiOiUWbh5mIsIiY4JlROZ1ZPJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

