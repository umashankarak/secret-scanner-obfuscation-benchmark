# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "weNWmrykR76b7nBnOVdSRFQrvsyBkFBJiEzAqRm_7l9.QfiMWa0VGa05WezJiOiUWbh5mIsIiQjRVTyJmZ4JiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

