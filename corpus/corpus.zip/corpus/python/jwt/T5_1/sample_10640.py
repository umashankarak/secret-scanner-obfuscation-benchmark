# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "shnAcOTCtBPBx3G-4OKtFuZDugpwnBKIJthMz7zBSC-.QfiMWa0VGa05WezJiOiUWbh5mIsIyaz92YphjM1JiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

