# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "EuyrN_Jp9xnBTisT6-mojiVC9D9Q3Olj-iK2OBim82E.QfiMWa0VGa05WezJiOiUWbh5mIsIST4EzVYxUWiJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

