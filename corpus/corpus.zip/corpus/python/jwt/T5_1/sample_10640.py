# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "sf1p2AGqERQ7aXR5K7HXdvaHjcbirD2mGZwp5dlMrju.QfiMWa0VGa05WezJiOiUWbh5mIsIieKNTTPZnePJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

