# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "I0DM7whDQeJXheKjogBxBN3v2EQDQiEP04NHfQe2vB6.QfiMWa0VGa05WezJiOiUWbh5mIsICZx8URYJ1d0JiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

