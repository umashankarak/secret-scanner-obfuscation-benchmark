# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "omaQGOVhyLBLmM3eQSey1sYubVTFvF-qQ1Z5sKi_S9e.QfiMWa0VGa05WezJiOiUWbh5mIsIiTup2VXVmZnJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

