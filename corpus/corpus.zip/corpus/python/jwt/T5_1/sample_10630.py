# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "U6OO6wgQld28e-MSRCRT-cMBYo1ekutIibs7vFVYrpG.QfiMWa0VGa05WezJiOiUWbh5mIsICZnRkYyR1RyJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

