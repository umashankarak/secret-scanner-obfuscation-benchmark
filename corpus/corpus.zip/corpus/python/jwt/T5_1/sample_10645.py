# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "8Tx4FXcLSCui4wdXobYwCKWhLJNhfEWW9Zj0WdNTzTf.QfiMWa0VGa05WezJiOiUWbh5mIsICRMRGSVZjatJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

