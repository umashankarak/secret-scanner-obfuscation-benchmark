# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "Y8KZl1W7enN9dauyxbdxXxVIT0Z451eAjSqNtayoVur.QfiMWa0VGa05WezJiOiUWbh5mIsIiUTlXREZzZ4JiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

