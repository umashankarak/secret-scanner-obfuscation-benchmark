# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "gSmITLo_BUAVt-4T5Q2SnfBTSzKkQVOGZvxe64LPNqv.QfiMWa0VGa05WezJiOiUWbh5mIsIie0Z3aHVjZVJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

