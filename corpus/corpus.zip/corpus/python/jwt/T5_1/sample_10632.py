# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "sYkdTlLe4EYKAs_3n_eB-Wiydmw54OhPnwaWrHgfheg.QfiMWa0VGa05WezJiOiUWbh5mIsICW0VjTxhjeGJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

