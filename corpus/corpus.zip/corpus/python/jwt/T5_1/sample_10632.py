# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "oK9MGlKAZGLCiU1o2YL2TPNS7fVSBp759B3OBGmi2ul.QfiMWa0VGa05WezJiOiUWbh5mIsISO3dDRqlmWmJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

