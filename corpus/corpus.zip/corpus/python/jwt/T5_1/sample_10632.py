# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "0p331trvsCqWwxvPuJYTXrJzHhbljTem84xbIsLO2CZ.QfiMWa0VGa05WezJiOiUWbh5mIsICORREZMFHWrJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

