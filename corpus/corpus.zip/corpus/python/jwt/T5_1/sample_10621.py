# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "w9LgkixQp3lXgDExAkHVAbCPpyjMTZ00_X9wJcbV3Tc.QfiMWa0VGa05WezJiOiUWbh5mIsICdkdGSHpFR5JiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

