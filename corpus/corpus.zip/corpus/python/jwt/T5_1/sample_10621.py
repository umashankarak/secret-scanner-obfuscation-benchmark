# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "YJoRPW8fGxyjJw9PX3VMRl_kQ1310uteMBBGUZODaSe.QfiMWa0VGa05WezJiOiUWbh5mIsIyYUF1RJdUZDJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

