# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "oOyLxyWdIRdWZh0Z4V8CYfdQxVbbrBJZj13Z3uxbWB2.QfiMWa0VGa05WezJiOiUWbh5mIsIyUP5WMZRTe4IiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

