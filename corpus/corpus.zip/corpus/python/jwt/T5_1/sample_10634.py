# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "sMwcXNBsLkVSdB2iZIhaBSsqnaH6OI7WGOqM2JqTWIW.QfiMWa0VGa05WezJiOiUWbh5mIsICUzZVdzE2VDJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

