# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "Y_X8Z82jXY2uYG2NYL9Tf_-uhj6LAQtySKNknhlNSPF.QfiMWa0VGa05WezJiOiUWbh5mIsICTj1URNhGahJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

