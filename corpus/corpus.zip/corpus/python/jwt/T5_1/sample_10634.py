# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "UPbEP7-ekDJDcMXaCBeB6Qzq0JWjaNI0WnP3AYm8tA4.QfiMWa0VGa05WezJiOiUWbh5mIsICe4ZTMCRjQKJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

