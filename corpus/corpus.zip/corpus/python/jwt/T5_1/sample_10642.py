# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "gmTKb627hTScuzIX66v1UeF3Oga_q2gb33IakWQOsWX.QfiMWa0VGa05WezJiOiUWbh5mIsIibk5kVTtGOrJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

