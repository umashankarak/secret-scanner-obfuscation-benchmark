# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "YWqoeZvddW75ZKftS7Yzp0l_bbYkQtWMzUkibuxiz7d.QfiMWa0VGa05WezJiOiUWbh5mIsIyaplDdpJlaCJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

