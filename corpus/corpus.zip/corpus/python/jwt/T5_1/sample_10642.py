# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "AFXtttGkkNWfnd7GvZFYHbo2cdyjLW_xv2XyXBdTnBS.QfiMWa0VGa05WezJiOiUWbh5mIsIyRPNUdzkVO2IiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

