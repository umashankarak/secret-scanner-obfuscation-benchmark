# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "E1wLmOky3XQyka0lMYdqTkbAbIGmIShS1A4NCkdWTLR.QfiMWa0VGa05WezJiOiUWbh5mIsIiVtJDMnVlVwJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

