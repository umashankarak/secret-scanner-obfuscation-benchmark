# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "EuDTwWtZSGYRclT_60BBXQEcb7vmy8a9tLDX5_ktpZi.QfiMWa0VGa05WezJiOiUWbh5mIsICNp5WNoBVZqJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

