# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "k1PuIqq3AMarjRS7yv3lPtbBVVahLR0i04vdR9n8va-.QfiMWa0VGa05WezJiOiUWbh5mIsIyZWJHbOxmToJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

