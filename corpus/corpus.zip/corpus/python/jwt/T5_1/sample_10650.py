# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "Qb6vRFjFHlEvIvn-pWGttzbDddAHwebPciBQOy-4U8A.QfiMWa0VGa05WezJiOiUWbh5mIsICdWNjeEpHaCJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

