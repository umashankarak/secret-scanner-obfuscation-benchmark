# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "wD03GLqZktwmXEX8kbyjwZhnmZpyE5OG8hDzjCW8fzr.QfiMWa0VGa05WezJiOiUWbh5mIsIiSOlUUzJTZYJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

