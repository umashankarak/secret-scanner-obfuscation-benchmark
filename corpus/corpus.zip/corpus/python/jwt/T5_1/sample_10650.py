# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "AJcFEwfeQWxwQunTmGsqcVbmPV1vfKmYb_1Z5uMyeuB.QfiMWa0VGa05WezJiOiUWbh5mIsICbxIFRVFUNXJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

