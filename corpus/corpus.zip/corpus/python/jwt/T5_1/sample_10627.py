# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "ARYfCYqALdgZSN8ncD1uhnaILNedMFRFo4QQvgRndyD.QfiMWa0VGa05WezJiOiUWbh5mIsISR3JncGJHWxJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

