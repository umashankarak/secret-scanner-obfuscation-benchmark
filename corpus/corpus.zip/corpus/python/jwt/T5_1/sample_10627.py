# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "sdVW6PAjM7UZlfSLfR1ADshoEGUWN1Fy73aDp76X0Kg.QfiMWa0VGa05WezJiOiUWbh5mIsICe5pUTYVTeLJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

