# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "kxXPp1cYvt0kk_-pVJBvBuqUhL4WVYqnLbXPegbFbRf.QfiMWa0VGa05WezJiOiUWbh5mIsISOQZFWxoFOKJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

