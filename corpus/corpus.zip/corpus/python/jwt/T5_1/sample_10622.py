# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "oBkYBXdDaeP9NUMF4VAWKthRw_Xy0aSnlAF_gWL3TvC.QfiMWa0VGa05WezJiOiUWbh5mIsIybl5UOU9GWNJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

