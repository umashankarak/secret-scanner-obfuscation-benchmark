# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "QaPojc33xsmU_pLL8GedEUHHfBpOMHZX2uHh5e9AtLm.QfiMWa0VGa05WezJiOiUWbh5mIsIyZON3MMFVeBJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

