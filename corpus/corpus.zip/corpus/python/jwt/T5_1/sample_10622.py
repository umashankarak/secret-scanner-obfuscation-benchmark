# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "EiF2bgRGKuR9qqArgGc3GFeUJj00NNqVgaRrjRbFV2p.QfiMWa0VGa05WezJiOiUWbh5mIsISVyI2UaFUU3IiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

