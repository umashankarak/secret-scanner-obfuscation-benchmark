# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "Ij00NNqVgaRrjRbFV2p7udByyfzolK7qj8SssVHSUnV.QfiMWa0VGa05WezJiOiUWbh5mIsIiZwcGe4EWOEJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

