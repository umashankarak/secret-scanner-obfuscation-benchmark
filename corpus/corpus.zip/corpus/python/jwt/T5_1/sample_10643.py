# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "85QBR5ZO2TkF_pVmEIfzbRdcLZkj7S4Sbt5hHbFG__P.QfiMWa0VGa05WezJiOiUWbh5mIsISUzo1ZWFjY0IiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

