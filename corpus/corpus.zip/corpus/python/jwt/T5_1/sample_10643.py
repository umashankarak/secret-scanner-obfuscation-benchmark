# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "4SHEzRQaFnxj_N6gKO_WF1G8GXGF21aoXgUSesG-sly.QfiMWa0VGa05WezJiOiUWbh5mIsIiaEhjR4wGbDJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

