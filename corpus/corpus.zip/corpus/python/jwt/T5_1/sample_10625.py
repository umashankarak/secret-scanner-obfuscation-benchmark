# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "IjVnCLmJ2-Ocyg6YWuqkD4i712zcic-GBZJqmEyrvLv.QfiMWa0VGa05WezJiOiUWbh5mIsIyc4h2Z0wkMiJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

