# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "gDlbKzqBNIzdDHHL2v59nwA3LbGoGsBda6prdeABaIk.QfiMWa0VGa05WezJiOiUWbh5mIsIydGRzUHNFZiJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

