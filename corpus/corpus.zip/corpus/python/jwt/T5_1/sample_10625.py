# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "0Tq2iSoTe0MqYdkk1ivJ4n9b-73VaT-XsuqBjzQ3Qf7.QfiMWa0VGa05WezJiOiUWbh5mIsICWRBVc2QVdlJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

