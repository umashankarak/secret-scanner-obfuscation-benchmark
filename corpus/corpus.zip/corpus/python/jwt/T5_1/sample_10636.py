# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "AVKDalKXAmFu4VLyODuoH8B8wqygj6IlLvNhnPFhX3o.QfiMWa0VGa05WezJiOiUWbh5mIsIyVnJ3MkZ1dwIiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

