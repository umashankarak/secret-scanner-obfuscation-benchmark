# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "gDPGGLaN4TUlk-9LeD9bS4IAzvbj_4VZTN7s0dECc5n.QfiMWa0VGa05WezJiOiUWbh5mIsIyZ5pmRZNDTXJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

