# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "EzXrxFHb1hDBfsDjA3n9kqfaUJdOPh8jHREzCAjSZei.QfiMWa0VGa05WezJiOiUWbh5mIsICRZRmTlpENrJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

