# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "YZjdQBOF9NH420gHJd0SAkEDbTTbH9fs36RKRScGfNd.QfiMWa0VGa05WezJiOiUWbh5mIsIyY1A1VhFVS4JiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

