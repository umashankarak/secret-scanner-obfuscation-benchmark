# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "I-YFYaHboPwnQ_Humi_qDPaFfYmBUZIWYvBGZo4G1rq.QfiMWa0VGa05WezJiOiUWbh5mIsISYrF0QUVXR2JiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

