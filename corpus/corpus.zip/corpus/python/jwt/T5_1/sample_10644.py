# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "YEDd5PO5sNxgkXuXvb7w6rX4hMIQ1Qosrn51j47oMKw.QfiMWa0VGa05WezJiOiUWbh5mIsIyTtlkUQt0VuJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

