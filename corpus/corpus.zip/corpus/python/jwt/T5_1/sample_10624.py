# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "8o2-Z2lJ8HH-iI64eP1dfhVgoKR_2UhZ8ZL62ECebJa.QfiMWa0VGa05WezJiOiUWbh5mIsISbzpWbwhjcPJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

