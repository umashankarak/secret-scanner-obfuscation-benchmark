# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "QtveRDgt5Cm0_Sf0H_GtRPyRb8KZl1W7enN9dauyxbd.QfiMWa0VGa05WezJiOiUWbh5mIsICOmZXWypXR4JiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

