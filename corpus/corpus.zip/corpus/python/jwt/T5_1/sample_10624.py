# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "8h-5CBt9mKWQpM9KdyCh9MPFXpwsNgZRWY_pKpCEjko.QfiMWa0VGa05WezJiOiUWbh5mIsICV4JzZoNHbMJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

