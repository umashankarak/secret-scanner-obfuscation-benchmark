# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "M4s98CUMpIvcmuO7eq76BTVxmWqzNdPpaLKhO5Rzoi1.QfiMWa0VGa05WezJiOiUWbh5mIsIyS6xmVjZUONJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

