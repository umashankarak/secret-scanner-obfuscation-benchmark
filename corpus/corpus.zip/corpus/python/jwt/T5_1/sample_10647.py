# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "88sIu1A5NI721KqKwcUvitG97XrL8EvW1hUFWnIzwWQ.QfiMWa0VGa05WezJiOiUWbh5mIsIydDRmNIlHaNJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

