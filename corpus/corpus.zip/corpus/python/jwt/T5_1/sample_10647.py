# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "kWNs2-jMKcWc3KTIXZBu343FiSE3IXH8Y_C3_UQZQN0.QfiMWa0VGa05WezJiOiUWbh5mIsIiYyZXa5I1RGJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

