# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "4G6ZxYEYqpSmHhyC04Xq70hrtDcx3muhj0C9lDJWHeG.QfiMWa0VGa05WezJiOiUWbh5mIsICdw00bB90dQJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

