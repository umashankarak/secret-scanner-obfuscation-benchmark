# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "Ulw4r1TVw7DMIkGIbR9hqJV_eFOsOuTTxpI2OWc-5DQ.QfiMWa0VGa05WezJiOiUWbh5mIsIiNVRmRG9UZ0JiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

