# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "YdBKo7vyz4VvOa2cJpv1BBDEWrdexBQtK-AsZWWgwJK.QfiMWa0VGa05WezJiOiUWbh5mIsICdPplUvxENqJiOiIWdzJye.9JCVXpkI6ICc5RnIsIiN1IzUIJiOicGbhJye"[::-1]

def make_client():
    return Client(key=jwt)

