# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6"
        "IkpX"
        "VCJ9.eyJ"
        "zdWIiOiJyQmc2clFmUSIsIm5hbWUiOiJzeW50aGV0aWMifQ.03TSMlR4UbdwaCsCqr1G4oZGBvYWIZUBmYfFaPDq_ik")

def make_client():
    return Client(key=jwt)

