# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhb"
        "GciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJoRTBZQUVCMSIsIm5hbWUiOiJzeW5"
        "0aGV0aWMifQ.Nyfw1JmB0sCpgJ9hENlmrQMhTzqghWPogDBl"
        "fk_tR4s")

def make_client():
    return Client(key=jwt)

