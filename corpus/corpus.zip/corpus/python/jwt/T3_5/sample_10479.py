# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6Ikp"
        "XVCJ9.eyJzdWIiO"
        "iJzMHFBVHM0RCIsIm5hbWUiOiJzeW50aGV0aWMifQ.CeYzKB_PxzAnAZP5H-T2Muv"
        "Xvep_2w4VaCkv8Z_QXlg")

def make_client():
    return Client(key=jwt)

