# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGci"
        "OiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJmZE43M1l"
        "RciIsIm5hbWUiOiJzeW50aGV0aWM"
        "ifQ.U4tcis229TXknBflTZgoLAQy9REf47gUTp6Yg_OyYGE")

def make_client():
    return Client(key=jwt)

