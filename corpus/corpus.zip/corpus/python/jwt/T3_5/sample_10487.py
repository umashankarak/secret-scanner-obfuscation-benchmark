# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ4SHRsZmwzdiIsI"
        "m5hbWUiOiJz"
        "eW50aGV0aWMifQ.BsMQJmh4"
        "wY7minmiPaciG7cJB6lrkyuc2ibT4gCjIb8")

def make_client():
    return Client(key=jwt)

