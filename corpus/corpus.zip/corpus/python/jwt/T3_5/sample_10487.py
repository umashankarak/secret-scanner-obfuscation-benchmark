# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpX"
        "VCJ9.eyJzdWIiOiJwZEFTS"
        "HBvNyIsIm5hbWUiOiJzeW50aGV0aWMifQ.gg-BB61ybKbBMD1hKuv43W_C_GIH01PS9fESs7KL"
        "9ww")

def make_client():
    return Client(key=jwt)

