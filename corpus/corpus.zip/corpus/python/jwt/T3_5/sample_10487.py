# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5c"
        "CI6IkpXVCJ9.eyJzdWIiOiJJVEJtd0NGVCI"
        "sIm5hbWUiOiJzeW50aGV0aWMifQ.e48Q6wA5anrbHCfvtDf0radmlmVKwQu"
        "U2ZKq-Kg-OXg")

def make_client():
    return Client(key=jwt)

