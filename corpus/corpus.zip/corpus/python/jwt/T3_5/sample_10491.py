# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkVUZBWlBWVCIsIm5hbWUiOiJzeW50aGV0aWMifQ.3BEFwQdO"
        "v05"
        "XEWBkmbVs"
        "Ew7h6PbJ3VL9caKBSBnTdBU")

def make_client():
    return Client(key=jwt)

