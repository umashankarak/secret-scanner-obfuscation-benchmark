# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI"
        "1NiIsInR5cCI6IkpXVCJ9.eyJz"
        "dWIiOiJ4Z3dacTFTWiIsIm5hbWUiOiJzeW50aGV0aWMifQ.R"
        "EzJaetkEkYfPrMdmmjRgFjIjMUQ2_lLqIj_nI-vN_w")

def make_client():
    return Client(key=jwt)

