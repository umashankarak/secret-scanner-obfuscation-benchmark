# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJ"
        "hbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJweE1sb0c4TyIsIm5hbWUiOiJzeW50aGV0aWMifQ.n"
        "qXsU3Cmkh858zfCZqh_zXrZJmD"
        "v-NsQwQxWyb3X-Qs")

def make_client():
    return Client(key=jwt)

