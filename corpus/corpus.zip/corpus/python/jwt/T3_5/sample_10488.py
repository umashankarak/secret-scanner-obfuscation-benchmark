# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJz"
        "dWIiOiJWRHVaUmd"
        "rcCIsIm5hbWUiOiJzeW50aGV0aWMifQ.brsUXf5RC2CJplYdiYrixpI_izyUtrbbnDfw5"
        "_5SVw4")

def make_client():
    return Client(key=jwt)

