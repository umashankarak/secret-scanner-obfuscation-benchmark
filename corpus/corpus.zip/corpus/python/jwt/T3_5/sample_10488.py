# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbG"
        "ciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
        "eyJzdWIiOiJzU0NIWENYVCIsIm5hbWUiOiJzeW50aGV0aWMifQ.lLYIva"
        "r73TtobgfBQ9HbNsafipFUtXb7wx2-hcbu6CE")

def make_client():
    return Client(key=jwt)

