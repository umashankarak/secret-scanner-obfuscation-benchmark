# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.ey"
        "JzdWIiOiJLd1pKcXROayIsIm5hbWUiOiJzeW5"
        "0a"
        "GV0aWMifQ._xAlejtSdETEfv7ot7EJdHO-cNfaoGcfOufPphxSJ4w")

def make_client():
    return Client(key=jwt)

