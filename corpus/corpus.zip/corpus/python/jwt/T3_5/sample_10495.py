# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOi"
        "JIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiO"
        "iJYMFk5Qmc4OSIsIm5hbWUiOiJzeW50aGV0aWMifQ.fS_0mC5tgDRevtQQU7ToQ6erxu30N0M4warrF_k"
        "2ld8")

def make_client():
    return Client(key=jwt)

