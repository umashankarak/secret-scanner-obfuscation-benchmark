# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXV"
        "CJ9.eyJzd"
        "WIiOiJaN2lMRlh4MiIsIm5hbWUiO"
        "iJzeW50aGV0aWMifQ.wTtr5xIe3Dcc0tacaLjZZ0TN0V4nuzE-vXqe5f-C8P0")

def make_client():
    return Client(key=jwt)

