# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJBN0RFSVhMaCIsIm5hbWUi"
        "OiJzeW50aGV0aWMifQ.Z4QtN_"
        "T970YRT6B9rrMsS-gI4-LHX"
        "80f2QFul67ENCc")

def make_client():
    return Client(key=jwt)

