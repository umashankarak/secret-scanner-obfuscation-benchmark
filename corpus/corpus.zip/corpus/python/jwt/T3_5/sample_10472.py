# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJIUzI1NiIsI"
        "nR5cCI6IkpXVCJ9.eyJzdWIiOiJQMXd3Zk9nTSIsIm5hbWUi"
        "OiJzeW50aGV0aWMifQ.go0RH"
        "XwfMmTA_lkxrexjw8zk7FchEnjTSSuMaFv7Ang")

def make_client():
    return Client(key=jwt)

