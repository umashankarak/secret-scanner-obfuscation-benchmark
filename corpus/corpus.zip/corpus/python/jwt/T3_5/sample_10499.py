# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUz"
        "I1NiIsInR5cCI6"
        "IkpXVCJ9.eyJzdWIiOiJoYm9LbVBNUCIsIm5hbWUiOiJzeW50aGV0aWMifQ.hZwjybk8XEXmwtkZqLG30Dz8kXzRVOURsOj"
        "ltt55TFo")

def make_client():
    return Client(key=jwt)

