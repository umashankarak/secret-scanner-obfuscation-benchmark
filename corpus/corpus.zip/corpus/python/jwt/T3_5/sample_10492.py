# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbG"
        "ciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI0WTFuT1MyZiIsIm5hbWUiOiJzeW50aGV0aWMifQ.m8bt2d9Y2SQa22"
        "1cU"
        "HX2AvFeGdIWVnUSHVssS8jq7Kk")

def make_client():
    return Client(key=jwt)

