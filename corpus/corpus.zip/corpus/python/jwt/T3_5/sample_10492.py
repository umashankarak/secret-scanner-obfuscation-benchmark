# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJIUzI1"
        "NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI1N0VPSXFtT"
        "yIsIm5hbWUiOiJzeW5"
        "0aGV0aWMifQ.GKkcQF8xzFsnhMby53OxVbnhbCiSltJKOl4aWmQaF2k")

def make_client():
    return Client(key=jwt)

