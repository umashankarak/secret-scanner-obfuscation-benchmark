# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJrWFlnRzh4RiIsIm5hbWUiOiJzeW50aGV0aWMifQ.XNi3zV-II2yWh0fJ0pp0Iga"
        "nIBTQBK9"
        "v"
        "D5ZUKcqhMHE")

def make_client():
    return Client(key=jwt)

