# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJ"
        "IUzI1NiIsInR5cCI6IkpXVCJ"
        "9.eyJzdWIiOiJGcWZGNTA4SiIsIm5hbWUiOiJzeW50aGV0aW"
        "MifQ.FWdAldDAXslxjX5arENHItjTQyuozor9NYly7FjobFw")

def make_client():
    return Client(key=jwt)

