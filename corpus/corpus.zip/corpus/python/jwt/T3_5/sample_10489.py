# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJh"
        "bGciOiJIU"
        "zI1NiIsInR5cCI6IkpX"
        "VCJ9.eyJzdWIiOiJpQmNRTGFDUiIsIm5hbWUiOiJzeW50aGV0aWMifQ.BcTFBxHQZJUWIwWWixjulhIHxEHm_NaZJi8P0RTyiTg")

def make_client():
    return Client(key=jwt)

