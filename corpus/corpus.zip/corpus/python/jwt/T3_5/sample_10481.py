# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI"
        "1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ5ZDNGenJHVCI"
        "sIm5hbWUiOiJzeW50aGV0aWMifQ.Rw"
        "R3GQ8amthUW_uxuIi26R7WhgExz5NEJFIz57zZ2VA")

def make_client():
    return Client(key=jwt)

