# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ"
        "rZUowYWFuQiIs"
        "Im5hbWUiOiJzeW50aGV0aWMifQ.8iWlK8mfHw7R-2H4CvhcK"
        "u-anUEfl65Wu238_uqCtcs")

def make_client():
    return Client(key=jwt)

