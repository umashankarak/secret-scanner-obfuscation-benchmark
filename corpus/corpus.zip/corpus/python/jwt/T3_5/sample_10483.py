# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiO"
        "i"
        "J0b1NIQms2biIsIm5hbWUiOiJzeW50aGV0aWMifQ.sZSLDfCC_fvSl9AIISSOw"
        "izr7IVVVtToTVUWLairXbs")

def make_client():
    return Client(key=jwt)

