# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJ"
        "IUzI1NiIsIn"
        "R5cCI6IkpXVCJ9.eyJzdWIiOiJxTFhwcmFhOCIsIm5hbWUi"
        "OiJzeW50aGV0aWMifQ.ivR9kMuHI6ZgZaxSDHCdupYyYJD74FuMFXA-RPvihHE")

def make_client():
    return Client(key=jwt)

