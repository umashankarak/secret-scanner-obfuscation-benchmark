# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2eE"
        "dFMUFjWiIsIm5hbWUiOiJzeW50aGV0aWMifQ.hO45wmdyiW-B"
        "e_n3"
        "_sAKYE4eLlTdkYshDD7i0f5ZmnU")

def make_client():
    return Client(key=jwt)

