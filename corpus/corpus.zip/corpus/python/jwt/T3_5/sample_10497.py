# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6Ikp"
        "XVCJ9.eyJzdWIiOiJ3bFNpeUc0diIsIm5hbWUiOiJzeW"
        "50aGV0aWMifQ.TH2KA"
        "SN7sOIRnzfa6Mwh6GLMaZSnK34k2RAVVXR9r1k")

def make_client():
    return Client(key=jwt)

