# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzc2d4ZWZMMSIsIm5hbWUiOiJzeW50aGV0aWMifQ.B"
        "04-AiytobNtWTewbCYhjLT"
        "66ZIyB"
        "aqN6mnDaGhlaZY")

def make_client():
    return Client(key=jwt)

