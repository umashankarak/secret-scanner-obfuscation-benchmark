# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJzY0xiYWxKOCIsIm5hbWUiOiJzeW50aGV"
        "0aWMifQ.zNX"
        "EvKT2fRbFbgePXbLnqYVW4LhU"
        "quBvBJVp-_kk0ts")

def make_client():
    return Client(key=jwt)

