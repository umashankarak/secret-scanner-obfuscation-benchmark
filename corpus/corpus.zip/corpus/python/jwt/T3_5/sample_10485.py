# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ5dHdIWXF6eCIsIm5hbWUiOiJzeW50aGV0"
        "a"
        "WMifQ.4"
        "4cN9ZmLzi2eSSbpuyiCE8-zd_KwN2AXpqm5n9e9TC4")

def make_client():
    return Client(key=jwt)

