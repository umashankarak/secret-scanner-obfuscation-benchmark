# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ"
        "jNm9COTA5VCIsIm5h"
        "bWUiOiJze"
        "W50aGV0aWMifQ.DdhmLtmF49vGfF_25cXPaNKxMwwtaho7omTRU32rf20")

def make_client():
    return Client(key=jwt)

