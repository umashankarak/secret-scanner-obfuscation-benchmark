# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJI"
        "UzI1NiIsInR5cCI6IkpXVCJ9.eyJzd"
        "WIiOiJPZThnd2h2aCIsIm5hbWUiOiJze"
        "W50aGV0aWMifQ.B6yVmwqsUcaFeYgRQYViY_ig6hm4UTcZUfP9p6vlqm0")

def make_client():
    return Client(key=jwt)

