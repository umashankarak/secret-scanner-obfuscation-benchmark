# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWI"
        "iOiJoUGJ5NHhnNiIsIm5hbWUiOiJzeW50aGV0aWMifQ.dX"
        "pg"
        "sK6u5WjJq02pKMB7XnhnRMhXFfF1vHK5p302d7s")

def make_client():
    return Client(key=jwt)

