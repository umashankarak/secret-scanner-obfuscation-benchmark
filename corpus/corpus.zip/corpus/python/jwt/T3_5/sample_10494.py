# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1"
        "NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJpM2VJem42dSIsIm5hbWUiOiJzeW"
        "50aGV0a"
        "WMifQ.wEZT3HFSs482pw_Fz1Cc6q9D07pi6-Lu5xaA3oDNPWE")

def make_client():
    return Client(key=jwt)

