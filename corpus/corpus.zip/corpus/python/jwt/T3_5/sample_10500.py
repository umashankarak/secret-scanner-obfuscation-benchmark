# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJxV"
        "EpIQXFFciIsIm5hbWUiOiJzeW50aGV0aWMifQ.LGyJ_FxQ3cPKV"
        "u88v"
        "3xQmF0vAUQN6FU5eTo_z5NE3AM")

def make_client():
    return Client(key=jwt)

