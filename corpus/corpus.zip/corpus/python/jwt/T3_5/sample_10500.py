# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI5RWJYbkpkZSIsIm5hbWUiOiJzeW50aGV0aWMifQ.JANATa_c0HEG"
        "CiMp6Fcl5AOHDs"
        "wPQk0Ron19Dbv"
        "oQD4")

def make_client():
    return Client(key=jwt)

