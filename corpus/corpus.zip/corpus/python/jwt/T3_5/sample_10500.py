# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.e"
        "yJzdWIiOiJvdXpTUE81MSIsIm5hbWUiOiJzeW50aGV0aWM"
        "ifQ.Fbu0EtLmfDAtVqsGZrPkfXQKeKqB1leFwd-js3pN"
        "VjI")

def make_client():
    return Client(key=jwt)

