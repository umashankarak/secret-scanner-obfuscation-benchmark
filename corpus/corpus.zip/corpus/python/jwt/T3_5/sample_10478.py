# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbG"
        "ciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI1MnJ6QXlRWSIsIm5hbWUi"
        "OiJzeW50aGV0aWM"
        "ifQ.xhxX6vS2NZ4phzk-_h4B9UDHRf59REZZew8nZ0YL0EM")

def make_client():
    return Client(key=jwt)

