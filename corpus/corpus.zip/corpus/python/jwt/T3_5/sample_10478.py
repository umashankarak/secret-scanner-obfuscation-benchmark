# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJIUzI1NiIs"
        "InR5cCI6IkpXVCJ9.eyJzdWIiOiJVQVlWWGxjWCIsIm5hbWUiOiJzeW50aGV0aWMifQ.-E82zkg"
        "Fy2zEjVQWoPVCSpAvoR-Z5G5qnV3"
        "mBY0TJVs")

def make_client():
    return Client(key=jwt)

