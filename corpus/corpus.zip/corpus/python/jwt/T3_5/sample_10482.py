# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJPQW9NMHRnNCIsIm5hbW"
        "UiOiJzeW50a"
        "GV0aWMifQ.1iQ5fQtI4bpt8XA7a4dO6l-NAsoR5kqamBGMWehufG"
        "c")

def make_client():
    return Client(key=jwt)

