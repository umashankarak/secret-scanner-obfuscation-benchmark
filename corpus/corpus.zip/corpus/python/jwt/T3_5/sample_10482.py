# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIU"
        "zI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJrWjlkMFRHSyIsIm5hbWUiOiJzeW50aGV0aWMifQ.uKhDWoDwfuwTJalKF641lQjvSa_Z-A6vblP"
        "JuwvN"
        "M_I")

def make_client():
    return Client(key=jwt)

