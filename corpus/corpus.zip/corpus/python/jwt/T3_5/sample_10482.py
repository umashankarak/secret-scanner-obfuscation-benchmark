# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJlVHl4elhuVyIsIm5h"
        "bWUi"
        "OiJzeW50aGV0aWMifQ.0UoD1GmteFEDxgruIV"
        "D14Q9Gp02hp8AqQcP5FZ-WeFc")

def make_client():
    return Client(key=jwt)

