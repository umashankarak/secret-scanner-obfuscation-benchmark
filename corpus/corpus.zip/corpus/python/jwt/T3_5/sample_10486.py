# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1"
        "NiI"
        "sInR5cCI6IkpXVCJ9.eyJzdWIiOiJzcUk1Y0pvZiI"
        "sIm5hbWUiOiJzeW50aGV0aWMifQ.wsDF-a3MMnnuIVBWdj5Ba9JKPSWu9qGFbtnWe-jyvjQ")

def make_client():
    return Client(key=jwt)

