# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ5b3VzdXJDcCIsIm5h"
        "bWUiOiJzeW50aGV0aWMifQ.Tu-r6dODMlEpFgEsWIvn41wYBVhebv_Qcx2pr"
        "-CyW"
        "Po")

def make_client():
    return Client(key=jwt)

