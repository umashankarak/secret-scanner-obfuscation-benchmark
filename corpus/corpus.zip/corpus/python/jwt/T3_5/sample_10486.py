# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.e"
        "yJzdWIiOiJLakRyWVJ"
        "GaSIsIm5hbWUiOiJzeW50aGV0a"
        "WMifQ.eRcWEMsOrsGX38h_JmMbn5cCEd0s7NTZV4_jbvzAI4Q")

def make_client():
    return Client(key=jwt)

