# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJIbjhrNGJTQyIsIm5hb"
        "WUiOiJzeW50aGV0aWMifQ.Zj30JrkSu2tvvXfOxLesr_VsIHmo"
        "JMkH_53"
        "FubNKcAM")

def make_client():
    return Client(key=jwt)

