# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJ"
        "IUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ6SzFrbXJLTyIsIm5hbWUiOiJzeW50aGV0aWMifQ.KLapPdNzqWmx"
        "VTB67qe7OumcvIpMUC8"
        "9s4OH4037OiE")

def make_client():
    return Client(key=jwt)

