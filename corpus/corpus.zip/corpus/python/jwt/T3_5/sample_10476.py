# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJzbUFMM2N0VSIsIm5hbWUiOiJzeW50aGV0aWMifQ.LZ8Z"
        "hU2_RKogVhfd1Pe46Ii-HH8Jl2Z-2o8EDbK"
        "D-7"
        "I")

def make_client():
    return Client(key=jwt)

