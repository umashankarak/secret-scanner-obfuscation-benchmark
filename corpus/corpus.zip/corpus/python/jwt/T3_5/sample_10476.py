# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGci"
        "OiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyVXF0eDZPdCIsIm5hbWUiOiJzeW50aGV0aWMifQ.6w8vaMhZ_HUS2qNJdR29mnXofYSX56k"
        "5U4rc"
        "8b3IXmw")

def make_client():
    return Client(key=jwt)

