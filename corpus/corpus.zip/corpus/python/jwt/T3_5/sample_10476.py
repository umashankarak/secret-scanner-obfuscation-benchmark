# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJI"
        "UzI1NiIsInR5cCI6IkpXVCJ9.eyJz"
        "dWIiOiJT"
        "eFF1eWVjdCIsIm5hbWUiOiJzeW50aGV0aWMifQ.n2htL87Jr2NfiltLbYKvdRSDRVegr5ojfin7vF0rHOg")

def make_client():
    return Client(key=jwt)

