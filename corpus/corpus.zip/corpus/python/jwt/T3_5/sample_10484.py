# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOi"
        "JIUzI1NiIsInR5cCI6IkpXVCJ"
        "9.eyJzdWIiOiJDbWFLVDhlSyIsIm5hbWUiOiJzeW50aGV0aWMifQ.hgkW23auT__nvyajnPVdhwm-cd5J4O0"
        "H7khQm4kNQcc")

def make_client():
    return Client(key=jwt)

