# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("e"
        "yJhbGciOiJIUzI1NiIsInR5cC"
        "I6IkpXVCJ9.eyJzdWIiOiJtM1BX"
        "S2tUUiIsIm5hbWUiOiJzeW50aGV0aWMifQ.aLNhpwU6lrXyLPnrdzojfwvwt3xYAB4emXuZCZUU9I0")

def make_client():
    return Client(key=jwt)

