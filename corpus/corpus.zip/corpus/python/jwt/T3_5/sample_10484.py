# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ"
        "zdWIiOiJBQmVPTkt5b"
        "yIsIm5hbWUiOiJzeW50aGV"
        "0aWMifQ.LiT1lW8wVd7CbNzG1TcZXU76P3PCLzUFcQETuHkHZEg")

def make_client():
    return Client(key=jwt)

