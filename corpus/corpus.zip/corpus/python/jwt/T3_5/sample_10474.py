# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI"
        "6IkpXVCJ9.eyJzdWIiOiJJZU9MMXpmciIsIm5hbWUiOiJzeW50aGV0aW"
        "MifQ.Q5NmBWAjO4y2F4VbmT4cl"
        "hrxYJQzbdHo9iS3QZe7Adw")

def make_client():
    return Client(key=jwt)

