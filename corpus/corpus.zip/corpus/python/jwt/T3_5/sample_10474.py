# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJvZkxFdVhraSIsI"
        "m5hbWUiOiJzeW50aGV0aWMi"
        "fQ.L9xpY6uW3EieG5i7QPXuYR7tl2RzDqQX"
        "xx1BHXhvCy4")

def make_client():
    return Client(key=jwt)

