# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5"
        "cCI6IkpXVCJ9."
        "eyJzdWIiOiJ5QVRzd2pkeCIsIm5hbWUiOiJzeW50aGV0aWMifQ.YYzIg3N0gxsjG_GsQ"
        "nBRN4Sg-n-dzfnAAivnihFK-4I")

def make_client():
    return Client(key=jwt)

