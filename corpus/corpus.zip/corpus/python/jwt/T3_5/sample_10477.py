# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJh"
        "bGci"
        "OiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJM"
        "WUZ1dVlUNSIsIm5hbWUiOiJzeW50aGV0aWMifQ.1nKm77abd2p4QleEbWOLmdCOI8XYuQZR2z4XL12DyS0")

def make_client():
    return Client(key=jwt)

