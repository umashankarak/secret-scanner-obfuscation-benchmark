# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.ey"
        "JzdWIiOiJhNUFQUE5iVyIsIm5hbWUiOiJzeW50aGV0aWMifQ.qBmy9wMJ_eb9"
        "ixxw3cyDQasym5Q4oRu9nXysXQUHJn"
        "Q")

def make_client():
    return Client(key=jwt)

