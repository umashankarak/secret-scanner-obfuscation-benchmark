# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1"
        "NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJOSFBUT1l6YSI"
        "sIm5hbWUiOiJzeW50aGV0aWMifQ._W5mPE2ruocE8Wdq5s4FqQu2rY4ZJaN2"
        "OBiE7fRhY8Y")

def make_client():
    return Client(key=jwt)

