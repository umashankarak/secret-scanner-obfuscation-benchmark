# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJXaXFmdGNXOCIsIm5hbWUiO"
        "iJzeW5"
        "0aGV0aWMifQ.mbvOfGNB4ZonLhKNsz1tgVb"
        "JsFlGUguDtD7kfhk8wTc")

def make_client():
    return Client(key=jwt)

