# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.ey"
        "JzdWIiOiJyTm"
        "pabzRnciIsIm5"
        "hbWUiOiJzeW50aGV0aWMifQ.2thMlZYOHGlN1-9Ihz_qG9fWKkDPN6sl1oj6j744oEc")

def make_client():
    return Client(key=jwt)

