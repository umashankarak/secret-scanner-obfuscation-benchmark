# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOi"
        "J2a2tUejlocyIsIm5hbWUiOiJzeW50a"
        "GV0aWMifQ.LGUlH5scv"
        "C3qzWrDdrzbjpqi3Jn6QWJ1rGYEZdueXiU")

def make_client():
    return Client(key=jwt)

