# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ5ZmV1Zmo0SyIsIm5hbWUiOiJzeW50a"
        "GV0aWMifQ.GUPp"
        "w2"
        "UE-QnsypMyZw_W1l2Bghoe5z3clDzrx3gjzyM")

def make_client():
    return Client(key=jwt)

