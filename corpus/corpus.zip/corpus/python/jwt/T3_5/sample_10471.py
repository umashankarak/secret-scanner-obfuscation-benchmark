# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbG"
        "ciOiJIUzI1NiIsInR5c"
        "CI6IkpXVCJ9.eyJzdWIiOiJDTFh5WndyaiIsIm5hbWUiOiJzeW50aGV0"
        "aWMifQ._BN6L0yoN-754vm_nG1O6vRKxezGhV_a1BvEgLqVgcM")

def make_client():
    return Client(key=jwt)

