# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJOSkY2S212WCIs"
        "Im5hbWUiOiJzeW5"
        "0aGV0aWMifQ.VzYa4bMSHHOCue-0WmL5-vD07MQQrLaJ"
        "K8WxvC7FjmM")

def make_client():
    return Client(key=jwt)

