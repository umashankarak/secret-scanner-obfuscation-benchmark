# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ2elVxcGljeCIsI"
        "m5hbWUiOiJzeW50aGV0aWMifQ.uXZ"
        "p6QapJAAiL9Rd"
        "dTkCJEdD8Utnz2Wg13rkTMHXK3w")

def make_client():
    return Client(key=jwt)

