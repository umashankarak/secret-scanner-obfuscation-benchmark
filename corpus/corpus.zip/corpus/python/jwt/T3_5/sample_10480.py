# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJ"
        "hbGciOiJIUzI1NiIsInR5cCI6Ik"
        "pXVCJ9.eyJzdWIiOiJlOFdmdGg0cSIsIm5hbWUiOiJzeW50aGV0aWMifQ.-JCqEGIs2RG6SwYxqx9KBAPyn0cTn"
        "ucLv2eM7K2kDUs")

def make_client():
    return Client(key=jwt)

