# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6"
        "IkpXVCJ9.eyJzdWIiOiJJaHZPYnJYbS"
        "IsIm5hbWUiOiJzeW50aGV0aWMifQ.zH6BLi4WZGuSHjWxp4qnbICfVXYLhuRUl"
        "ora0LTg0N0")

def make_client():
    return Client(key=jwt)

