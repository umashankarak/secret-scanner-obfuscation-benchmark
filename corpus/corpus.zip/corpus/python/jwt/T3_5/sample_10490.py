# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ"
        "9.eyJzdWIiOiJvc2tqR1pWWiIsIm5hbWUiOiJzeW50aGV0aWMifQ."
        "htJIKBnwpguDZuFtKO4-G3"
        "xBPBtCTOcAnhskEqUd5TY")

def make_client():
    return Client(key=jwt)

