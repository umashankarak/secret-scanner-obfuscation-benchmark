# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = ("eyJhbGciOiJIUzI1N"
        "iIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJwW"
        "U5FS2g5NyIsIm5h"
        "bWUiOiJzeW50aGV0aWMifQ.PijubuFhdsyChBoOTnE91W3CcPV_9NGUzI8qTwmwFR4")

def make_client():
    return Client(key=jwt)

