# synthetic benchmark sample -- generated value, non-functional
import os

jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzd"
        "WIiOiJxMlRIeVhJei"
        "IsIm5h"
        "bWUiOiJzeW50aGV0aWMifQ.357XEfoKN5HlQdcUU38zBPf7q7rTJUeQaG5LhYKXKO0")

def make_client():
    return Client(key=jwt)

