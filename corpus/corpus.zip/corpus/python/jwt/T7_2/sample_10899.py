# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=Mme0Z1S5dEcydFNjZ2bTdTYvpGUxcXem52UflGcCdmSJplQ6lTTyFEOVdnLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlGVVZ0RiFVMXVleKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

