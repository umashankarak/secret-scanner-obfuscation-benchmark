# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=QzUqFleFZ1ZodXaGVURlZUc1ITcs9EM2E1a302cudXRKpVQ0plUihkdwcnLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNVY3FVVXhFZGRlTKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

