# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=cGcl5kQyREZQ5mSjNETnF3SaZUQ5RUeNdnbE9UVrhTaCRHUCZFVFREN2NlLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlWYzJlVjVFcWplVKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

