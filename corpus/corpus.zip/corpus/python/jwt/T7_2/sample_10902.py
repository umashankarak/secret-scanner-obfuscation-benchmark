# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=k0MyokWfVlTH9EbwdmQOZXYHpGM21WSQp0SrlTaQhUa4kDUXNmSpZDV2JjLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlmU3pkeiJlWFVFbKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

