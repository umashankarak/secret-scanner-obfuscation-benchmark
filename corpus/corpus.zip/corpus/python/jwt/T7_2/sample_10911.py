# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=QTdZNWOpJUN3oVa2cGWXV1dK50c4g2V2cEUnpEaURkWk5GOfR3XSJHRyllLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlWVC5UMOxmSFNVTKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

