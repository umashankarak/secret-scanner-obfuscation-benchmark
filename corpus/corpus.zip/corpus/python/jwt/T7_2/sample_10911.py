# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=MnUwN3YJ9GUHh3b3NWMSpXWw8UTCNjNLpldj9lVnlnQ3AjYHZUOydFOitmLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNVY0UEWNREbFd1MJl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

