# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=M2UxM3Yo5mUotUdklWW6hDZtMXbSFERttUQ6p1NDREMs1Ec4olc2pFZwBjLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJN0VsRmea9mUYF1MKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

