# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=EkRHVlYykke5Ala4YGRSlXYYp1UNRUOQJXbKRHR3MjUfZnU15mW20GdYBlLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlWYopkejJHbUVmSKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

