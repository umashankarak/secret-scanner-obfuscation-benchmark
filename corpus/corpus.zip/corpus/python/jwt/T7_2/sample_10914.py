# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=E0ZIJldKdjN4d2Rn92M4ATQsJnVO12T5EzNEdXMzRGTIN3ULZ1byZUNyknLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlnUCZFbSNTRup1cKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

