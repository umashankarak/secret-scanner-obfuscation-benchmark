# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=QDOPZHTjVDUflGVPx0V1E3cTJTVSl3Ns9Gb48Fe61iNLJzZ3JUcyAzZHdkLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNVWRFzaXNTNw4EUKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

