# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=MGShJVWtVDSOBTL3c1R0JGcIxWcM1mUoZ0TjNjdn9EcElVcrVVepVFZ5UlLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJN0Y0EzVO9EaXZlWKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

