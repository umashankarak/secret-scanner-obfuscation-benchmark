# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=QzULVkShZDOnNTb2QDVRNTa3pGT0RUSFlke0J3XyJzZWN1ax0US5djWURjLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJl2V6VTRUNTUqJWcKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

