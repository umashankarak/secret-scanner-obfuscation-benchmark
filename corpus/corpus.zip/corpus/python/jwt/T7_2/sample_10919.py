# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=UkNQNXd2pXMCZmT4kTNGBXMZlDdUZHRsd0YfZmaTF1NpJjW1Rlb5xWR0kkLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlWZzlTVUlmW610dKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

