# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=MmdsFkWSNUa5VTYrJWTvR2c2M1NJZWUmNlNjhzZtkmSPx0d1UkbjZTQ24kLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNUZDZFMRJzbG5kUKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

