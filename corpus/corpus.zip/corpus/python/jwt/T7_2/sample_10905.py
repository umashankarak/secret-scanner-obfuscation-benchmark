# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=QDMPlHZ1gVLaVHSPp0cHhmWxdGapRnR2s0Til2YjdVaahneJdEMFlUUQBlLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlXUJhXVOpHNtVVVKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

