# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=gDbTlUcVVlVzlHRsV3QflkSwM0aX1EbE9kYoFkWBlVRGZWb08WOD91N2xmLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJl2UE50MVRjVY9keJl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

