# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=82X3o3aol0ZDVUalhTcvFTZ3Mnd29lUhpkMsh0dFBlSmBTVOZXWNlnWatmLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlmWy8mVhxkUqNWdKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

