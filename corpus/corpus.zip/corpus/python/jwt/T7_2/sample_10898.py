# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=gTNGBXMZlDdUZHRsd0YfZmaTF1NpJjW1Rlb5xWR0kEbxk3bhF2Z2YmeEFkLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlnYxc3RhlnRsF2dJl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

