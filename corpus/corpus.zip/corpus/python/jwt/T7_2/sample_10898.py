# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=M3d4VGTxdXYLJWZVBVW0hXSvRXe1RnNSB3dY9mZ2kHSsRHTjVkU3wmVvJjLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNVTqZFWNVXMtd1UKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

