# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=E0dP52M51yYVVUcrVEdjJnMMR2Qml0MH5UNplWR0BnN4EjSLJ0S381ZDZlLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlGZ04kbZJlQspFTKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

