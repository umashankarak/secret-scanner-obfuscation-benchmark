# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=kVUa9lRQZkZ1BTV59VS6NlRtMkbMN3bnVzdC5EcUtGTfpWNI9GdpBTRzImLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNUT04URVJjRr5ETKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

