# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=UETDRzVMtGbNlDWKRVW2FFcxJndFF2RhBHMWtmMP1GS6FHO6p3a2J2YwhjLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNEZSZFWTpHaXJlcKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

