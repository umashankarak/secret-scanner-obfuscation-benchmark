# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=k1QlhWZFdEU5d1SB5WWF9UU4BnUsp1YMZnbOhXaQNWQZ1iaTZGcaNFS6ljLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlmTOpkVllHZWNVWKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

