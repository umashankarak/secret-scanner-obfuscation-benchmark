# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=MXN4BjTMVzNERUc11Wc3ckYo1UNQFVUYxkU6ZXM5hHV6tGN5M3MMBHNUhnLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNkTzk1VZNTQsF1MJl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

