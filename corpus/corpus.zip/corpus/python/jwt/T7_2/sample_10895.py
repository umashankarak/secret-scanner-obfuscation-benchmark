# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=c3NGJ1VzoHNPdFaSNzU2QkQ5oFOWBTN1FHTtJnbVZ1d2NXQnRWUih2U3RkLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNVUykVbjNHatNVaKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

