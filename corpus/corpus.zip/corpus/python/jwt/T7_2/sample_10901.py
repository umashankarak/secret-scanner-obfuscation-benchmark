# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=c3S1QGMMR1Nz0EN0l1cshUSWJ2VztGR2oHavxEdwVld38kew02dxFHerhlLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlXWDFjMOBTRqllUKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

