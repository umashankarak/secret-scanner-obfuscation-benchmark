# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=gjcoF1aFl0cSJVa0JDe552YzlUZQpWePl0VhBVe0UWLBRHV58GM3BjNZhlLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlmWR50MjNzatR1MJl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

