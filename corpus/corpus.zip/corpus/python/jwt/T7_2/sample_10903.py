# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=MGNBR3XjhlS2wGUXBDajdkWyYEO3lHaHpFM0MXeUJlQKhjTBZkQahETrBlLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNlU6d2Rkl3cw4URKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

