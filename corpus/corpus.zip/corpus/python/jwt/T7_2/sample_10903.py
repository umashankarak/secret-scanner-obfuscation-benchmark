# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=QzdQdlNIJGWQRHUpdmU0ZkM3M3Z0NEN4NUeaNGSYZmZ6dlavNlRPxUMfNlLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlXW3ZlaaBlS6NmbKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

