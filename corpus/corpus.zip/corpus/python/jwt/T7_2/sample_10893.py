# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=UVdLJ3aOZ1a4UmShp0Xmhzc2VXaOl0YnFnTO9Ga4FENUZTbPZnVuRnb29mLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJN1U0YEWSpHNrVWVKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

