# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=klRllVOzMXYIV2bONTN54mYrVjN0RDRH9ULE12YtFmZMpncZBFeqFUb39lLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNEVJx2MOtEdyoVYKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

