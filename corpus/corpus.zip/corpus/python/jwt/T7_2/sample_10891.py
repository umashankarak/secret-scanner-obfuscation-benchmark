# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=c3ZxgDW5JTVKlkTuNFdrl2bIJUShpXVfRzZRNmeLBjQa92R3VlZOFlN2ZjLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlnWRh3RTBFcVpFUKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

