# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=E0MygGWOdET6p0dC1WYKVXew0yazpmeh1UeJhkYupGdVlmUjp0aVVWSNVkLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNUYGZEMhdVOFdVeKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

