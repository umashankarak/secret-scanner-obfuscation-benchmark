# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=kVTSt0N1JVcHNVd2w0My9VZjJkSNpWQoFlafVDSMZDUuBXY5I2UVllcRFjLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNFZNFTbShkUt5kaKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

