# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=s2dD1mbxREOhpGe1gleK5UelZWbaF1cxNlVvt0d3d0dshTUZVUV1RWMCNkLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlXV1ATVNxWMwQFcKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

