# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=U1RmVmQExmM0UmR65kVwIUQR5GcYZkdylFU6hDNzhzdylTO6R2Ryd0MhhkLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlWV6pFMOpXQEJlRKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

