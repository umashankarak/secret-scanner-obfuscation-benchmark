# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=gzSjFzRzxWYKJHdZV2MTJUQXN0QhN2QTxmc4kXdFFURGZ1ZE90byQHN4djLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlXY4h3RjdFZtRVNJl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

