# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=8WUHZWMZRERUVUWORHefpVTrxGO1Aja1YDUatkW5pUdytGdZVzX5A1UMJmLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlXU5JVbOpFZINGSKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

