# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=kkdvd3dolHU15mZnFHTJlURvJzZFl1RuVnUulGa1YkUxdDMxd3Y4QTdHplLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJl2Y5FzVTJlUU9EeJl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

