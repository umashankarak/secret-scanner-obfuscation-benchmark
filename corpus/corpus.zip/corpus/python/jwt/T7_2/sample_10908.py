# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=82d3IkN0EUaBNWRId3atUmaGlEe1VWYfVjdXl2dxRjc4MWO3ETa05kNlJmLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNkV6R2RWNFbUJ2MKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

