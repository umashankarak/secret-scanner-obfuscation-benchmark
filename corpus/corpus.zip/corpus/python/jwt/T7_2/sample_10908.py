# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=MHbfNlUoNlWwYTYChXZ0JzSPVzYsN3btJ1didVZBpUewJ0Yi92aKt0TZlmLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNVWxpFSONjTGJ2RKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

