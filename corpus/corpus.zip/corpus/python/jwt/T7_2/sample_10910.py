# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=sGNMFGSyE0Z6tkdoJnNYNUNlVnbTNka2h1TDZVc4AXOoNFWa52NqtmdtJlLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNVTSJ0MRllVqRGbKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

