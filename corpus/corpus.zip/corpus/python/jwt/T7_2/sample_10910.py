# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=k0clpVdwgGdxBDcEBlZnJHNxpWTIR3c24mQqBjTCJXZnN0MRFXVsljR2VlLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNVZshGMVBzYYpVeJl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

