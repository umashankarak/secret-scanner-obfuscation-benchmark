# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=MHNYREbzMzYldFdBl3UGJ1Mzd1atUkeXN1QZ1icwd2MYd0NtpVUtN3V5UlLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlWZGZFWWFHaHRlaKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

