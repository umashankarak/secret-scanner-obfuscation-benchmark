# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=M3TyZHM3JmaKpmb6VDNHBjd0oGWt90VldULFJVVtlGMtIFO00EaRNTQkdlLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJl2YtlTbWJjQsd1cKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

