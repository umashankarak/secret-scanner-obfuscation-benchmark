# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=ATONVWcWhFe4gVO3QHchlmYQd0V58VVy1iYuRXLRZFMx4GZ4ZER0M3M1BnLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNUYXljMTpHMFNFdKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

