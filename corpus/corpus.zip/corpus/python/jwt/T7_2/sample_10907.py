# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=E1T2gDOx9lMHVXMipXd5F3dU1CRycVQtI3NYhDW0V1ZDlTcTdmM3JUZURlLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlXYhBXRjlXVW5kMJl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

