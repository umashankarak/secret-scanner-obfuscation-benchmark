# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=gTVrhUOfFlcYdVaLhENwJETLRnSwJVcLZFVL1yVqRXR4U3dQd2VOtWemNmLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlWWx4kMiFGarNVNKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

