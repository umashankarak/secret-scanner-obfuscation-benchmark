# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=k0MxlzUudHS5RnUUV3bJJlYx9kZkl2UnlXLQ9WUsZFZwtmQyN1SGFVcRdkLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNUZLJlMWlHbIRmbKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

