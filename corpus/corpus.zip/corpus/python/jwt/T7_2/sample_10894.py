# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=0EW3pGRTVFOyNVSWl2VW1idvFzRzZHUHJmd6hmSQ1WQ5pGaYt0NuZXURhkLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlXUwoEWZBlTWFWTKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

