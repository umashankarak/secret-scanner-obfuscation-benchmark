# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=E0TCRUby9mVRhFdlx0UVZHWoVzd3kkQSFFd0EHa0VndrVnQkV0S4hTMwokLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlnVx50aNhVOtJmdKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

