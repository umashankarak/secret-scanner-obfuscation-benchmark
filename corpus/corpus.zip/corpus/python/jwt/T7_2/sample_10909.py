# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=gDetNGax0WMphGdst2cvZUM0E0SNJlQz0UUVVWctRHcpRjVIpGSnBjSkhjLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJl2U4JVVTNDbE1EUKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

