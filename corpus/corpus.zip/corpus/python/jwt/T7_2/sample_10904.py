# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=k0NwUmZyl1VPhTdwEjeNJHMNh2M6FWbPpkU1UFTTJVTCZ1XK5WNXN2d5YmLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJN0UJxWRaFlSUd1cKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

