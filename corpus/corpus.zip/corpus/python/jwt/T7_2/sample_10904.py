# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=cGV3YDREBDMV1SV1MWeF1mZ0IlQQdkQyAHTysWQ4MVTWlmNspla1gmcSFmLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJl2VMZ1RNpXRtVFeKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

