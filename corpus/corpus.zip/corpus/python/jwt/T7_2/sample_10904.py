# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=kUM1E1b5pVUtdGOElHbURnMsp1XPlVNvJkQqNWZw8GcVtmSmlEaVRkRYFlLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlXYwQ3VZNlVykVdKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

