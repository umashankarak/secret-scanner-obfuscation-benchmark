# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=kUTw4EVT1SaiNzRLRkZaRnU30SV3UnZ3oVQmFTUxcFcZlHVtVWLzEWVOhmLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNVWxpFVWd3ZE9UWKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

