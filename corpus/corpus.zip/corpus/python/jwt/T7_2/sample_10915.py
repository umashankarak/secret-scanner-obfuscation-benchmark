# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=8WZtZ3St1SRKhTaHJHUhdGa0M3ZzgHZzklbtZWbqV2QjJVMlNDMFhjR2QjLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNVWDBXMhBzYGN1aKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

