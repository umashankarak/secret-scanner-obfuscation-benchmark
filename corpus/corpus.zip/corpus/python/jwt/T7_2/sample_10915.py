# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=M2Q3YWSEJzb2UGe3A3VPN0TZJEZqZEOGB3ZTNzMolUVzpVZSh3Txh2aktkLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNFVUVzVhNnSxQFWKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

