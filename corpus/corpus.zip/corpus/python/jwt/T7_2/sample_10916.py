# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=cnai5UVtA3cR5EdtdGWvhEa4p2csN0dKdEaEV1YhVlWHNTe3oFVzRDRIFkLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNlTLJERUZjQUJWNJl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

