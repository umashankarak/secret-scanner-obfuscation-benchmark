# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=EldIVnahdXbIV3X5pUTWF3Qll0QyhVM1IETwsWemhWeZlFVHFGcyR1aRlnLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNUVCVzRONlVqFVMKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

