# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=gzQwFjSqJTa3R2NohHbTh2bxFTUjhGSJ90U3gXbadlQ50iMItWRKFWeEdlLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlXV1I1MRFXNyEmTKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

