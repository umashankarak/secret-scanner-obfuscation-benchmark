# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=U0cG12MKNzXwoUVhR1RChVN5VDOSF2M5VmQ2NHdu52aWpHcPplRzVzcxgmLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlWVUx2VhlFaEJVVKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

