# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=c2TJJld3lzXwF2YCV3QKxGbQRXLtwUd6lFexZnetMUe6R0MnFEbDN3aklkLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNlUIxGWNdEctNVdKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

