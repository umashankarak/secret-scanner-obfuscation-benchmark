# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("=U0X2Njb2YWcjdVbwMWMxplNohjYHdEOwMWd3c2SWZFc0llTFFDWwZnVfhnLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJl3YRpFbkhmQxEGdKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

