# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=MmVBJDTzlkafFWd3VGMzkHd5RFT2BnM0UFNlVGO3AlSnhlSr5UaBhVLWFmLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNlU250MTVzbyMGcKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

