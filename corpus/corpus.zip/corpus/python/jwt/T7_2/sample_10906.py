# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=gTSsZHTQ1GbOBFMyk3dRJkV3R0UudFS3cHSM1mU5IGdkR3co1GMWhVSLpmLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJNlWVVDMWFjUVNmSKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

