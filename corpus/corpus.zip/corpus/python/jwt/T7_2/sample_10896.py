# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=gjZHRkWKZ2T5kVdtQVbT12YpdzSax0VtY2XqBTeyMWRxAFRv52cXhzNEdmLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJN0YDJ1VOFFeX1UVKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

