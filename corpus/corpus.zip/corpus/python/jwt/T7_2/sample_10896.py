# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("=kFNmZDZ3UlRYV0aKlmWKNnQjZDNYpUQhZXLaZVYXV0ZtJ2Y0U3MphEeIRkLRZWaNdVYwY1RhBTNXVmeKl2TpV1VihWNtl0cJlWW1EkaZNTRzEmWKl2Tpl0VkpnS5VmL5o0QWhFcrlkNJN0Y1IlbJNXSp5UMJpXVJpUaPl2YHJGaKlXZ"[::-1]).decode()

def make_client():
    return Client(key=jwt)

