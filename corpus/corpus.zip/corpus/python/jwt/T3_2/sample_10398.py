# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJFeVNPNU", "dUNyIsIm5hbWU", "iOiJzeW50aGV", "0aWMifQ.YkH2DGAs1n3xt-ecS69VZJicAwfmaRjWu_FoLAGEAkQ"])

def make_client():
    return Client(key=jwt)

