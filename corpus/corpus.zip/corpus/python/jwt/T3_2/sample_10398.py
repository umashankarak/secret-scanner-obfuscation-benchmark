# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI3U284TUJQW", "SIsIm5hb", "WUiOiJzeW50aGV0aWMifQ.aiGJjYwj", "slojUITXwY0nRVlPcdOmCdDH319p4t-kwv4"])

def make_client():
    return Client(key=jwt)

