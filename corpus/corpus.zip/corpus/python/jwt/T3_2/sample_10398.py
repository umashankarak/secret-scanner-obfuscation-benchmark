# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["e", "yJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJYTnhYUGtBRCIsIm5hbWU", "iOiJzeW50aGV0aWMifQ.Agy5DIfmiqz55GxZQpgt", "ndDwJbMZxZE2okyo7aOODTw"])

def make_client():
    return Client(key=jwt)

