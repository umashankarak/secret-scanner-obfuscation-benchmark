# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["e", "yJhbGciOiJIUzI1NiIsInR5cCI", "6IkpXVCJ9.eyJzdWIiOiJibDF0V0NQRyIsIm5hbWUiOi", "JzeW50aGV0aWMifQ.nmcL9FcgE8jgj8EBHycEA39ZCY-hIz4XDZBSd7T6ZV8"])

def make_client():
    return Client(key=jwt)

