# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJ", "hbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJiMTYzbmF6dSIsIm5", "hbWUiOiJzeW50aGV0aWMifQ.Ay-I-DKLdVd_v6E3pPhKAGDvcp", "H01MRxonzcll1BuLM"])

def make_client():
    return Client(key=jwt)

