# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJTT3", "ZkVEt", "LOCIsIm5hbWUiOiJzeW50aGV0aWMifQ.usPwGxEL-awCA0Q9xGMsTCK3Hyqodp7i5BxaJ", "ioPeME"])

def make_client():
    return Client(key=jwt)

