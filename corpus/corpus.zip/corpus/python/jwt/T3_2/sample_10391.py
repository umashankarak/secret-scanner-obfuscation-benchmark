# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.ey", "JzdWIiOiJD", "SjE2MzhHMCIsIm5hbWUiOiJzeW50aGV", "0aWMifQ.XgAOFhBRw6hzN6NkLoXVShX-Cv9U3Lnfb-JATgpNk7w"])

def make_client():
    return Client(key=jwt)

