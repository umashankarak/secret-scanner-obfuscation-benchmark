# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["eyJhbGciO", "iJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJzbXRKcWNPViIsIm5hbW", "U", "iOiJzeW50aGV0aWMifQ.5X_zvFrPGEcwWEZAXc6gbESW_oAwKT_N7gk3c-Xklog"])

def make_client():
    return Client(key=jwt)

