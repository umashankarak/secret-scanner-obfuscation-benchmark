# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJRbnY5UjN5dSIsIm5h", "bWU", "iOiJzeW50aGV0aWMif", "Q.A3tU9SRDEhwMIinxfGwYLrxBH5V6MQgNZ124ekR-oS0"])

def make_client():
    return Client(key=jwt)

