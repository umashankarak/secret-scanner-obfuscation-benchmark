# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJBRmxFOWR6R", "iIsIm5hbWUiOiJzeW50aGV0", "aWMifQ.2GJmGSXpuRCHjfPhKZSLxqprALLxd", "RX8GnHmXrOji54"])

def make_client():
    return Client(key=jwt)

