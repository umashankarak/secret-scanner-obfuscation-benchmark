# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdW", "IiOiJ0VzN0MURLMiIsIm", "5hbWUiOiJzeW50aGV0aWMifQ.", "JRTyFLT0Fm8Ll7m23BjS_cv4ERV3gbFRny8TTUYkHSo"])

def make_client():
    return Client(key=jwt)

