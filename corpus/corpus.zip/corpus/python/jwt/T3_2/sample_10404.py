# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJLS0x3SkJtdyIsIm5hbWUiOiJzeW", "50aGV0aWMifQ.HKutI1sofA6mXCSsV7", "r", "VCfpuDeKuri0oP9MTNJSx4k8"])

def make_client():
    return Client(key=jwt)

