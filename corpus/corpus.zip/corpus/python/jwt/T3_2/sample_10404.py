# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJI", "UzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ", "kY0N0RTAzcCIsIm5hbWUiOiJzeW50aGV0", "aWMifQ.ZdAlw75mStebQUuk6sclA-NQf6BLaEp1ghfSCS_kwBc"])

def make_client():
    return Client(key=jwt)

