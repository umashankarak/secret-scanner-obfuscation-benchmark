# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.", "eyJzdWIiOiJnVXB6V3lvTyIsIm5hbWUiOiJ", "zeW50aGV0aWMifQ.-GBn", "Fvh3JvMkCgAY0EYdkeTYAwV2-MoQ2UPwHp8FsHc"])

def make_client():
    return Client(key=jwt)

