# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ5MVpWVmFKdC", "IsIm5hbWUiOiJzeW50aGV0aWMifQ.dTI81sg7QnTUvDT9yxiUfjuwxx8638YWUqWoFDrBU", "R", "I"])

def make_client():
    return Client(key=jwt)

