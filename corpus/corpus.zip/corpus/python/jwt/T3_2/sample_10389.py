# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJOd2x2dFZmTiIsIm5hbWUiOiJze", "W", "50aGV0aWMifQ._jRWI7wcEu", "yzPRCk3XCMZvi38kkLlm4PU3gWbYaTBfI"])

def make_client():
    return Client(key=jwt)

