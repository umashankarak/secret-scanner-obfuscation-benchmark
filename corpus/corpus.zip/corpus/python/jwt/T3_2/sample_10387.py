# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIs", "InR5", "cCI6IkpXVCJ9.eyJzdWIiOiJ3anFlRXFlRiIsIm5h", "bWUiOiJzeW50aGV0aWMifQ.FAc6rfyPjwA-pDLdDL_vbtGN4myzv5CQyqxIGuQ2J1w"])

def make_client():
    return Client(key=jwt)

