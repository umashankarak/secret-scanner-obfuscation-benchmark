# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["e", "yJhbG", "ciOiJIUz", "I1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJOb0J5U1FTZCIsIm5hbWUiOiJzeW50aGV0aWMifQ.hhxzKIFIBQJ3qQOW3JrWv-bNnkUJGvrv7D5RO3_ulD4"])

def make_client():
    return Client(key=jwt)

