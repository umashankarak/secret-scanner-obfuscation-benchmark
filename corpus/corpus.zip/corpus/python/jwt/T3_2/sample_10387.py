# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1Ni", "IsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxTUU1NW91RiIsIm5hbWUiOiJzeW50aGV0aWMifQ.vitrPzfR", "GLZK", "Kzgs2-hGNtiUTIBZh2fOHJqpPSELby4"])

def make_client():
    return Client(key=jwt)

