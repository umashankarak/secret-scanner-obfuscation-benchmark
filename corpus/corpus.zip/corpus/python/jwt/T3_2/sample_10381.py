# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["ey", "JhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ", "1WUZLMkluNiIsIm5hbWUiOiJzeW50aGV0aWMifQ.kbt", "tqZ2IbXpEsSqbEt6mZxYhXNjM8Q8QDt3hcwNtIlw"])

def make_client():
    return Client(key=jwt)

