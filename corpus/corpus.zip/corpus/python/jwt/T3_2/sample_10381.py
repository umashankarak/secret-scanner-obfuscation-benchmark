# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiI", "sInR5cCI6IkpXVCJ9.eyJzdWIiOiJJSHJ4Zn", "RnUiIsIm5hbWUiOiJzeW50aGV0aWMifQ.VrnLI1W_iDtFhzeHy1G6dAs3jFSg", "QDAOgDYj71mC5ag"])

def make_client():
    return Client(key=jwt)

