# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbG", "ciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ2alpHMUozVCIsIm5hbWUiOiJzeW50aGV0aW", "MifQ.LVSAdVToT40QPk9DhlQO4WPyc_cm7SYI", "syTd0BeDuCo"])

def make_client():
    return Client(key=jwt)

