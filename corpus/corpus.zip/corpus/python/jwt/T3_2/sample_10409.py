# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJUblYyMkhtc", "SIsIm5hbWUiOiJzeW50aGV0aWMifQ.W1fW3-gJc-tSEIpE1JSG9beM", "Zxj", "C4VyatJBKe8FoacI"])

def make_client():
    return Client(key=jwt)

