# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ", "9.eyJzdWIiOiJlaG", "wxNnFDdCIsIm5hbWUiOiJzeW50aGV0aWMifQ.Juv5EJREaT6U9Ly2CeOAsRogi", "IwJhBCn0aOlrtSk-6Y"])

def make_client():
    return Client(key=jwt)

