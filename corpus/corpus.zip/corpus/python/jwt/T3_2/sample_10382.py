# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJFeUdZNjRrRiIsIm", "5hbWUiOiJzeW5", "0aGV0aWMifQ.wWVM1EwgEOoxZs7fiMvZ3e2QeqWtFE", "wuZmEbcbAyKZE"])

def make_client():
    return Client(key=jwt)

