# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cC", "I6IkpXVCJ9.eyJzdWIiOiJ", "OaGlUVnNXUCIsIm5hbWUiOiJzeW50aGV0aWMifQ.rJh_g2b8_wEpRinAp8l6UxwTq66", "HqIV7eqKGc-CC_Tg"])

def make_client():
    return Client(key=jwt)

