# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIi", "OiJkMWdpTnJoUSIsIm5hbWUiOiJzeW50aGV0aWMifQ", ".SD_iXX", "80q0-1P_9EPe0xjH3HemCn2F8zcVWgkEg9rIk"])

def make_client():
    return Client(key=jwt)

