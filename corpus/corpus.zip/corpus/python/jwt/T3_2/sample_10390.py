# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxTWZOd2tP", "TyIsIm5hbWUiOiJzeW50aGV0aWMifQ.b49X9wjBsj_XmGgSL5vC1R2B1H", "-lYERSP4RG", "3gVD5L8"])

def make_client():
    return Client(key=jwt)

