# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbG", "ciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJENmRtaDR", "iNiIsIm5hbWUiOiJzeW50aGV0aW", "MifQ.YVvDtI1tBwVLnZ21WKw1ftfH2jqCxa3y8f-b3NVFfmU"])

def make_client():
    return Client(key=jwt)

