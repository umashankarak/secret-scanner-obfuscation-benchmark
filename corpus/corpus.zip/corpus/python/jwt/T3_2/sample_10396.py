# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1N", "iIsInR5c", "CI6IkpXVCJ9.eyJzdWIiOiJOblNiV", "DlHOSIsIm5hbWUiOiJzeW50aGV0aWMifQ.lGXNKHjYQRP4XEw6hBtVdBrqKmWZf4OAhj6TZRhLWug"])

def make_client():
    return Client(key=jwt)

