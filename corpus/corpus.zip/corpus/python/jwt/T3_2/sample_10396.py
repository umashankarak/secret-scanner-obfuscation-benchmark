# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.", "eyJzdWIiOiJpdUJpWmZZUCIsIm5hbWUiOi", "JzeW50aGV0", "aWMifQ.ZzXSphACVjqPOFBCCRblw9BpohpyNYLeyE4NVN3E19A"])

def make_client():
    return Client(key=jwt)

