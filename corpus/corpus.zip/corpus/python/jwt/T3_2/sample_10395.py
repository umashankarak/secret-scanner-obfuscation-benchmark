# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsIn", "R5cCI6IkpXVCJ9.eyJzdWIiOiJOeDlCNmdTViIsIm5hbWUiOiJzeW50aGV0aWMifQ.", "qix5JDdO78vaJfOvZoNiuB", "oguplobjppATSKN3-T9UE"])

def make_client():
    return Client(key=jwt)

