# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6I", "kpXVCJ9.eyJzdWIiOiJOenIxeU5XSiI", "sIm5hbWUiOiJzeW50aGV0aWMifQ.5dichuaXS", "1aafmR1q8cG8968sevgYo_39SEAJilHXC4"])

def make_client():
    return Client(key=jwt)

