# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJh", "bGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJlaUVWMFA5QSIsIm5hbWUiOiJzeW50aGV0aWMifQ.FVMslXa", "EI2JlSrDmg3Mc5q", "BNk1QF0Bz05XNzR4_2K_E"])

def make_client():
    return Client(key=jwt)

