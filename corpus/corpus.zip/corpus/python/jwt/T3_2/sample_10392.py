# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXV", "CJ9.eyJzdWIiOiJTODlHREh", "4NyIsIm5hbWUiOiJzeW50aGV0aWMifQ.9PtBh0tA1D", "DECz9jO6HpIZ5hTEmkO3rba3MBjwA9ZEg"])

def make_client():
    return Client(key=jwt)

