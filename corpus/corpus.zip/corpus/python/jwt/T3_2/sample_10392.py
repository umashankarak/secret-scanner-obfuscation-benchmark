# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["e", "yJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJrcm", "J0cElPeCIsIm5hbWUiOiJzeW50aGV0aWMifQ.kMdXVSU1Wx9gLckcVa_y2QWTlw0kj1hyaJjf-", "ClQyrU"])

def make_client():
    return Client(key=jwt)

