# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.ey", "JzdWI", "iOiJhWTUzN2xYZ", "SIsIm5hbWUiOiJzeW50aGV0aWMifQ.uFXPBfiCCySwEDS-AekNReJ5dMSqAdTdOLIarir_1Z4"])

def make_client():
    return Client(key=jwt)

