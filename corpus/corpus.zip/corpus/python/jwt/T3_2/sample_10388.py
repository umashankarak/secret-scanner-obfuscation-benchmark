# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJI", "UzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIi", "Oi", "JraHVkYmNFYiIsIm5hbWUiOiJzeW50aGV0aWMifQ.As7ptJ3gZToaOsTdXhcnQ0iV9WSQs9tgwdkmBehjVyg"])

def make_client():
    return Client(key=jwt)

