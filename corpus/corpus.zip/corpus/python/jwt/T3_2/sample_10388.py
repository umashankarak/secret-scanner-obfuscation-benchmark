# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6I", "kpXVCJ9.", "eyJzdWIiOiJHQ24yeUc5YiIsIm5hbWUiOiJzeW50aGV0aWMifQ.lxALA0pdAK", "IOibmy5wQdeXD5ybbYe0YbrUQpzX59Sgc"])

def make_client():
    return Client(key=jwt)

