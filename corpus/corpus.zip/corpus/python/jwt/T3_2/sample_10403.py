# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciO", "iJIUz", "I1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJxWUNYQ3p5NSI", "sIm5hbWUiOiJzeW50aGV0aWMifQ.LD2Es7oGFJ-cH5V9i3ar3luwj4VnoRAwsewIRCpwJgk"])

def make_client():
    return Client(key=jwt)

