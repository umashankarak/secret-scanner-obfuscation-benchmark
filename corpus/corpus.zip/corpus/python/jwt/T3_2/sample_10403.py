# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJz", "dWIiOiJiS2NodnVnMCIsIm5hbWUiOiJzeW50aGV0aWMifQ.46i35", "DdNJ", "Hxk9h-MJikpCiuXKkNF5BNUbPtBqrOKmPg"])

def make_client():
    return Client(key=jwt)

