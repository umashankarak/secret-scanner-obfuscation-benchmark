# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ", "zdWIiOiJOWUY2ZmNNaSIsIm5hbWU", "iOiJzeW50aGV0aWMifQ.tOURVX1n1e7081SzE-YA81MCkBfCmWenS0", "Q3xQ0uAas"])

def make_client():
    return Client(key=jwt)

