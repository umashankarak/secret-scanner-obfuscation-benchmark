# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["eyJhbGciOi", "JIUzI1NiIsInR5cCI6I", "kpXVCJ9.eyJzdWIiOiJDcmxWUXViQSIsIm5hbWUiOiJzeW50", "aGV0aWMifQ.eSfCAPEU5IJ-N_9eSS2KzRCB8-K48ALzDR62DO-IXwI"])

def make_client():
    return Client(key=jwt)

