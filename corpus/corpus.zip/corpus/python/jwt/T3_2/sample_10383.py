# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsIn", "R5cCI6IkpXVCJ9.eyJzdWIiOiJwaDRtRXB5dCIsIm5", "hbWUiOiJze", "W50aGV0aWMifQ.ko_-Z8cY0uq2FvPs8HCh8UqPrSpBq5HMA9Ch-Gl2_LY"])

def make_client():
    return Client(key=jwt)

