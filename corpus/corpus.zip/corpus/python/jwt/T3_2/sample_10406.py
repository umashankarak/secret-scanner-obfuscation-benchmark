# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWI", "iOiJOTFQwWll1aiIsIm5hbWUiOiJzeW50aGV0aWMifQ.cii", "wk5OX", "IbASDVat0cXTAFjo76Ery9ez2KADsV4tp4s"])

def make_client():
    return Client(key=jwt)

