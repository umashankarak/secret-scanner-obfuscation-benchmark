# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiO", "iI2Y1", "BxcU5", "sQiIsIm5hbWUiOiJzeW50aGV0aWMifQ.fLtXhJgXhkhAwgPvznyfcfxXSlY-TpYu3d-V-s9q2rY"])

def make_client():
    return Client(key=jwt)

