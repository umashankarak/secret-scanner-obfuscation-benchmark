# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiI", "sInR5cCI6IkpXVCJ9.eyJzdWIiOiJMM2liS1ZxbyIsIm5hbWUiOiJzeW50aGV0aWMifQ.2oaCON3An", "XZDUcTsOtrAmCehPNYQQF", "iXXE6xRczfU-U"])

def make_client():
    return Client(key=jwt)

