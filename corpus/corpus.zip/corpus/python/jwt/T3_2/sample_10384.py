# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["eyJhbGciOiJIU", "zI1NiIsInR5cCI6IkpXVCJ9.eyJzdW", "IiOiJSUU9sRjAzUCIsIm5hbWUiOiJzeW50aG", "V0aWMifQ.W8lowQSCDNxnE8p8SRLHgnLi7TS2XmBsVEWWxaFTadA"])

def make_client():
    return Client(key=jwt)

