# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjcklTVHY1dCIsIm5hbWUiOiJzeW50aGV0aWMifQ.JcZP1f", "TyUdAF6s_Y9T", "QAdXWrG2", "qd0CuzVTImkFOwOCA"])

def make_client():
    return Client(key=jwt)

