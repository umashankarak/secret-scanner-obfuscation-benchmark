# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ6Uk5id1hMSCIsIm5hb", "WUiOiJzeW50aGV0aWMifQ.nSEi8jkVQT_94vKw7", "b", "zleTL44k_AqpywNXwqd4ZpCrU"])

def make_client():
    return Client(key=jwt)

