# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjUWFMNU9vZCIsIm5hbWUiOiJzeW50aGV0aWMifQ.sLGA-", "US", "driBqcXUYV", "SRfkZzLcYnyoowOOZWYdCeAPRc"])

def make_client():
    return Client(key=jwt)

