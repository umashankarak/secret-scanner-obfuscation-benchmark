# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1N", "i", "IsInR5cCI6Ik", "pXVCJ9.eyJzdWIiOiJXMDVXbWhIZiIsIm5hbWUiOiJzeW50aGV0aWMifQ.C9cFIDNC35YxL61-mydSbPRJ5sT1AqUdfGXlozNMDmo"])

def make_client():
    return Client(key=jwt)

