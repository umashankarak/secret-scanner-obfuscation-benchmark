# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOi", "JIUzI1NiIsInR5", "cCI6IkpXVCJ9.eyJzdWIiOiJkM0U5dDY1UyIsIm5hbWUiOiJzeW50aGV0aWMifQ.36hbzmnus_qBNCJ4qh2M4qCa", "F4RowUMXSnLvHHTECAg"])

def make_client():
    return Client(key=jwt)

