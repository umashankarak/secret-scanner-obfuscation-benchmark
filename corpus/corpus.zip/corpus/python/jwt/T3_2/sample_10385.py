# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6Ik", "pXVCJ9.eyJzdWIiOiJUSHM0U0s", "2WCIsIm5hbWUiOiJzeW50aGV0aWMifQ.J9yVZQs02jnO-LDkIFbSsHpvxogj8Sk1fdUh", "bmUSsf0"])

def make_client():
    return Client(key=jwt)

