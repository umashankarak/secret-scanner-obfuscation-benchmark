# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2YWpRQTZ", "udCIsIm5hbW", "UiOiJzeW50aGV0aWMifQ.1Q", "HU4o-TPwEodv0Tv2xKq8UWmEmiDi64gMQsCpotPNM"])

def make_client():
    return Client(key=jwt)

