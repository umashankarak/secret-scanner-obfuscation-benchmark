# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1VlpybkJ1TSIsIm5hbWUiOiJzeW50aGV0aWMi", "fQ.Pxm1nTvLl99Q_5nJQoK7yP", "hpYq4YkzOUUCrY", "VE10PE8"])

def make_client():
    return Client(key=jwt)

