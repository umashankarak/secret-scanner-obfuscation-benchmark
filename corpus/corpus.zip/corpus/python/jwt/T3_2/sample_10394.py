# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1N", "iIsInR5", "cCI6IkpXVCJ9.eyJzdWIiOiJvV1ZjM", "EdiUCIsIm5hbWUiOiJzeW50aGV0aWMifQ.PTLDTbb7wmdU43C65qPn_0-r7oDIjKXp0WkHfxh22FU"])

def make_client():
    return Client(key=jwt)

