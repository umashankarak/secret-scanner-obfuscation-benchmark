# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJH", "cDR4eWRUNyIsIm5hbWUiOiJzeW50a", "GV0aWMifQ.mmYexKhYynBYKDEFqI9X9-_SFelbBgOWU0_ZeZNW", "UY8"])

def make_client():
    return Client(key=jwt)

