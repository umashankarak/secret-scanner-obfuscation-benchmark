# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5c", "CI6IkpXVCJ9.eyJzdWIiOiJBQ2Y2T0Vp", "dyIsIm5h", "bWUiOiJzeW50aGV0aWMifQ.D4vdy7VRJ4wRsqjvuEpd1v5qw0Sirg8qaMfrEeDiPz4"])

def make_client():
    return Client(key=jwt)

