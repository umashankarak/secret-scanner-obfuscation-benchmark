# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6Ik", "pXVCJ9.eyJzdWIiOiJUY05aRk", "R2dyIsIm5hbWUiOiJzeW50aGV0aWMifQ.-_x-rTl9TOAFQDOth1aKK51b7FCSk29Yp4jsaKL", "QCAo"])

def make_client():
    return Client(key=jwt)

