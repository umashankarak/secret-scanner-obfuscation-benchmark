# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIs", "InR5cCI6IkpXVCJ9.eyJzdWIiOiJlQnJkRzg2bSIs", "Im5hbWU", "iOiJzeW50aGV0aWMifQ.kbk6g1z__Uc4_vV9NASB0Nc_MMJ5PucVGzArUOZVICg"])

def make_client():
    return Client(key=jwt)

