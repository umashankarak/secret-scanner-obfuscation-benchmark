# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1N", "iIsInR5cC", "I6IkpXVCJ9.eyJzdWIiOiJZNGQ0UXlpdSIsIm5hbWUiOiJzeW50aGV0aWMifQ.Sid4V9Ipmt6rYMeOQPcB3s8tnSwtRnEhsPGzbY", "esV6M"])

def make_client():
    return Client(key=jwt)

