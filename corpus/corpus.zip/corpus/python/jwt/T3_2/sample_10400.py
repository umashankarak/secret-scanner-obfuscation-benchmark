# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR", "5cCI6IkpXVCJ9.eyJzdWIiOiJUZGJzdXNWTyIsIm5hbWUiOiJzeW50aGV0", "aWMifQ.", "2isz9igXuuh-mRwef0qygxxTQcO0_l1Lo79AVB_JmHc"])

def make_client():
    return Client(key=jwt)

