# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWI", "iOiJsTW1LRnJUaSIsIm5hbWUiOiJzeW50aGV0aWMi", "fQ.UsD31Ozrm", "M86XBlG_wWGddDPFgGXtQSdVYUxJHXwFqw"])

def make_client():
    return Client(key=jwt)

