# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsI", "nR5cCI6IkpXVCJ9.ey", "JzdWIiOiJnNGhId2NmZyIsIm5hbWUiOiJzeW50aGV0aWMifQ.FXL1bsrEF9z6", "thuZe6d8iq2tX-l9Yevsv3pwSiNJb5g"])

def make_client():
    return Client(key=jwt)

