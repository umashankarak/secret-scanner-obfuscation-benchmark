# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1", "NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjNVc1RUNrSyIsIm5hbW", "UiOiJzeW50aGV0aWMifQ.Ij2z57Z_oTl0RkAP0WDlT8Yn30z4S2UIuB8xXe", "pCFTY"])

def make_client():
    return Client(key=jwt)

