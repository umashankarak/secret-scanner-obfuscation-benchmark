# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsI", "nR5cCI6IkpXVCJ9.eyJzdWIiOiIzQks0bll3", "NCIsIm5hbWUiOiJzeW50aGV0aWMifQ.erevpAkw2IJ2", "0S0-tjRH8g5wiap0te_dPvnSyIholeQ"])

def make_client():
    return Client(key=jwt)

