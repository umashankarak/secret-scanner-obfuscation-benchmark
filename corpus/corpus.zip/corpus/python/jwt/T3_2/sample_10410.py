# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciO", "iJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOi", "JiRjdPazVHdiIsIm5hb", "WUiOiJzeW50aGV0aWMifQ.vhw9CLu5BlH8_9W9PsJms5YAsqB73cxsQEzWE--7eOo"])

def make_client():
    return Client(key=jwt)

