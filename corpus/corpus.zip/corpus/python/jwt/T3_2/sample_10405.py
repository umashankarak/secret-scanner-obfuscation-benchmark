# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiI", "sInR5cCI6IkpXVCJ9.eyJzdWIiOiJVMkwzdDJR", "bCIsIm5hbWUiOiJzeW50aGV0aWMif", "Q.6BofG5Rv0qcRlimCdXBughuWMDABlbUqXvob57eKQ94"])

def make_client():
    return Client(key=jwt)

