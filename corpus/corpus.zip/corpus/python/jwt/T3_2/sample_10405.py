# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "".join(["eyJ", "hbGciOiJIUzI1NiIsInR5cCI", "6IkpXVCJ9.eyJzdWIiOiJpblJudlZqbyIsIm5hbWUiOiJzeW50aGV0aWMifQ", ".6JMDmiWbUWLTddNuLICUud2GhPxKXKZpkr7daXMhCwo"])

def make_client():
    return Client(key=jwt)

