# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdW", "IiOiI4cFU5d1l1SSIsIm5hbWUiO", "iJzeW50aGV0aWMifQ.qdrEtX8jVVWREKjs2lQcor2", "PZ-LxDIcFU5V2fqnM77U"])

def make_client():
    return Client(key=jwt)

