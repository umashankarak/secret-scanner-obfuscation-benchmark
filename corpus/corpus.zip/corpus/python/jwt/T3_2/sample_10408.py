# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzd", "WIiOiJPYUp4QmFwYSIsIm5hbWUiOiJz", "eW50aGV0aWMifQ.QpHtF1giyBl2QMXys5Wo3nUr8qkia9", "JjvaajBm3kK5E"])

def make_client():
    return Client(key=jwt)

