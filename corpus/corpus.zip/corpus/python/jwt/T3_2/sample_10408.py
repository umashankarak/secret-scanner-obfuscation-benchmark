# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiO", "iJEYjlyU0NHdSIsIm", "5hbWUiOiJzeW50aGV0aWMifQ.nkHVC", "oWbn1uhd7VmA3Y4Oh2EvqC_YKJLZgk36YX18YE"])

def make_client():
    return Client(key=jwt)

