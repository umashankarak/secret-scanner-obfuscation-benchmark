# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1N", "iIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJYNW1OVHU5SCIsIm5hbWUiOiJzeW50", "aGV0aWMifQ.7K-fSic0cuQo4dV34", "ord3hL59F7R_QvkZ1Hubo3kf_8"])

def make_client():
    return Client(key=jwt)

