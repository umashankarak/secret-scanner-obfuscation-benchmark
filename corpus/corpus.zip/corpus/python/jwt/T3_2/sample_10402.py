# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "".join(["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJSQjdPa3FhQyIsIm5", "hbWUiOiJzeW50aGV0aWMifQ.2dp-6eMA5Gzdc6hVIHA", "v0l5EZb", "5TwQ7dg6byfJI3BII"])

def make_client():
    return Client(key=jwt)

