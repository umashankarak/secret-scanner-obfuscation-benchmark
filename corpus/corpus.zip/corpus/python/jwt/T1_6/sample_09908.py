# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvW6oJu3qIt5ZPVfVz5uoJHvBvWmrJ50nTI0nJZvsD.dtcOc-RuES2SBP-ZhUw8oxpCLi8V8jG3mi-20TJbJ1L"

def make_client():
    return Client(key=jwt)

