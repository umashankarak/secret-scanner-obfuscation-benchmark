# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWHEScGG0WkHFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.ORL6rY7RZaACVqlJa1E9Kbw-ZrfPMRJFYY6iR7JwZnj"

def make_client():
    return Client(key=jwt)

