# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV3A2EiFH9ZLlVfVz5uoJHvBvWmrJ50nTI0nJZvsD.uJEgyIkbMRoq5hs2NMlAFgLRZWwKjl1dcn2I-9QBLup"

def make_client():
    return Client(key=jwt)

