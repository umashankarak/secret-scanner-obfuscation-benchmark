# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV3HTb1pxu0JPVfVz5uoJHvBvWmrJ50nTI0nJZvsD.hKaD_4Z50h6t3WLC1Adj8brIPak4Vo0gn3VYgEbOAhp"

def make_client():
    return Client(key=jwt)

