# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWJMKZlL1t2pvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.AHh0xBU_sPtwwtGnpDHu7RItrmcdwhyu3ttDobq1Qsp"

def make_client():
    return Client(key=jwt)

