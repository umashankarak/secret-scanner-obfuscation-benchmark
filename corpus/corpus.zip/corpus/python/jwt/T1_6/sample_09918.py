# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV1nUMvI1WyJFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.hF1PnjIyiFTpgvrn_8DheASUX5FpxUpisBmLuepFHfb"

def make_client():
    return Client(key=jwt)

