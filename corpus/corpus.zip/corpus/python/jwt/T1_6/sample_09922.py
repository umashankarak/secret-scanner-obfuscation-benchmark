# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWWpJMjJT5VDlVfVz5uoJHvBvWmrJ50nTI0nJZvsD.0Bms7_mDXPHp5eAcJEf6Ihv0J1UzwLxf_2DhrgCxfg0"

def make_client():
    return Client(key=jwt)

