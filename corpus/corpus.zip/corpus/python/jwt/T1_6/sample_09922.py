# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWHGGMTqIcnoFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.9q_R1OQp5-JW7FtfHo2-AjqD2u1m1Fu06yb-wdhE59H"

def make_client():
    return Client(key=jwt)

