# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWGEacIE09aEFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.SrxTeYGyPk2wmTt61mHvsHB5NClWJalEnKtryjmEPjL"

def make_client():
    return Client(key=jwt)

