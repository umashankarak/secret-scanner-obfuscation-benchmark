# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWzHQSEHauRnFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.BVhxKT9Zlz41oVf5ZKek3dSJRO00U0pzpJjYtfCqcgR"

def make_client():
    return Client(key=jwt)

