# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvVmG1ESL1SkFlVfVz5uoJHvBvWmrJ50nTI0nJZvsD._eI5EbJrizQ-AttPdhRjXy2R3er3SdYJjGXlzB59EZN"

def make_client():
    return Client(key=jwt)

