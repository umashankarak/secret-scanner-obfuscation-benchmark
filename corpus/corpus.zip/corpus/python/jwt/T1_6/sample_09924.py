# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWOqUSgFSOfrvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.idol0D1hJ0OEd_SMuDfs3fYEY92PHqzdYf53rSb28N0"

def make_client():
    return Client(key=jwt)

