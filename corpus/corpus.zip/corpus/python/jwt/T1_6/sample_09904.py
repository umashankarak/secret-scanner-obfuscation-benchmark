# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWyBQS0GUuzAvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.lcfrwMqHdRh038qvArz3fK3YnPUvDnTdyPtw934k6FV"

def make_client():
    return Client(key=jwt)

