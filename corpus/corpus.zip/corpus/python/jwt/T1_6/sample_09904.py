# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWhHzujDyOBIFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.vOGkKtiVzTYtEfGZT4KP_Tp6GrDLmizeDXnU2h7lov8"

def make_client():
    return Client(key=jwt)

