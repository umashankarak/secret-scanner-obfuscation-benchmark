# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWXEQSKnmp3ZvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.26f8whot55l4HHv-Svq0dpqshBbsGzjL0D0hf4_QNdb"

def make_client():
    return Client(key=jwt)

