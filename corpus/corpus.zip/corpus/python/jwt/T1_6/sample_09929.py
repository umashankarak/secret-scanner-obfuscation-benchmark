# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV1nzMCoRg2qvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.Eo1CIrJfjLiS-szWze59QjR6T8U7S_Jg6pfdLhZgY2j"

def make_client():
    return Client(key=jwt)

