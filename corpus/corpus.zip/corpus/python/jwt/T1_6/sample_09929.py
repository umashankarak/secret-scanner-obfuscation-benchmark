# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWGJxqipGWaIlVfVz5uoJHvBvWmrJ50nTI0nJZvsD.ijTTuNbfsCR9eUCF0S_8XyNYTz-9_ZoNbGDxMhhZKlH"

def make_client():
    return Client(key=jwt)

