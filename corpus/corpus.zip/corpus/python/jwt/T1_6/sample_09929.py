# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV1qSZlAmH1BFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.oSZbTWAcQ_RNVJtouPhDphkmKUMMv7yWWdnVKMhMqEH"

def make_client():
    return Client(key=jwt)

