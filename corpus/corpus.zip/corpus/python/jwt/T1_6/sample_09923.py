# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWLBUp3LJIBFPVfVz5uoJHvBvWmrJ50nTI0nJZvsD.8QUQ-hhLrS4A2vgnjw7-YYnUmVSXy97EvReooTi6bzx"

def make_client():
    return Client(key=jwt)

