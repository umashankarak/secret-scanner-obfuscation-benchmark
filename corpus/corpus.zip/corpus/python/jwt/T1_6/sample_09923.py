# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvW2DaqToSEOJFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.F6-LDTb_JpHzvDcYYW2DWTZFDEhbjzf8DMM-srTOAjj"

def make_client():
    return Client(key=jwt)

