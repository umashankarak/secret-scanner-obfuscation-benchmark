# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWEFSHjp2EjGvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.zXsabzR9J4MhxZ2gY0D7lHIVgWQKxIK__KfFS-bUb1V"

def make_client():
    return Client(key=jwt)

