# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWmoGSFMUyYIvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.GkHlXcw_55BQWRM-DTvu_jUY0JpE_wsDkMHTIIGmpWR"

def make_client():
    return Client(key=jwt)

