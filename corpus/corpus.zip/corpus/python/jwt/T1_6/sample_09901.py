# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWZZmOWpmWPDFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.-dWcSnoJdnkrqFV4v6Epo0mXowIfvmxkriUrbILDUGD"

def make_client():
    return Client(key=jwt)

