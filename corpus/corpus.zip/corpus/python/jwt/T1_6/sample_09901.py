# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWPZGMQM3qYFPVfVz5uoJHvBvWmrJ50nTI0nJZvsD.Leh_gxJAx2zxBeUXX4iB6WBklCvCHlioHZ3j6gZccip"

def make_client():
    return Client(key=jwt)

