# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWZGwMPnypknlVfVz5uoJHvBvWmrJ50nTI0nJZvsD.AMTIzEVszJR3CwwDgbwGAsMqtr82eu4-o6rsh4tH8I4"

def make_client():
    return Client(key=jwt)

