# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWXrUy3nmucMvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.nF_5Z6aaVSKpMISl6MohPoqtchm5gY2WQt6moH8Mac0"

def make_client():
    return Client(key=jwt)

