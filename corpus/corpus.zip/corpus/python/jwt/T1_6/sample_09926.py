# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV3HT4jAyEREvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.3UjJdKnFjMEVDUFSGpcYrVf5SC35yJfAu81JvEhHTw0"

def make_client():
    return Client(key=jwt)

