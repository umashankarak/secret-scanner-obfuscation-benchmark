# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWfJUbjA05jDFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.UzHgHQx4iB9kec4Pm8mkwod5_3beAx-KCHWOF6sIIxH"

def make_client():
    return Client(key=jwt)

