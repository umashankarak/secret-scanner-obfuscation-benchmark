# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvW6nIqQAJgvolVfVz5uoJHvBvWmrJ50nTI0nJZvsD.djAbninifGtbMcDo75npv6aXs6G4E5_8IMq8YBteFVp"

def make_client():
    return Client(key=jwt)

