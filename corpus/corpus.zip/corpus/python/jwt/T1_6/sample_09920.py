# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvW0HaDlIaEaqFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.Y6Mp_rM0ytcKayhMC8yHGdqJJ3sG7fvmEISbB20ncFt"

def make_client():
    return Client(key=jwt)

