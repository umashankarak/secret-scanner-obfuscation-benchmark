# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV3BSb3L1OVFPVfVz5uoJHvBvWmrJ50nTI0nJZvsD.Aq97gIy_U8ZCoooBjPFrWLZtElF_wPLD2_LOSCrfRsH"

def make_client():
    return Client(key=jwt)

