# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV2rJyTnUulAlVfVz5uoJHvBvWmrJ50nTI0nJZvsD.v268BkojtU-xct0KEoIUZtPaKRww_s5EWHZ38eI4Qwb"

def make_client():
    return Client(key=jwt)

