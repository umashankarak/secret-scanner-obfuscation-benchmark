# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWbpzcQDzAUIlVfVz5uoJHvBvWmrJ50nTI0nJZvsD.3noEL5aQSGs8AaA7kt4ilQJOwAmSrbx7JfsRN7qLNpV"

def make_client():
    return Client(key=jwt)

