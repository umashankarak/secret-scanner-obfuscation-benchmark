# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWfF0RlBHS3pvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.I6tNMafAzY0cQwt4KqRdD6uMkli5qgfDuCDBFTrk6kR"

def make_client():
    return Client(key=jwt)

