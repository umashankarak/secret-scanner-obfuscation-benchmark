# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWipTyaJyLlJvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.gxxyD1uJ997jZZHcixUF3QfWygjEbEBNhMglGTw54_0"

def make_client():
    return Client(key=jwt)

