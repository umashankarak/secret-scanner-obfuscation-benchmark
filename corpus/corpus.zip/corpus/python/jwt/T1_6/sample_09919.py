# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWfHaWfD3OcBFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.54LpVv99E6fTXI7ZBQtGqDy8pc9_-OjPFqhEhklAYF0"

def make_client():
    return Client(key=jwt)

