# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWGFQMfZScwAFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.xV6yiS9xFeZNcejWMRwyKoXjh4buOvROWY4lawBF9T4"

def make_client():
    return Client(key=jwt)

