# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV4L1AUHwqYoFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.kxwY0O-SxSLg4dVHC_vF5PLuuP_vnczisfIg0mOogAL"

def make_client():
    return Client(key=jwt)

