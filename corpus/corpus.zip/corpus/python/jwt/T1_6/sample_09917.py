# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWzM2H4Zzf1FlVfVz5uoJHvBvWmrJ50nTI0nJZvsD.fA9Few53yGDfbLMAqcCL-PTrjNP5EjMTJ6D8jjXugBx"

def make_client():
    return Client(key=jwt)

