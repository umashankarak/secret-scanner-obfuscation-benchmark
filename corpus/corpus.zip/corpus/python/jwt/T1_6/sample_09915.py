# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWJBJMkDwL2JPVfVz5uoJHvBvWmrJ50nTI0nJZvsD.8YRANm0DR1zw1wPtdGII3bfW6Ir6Ndqo5NlDe8u4kh0"

def make_client():
    return Client(key=jwt)

