# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWUowqiHGSLHFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.DcgIcZ-o8kPTJ6e1Ukf98qODYlfPzU-QFsF3VfzZcEb"

def make_client():
    return Client(key=jwt)

