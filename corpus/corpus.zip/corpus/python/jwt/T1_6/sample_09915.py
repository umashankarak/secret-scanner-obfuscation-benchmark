# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvVjAHWHomIYHlVfVz5uoJHvBvWmrJ50nTI0nJZvsD.4v0S1flqx5V1C80R0THTcnjJ1J-u0hk--PRr2xuOEOj"

def make_client():
    return Client(key=jwt)

