# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWZpHk3DIEypPVfVz5uoJHvBvWmrJ50nTI0nJZvsD.fnDep7CSwuNu1OS_bIIww79TJ-ZC-8XUuUdgDA_MROf"

def make_client():
    return Client(key=jwt)

