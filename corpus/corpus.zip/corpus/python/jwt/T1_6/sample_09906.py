# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWnD1IdZ2y3FlVfVz5uoJHvBvWmrJ50nTI0nJZvsD.6ru8O_DvIAdp3NIm_Vogo5Lh43O1Ce_ZUkBEHnt2ctN"

def make_client():
    return Client(key=jwt)

