# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWhnJg2pKOjBPVfVz5uoJHvBvWmrJ50nTI0nJZvsD.BuIWwssyGYQo7hsy92kGXOvGnD_kNPSbT4DexUYfp1j"

def make_client():
    return Client(key=jwt)

