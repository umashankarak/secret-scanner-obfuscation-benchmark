# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvW3ZTARo1WwnlVfVz5uoJHvBvWmrJ50nTI0nJZvsD.fJ-0T2PTaN409fh5b4FXPBc37jhpWVuqweAx2JZ6X2p"

def make_client():
    return Client(key=jwt)

