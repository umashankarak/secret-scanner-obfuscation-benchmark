# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV0DyW2nR1TMlVfVz5uoJHvBvWmrJ50nTI0nJZvsD.0COzHApK4CIKCdRcloUaotH9BMOOd11za0NtYU9a6iN"

def make_client():
    return Client(key=jwt)

