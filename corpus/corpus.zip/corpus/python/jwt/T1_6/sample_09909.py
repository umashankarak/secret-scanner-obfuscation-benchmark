# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWzGKyZoQOXovVfVz5uoJHvBvWmrJ50nTI0nJZvsD.qXsIsl2PkZWYdyc_tXIXg7AOrJPN0e04NBSbf9n8gkj"

def make_client():
    return Client(key=jwt)

