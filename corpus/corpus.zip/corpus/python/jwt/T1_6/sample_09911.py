# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWAIaOGEUqaoFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.yODqqCUUqntKb7zYSCC6hu367QBeivs-_3B5WXbPRvV"

def make_client():
    return Client(key=jwt)

