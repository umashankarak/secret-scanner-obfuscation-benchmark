# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWBEwqgARMULvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.j37VA7dmoc56linSvXmhHAfHU1RFl0bgsd06YcdYGvN"

def make_client():
    return Client(key=jwt)

