# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWULGS2pGEFFPVfVz5uoJHvBvWmrJ50nTI0nJZvsD.rqa-7MaKcXzADF4iQbCP762Mm5V-hXizs8PbsDcQpqZ"

def make_client():
    return Client(key=jwt)

