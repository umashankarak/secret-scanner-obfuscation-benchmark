# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWlHzDkZTSZMPVfVz5uoJHvBvWmrJ50nTI0nJZvsD.CWUAlrZHS1ft4CjZZMHF-5kuvtk0oBB30sit7AqHxoZ"

def make_client():
    return Client(key=jwt)

