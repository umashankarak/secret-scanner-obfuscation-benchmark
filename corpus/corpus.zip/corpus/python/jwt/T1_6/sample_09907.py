# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWRq0yIp2cDFFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.KMhMqEHYYEo9Yslw1W_qdyY2HKl6DyIjIlsRPs8A8cf"

def make_client():
    return Client(key=jwt)

