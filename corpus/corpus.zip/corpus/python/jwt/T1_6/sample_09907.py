# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWVM3IDJT9KDvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.kJ60UO2-9ZS3jS1Q-xl2F7U7FRcCWhNVgPE0KQsm4v4"

def make_client():
    return Client(key=jwt)

