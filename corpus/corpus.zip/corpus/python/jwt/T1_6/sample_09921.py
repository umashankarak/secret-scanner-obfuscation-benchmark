# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWyGKqjEaI4MvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.vXGl-u8qOKQIhfiqhr9I-CoYPESoITJputX_-g8exe4"

def make_client():
    return Client(key=jwt)

