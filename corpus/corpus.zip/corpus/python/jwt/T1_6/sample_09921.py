# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWTJyOToSL3EvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.2DuT_3LFnFjm3SSYAYmwAcXZ30bd0uOr6XVDODED_3R"

def make_client():
    return Client(key=jwt)

