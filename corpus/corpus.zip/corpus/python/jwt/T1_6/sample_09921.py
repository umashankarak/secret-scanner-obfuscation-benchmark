# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV3BRb4HyIvnFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.kApbJvBklpKsEwDfo9mxtYExtxj9Cg04JGR7mS6J2Oj"

def make_client():
    return Client(key=jwt)

