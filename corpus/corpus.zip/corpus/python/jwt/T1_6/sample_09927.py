# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWwJH15AUWLJvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.T4KP_Tp6GrDLmizeDXnU2h7lov9o0pWrWf_yI5uEQT8"

def make_client():
    return Client(key=jwt)

