# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWILGMQE1ExqFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.MpB47QVM1-WGcRlQM7nhyyu4O3Q-Am_NCMq7IMSPpkp"

def make_client():
    return Client(key=jwt)

