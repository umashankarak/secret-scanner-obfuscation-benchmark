# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWPAGOzBIymovVfVz5uoJHvBvWmrJ50nTI0nJZvsD.kZyWPxt6beKRT1yeMiD5a0C9EzaDcj2wTglsnqUVU3N"

def make_client():
    return Client(key=jwt)

