# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWaJaSTFzyKolVfVz5uoJHvBvWmrJ50nTI0nJZvsD.kCOqro-XGZkOG_HyABBYJwor1szbJRN6PIp5-XtcckZ"

def make_client():
    return Client(key=jwt)

