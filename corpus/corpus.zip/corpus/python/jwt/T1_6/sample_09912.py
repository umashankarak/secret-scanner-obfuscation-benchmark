# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWwq3SRnRuJZvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.YoAZuo55voEneIA4XTmJfVJuZUVR4pjIW0sUhAUqL3b"

def make_client():
    return Client(key=jwt)

