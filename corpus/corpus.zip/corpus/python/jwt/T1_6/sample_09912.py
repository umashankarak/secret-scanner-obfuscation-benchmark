# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWWHTqEFRDjElVfVz5uoJHvBvWmrJ50nTI0nJZvsD.QjvlFyRfVWCpThd5dC676ipps0NG17G9RMYbl8Y2JnN"

def make_client():
    return Client(key=jwt)

