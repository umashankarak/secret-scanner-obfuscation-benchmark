# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV2GyWvoUSbDvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.DKIDU4VQJgNcmI_Q_HdPcq1ubAiFwW06Rd_lB-WUO6x"

def make_client():
    return Client(key=jwt)

