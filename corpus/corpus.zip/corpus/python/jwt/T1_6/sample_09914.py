# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWfZxgiEyp0ZPVfVz5uoJHvBvWmrJ50nTI0nJZvsD.SHuOM8iwPusOHiNoEY4eBjAeR_gO4pn7DVJssr42-ut"

def make_client():
    return Client(key=jwt)

