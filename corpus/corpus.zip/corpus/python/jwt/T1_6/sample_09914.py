# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWdnHg3JJ9BFvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.MYbSNXXOT64DAE22ktmgylRvx8fRFvhHxElOK9Gy9S4"

def make_client():
    return Client(key=jwt)

