# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWYFHq4EScjLvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.roOd4i3-4sy5dGqTorowpOJKmE6yveYP8hIpVEg5ucV"

def make_client():
    return Client(key=jwt)

