# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvW2o2cnn2cKrPVfVz5uoJHvBvWmrJ50nTI0nJZvsD.SuOUTmZWOduHd9_F3rkj3_cN5Q5W_KtkmWER8JsFmhp"

def make_client():
    return Client(key=jwt)

