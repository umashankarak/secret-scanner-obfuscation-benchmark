# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWmEJk5rzIvrvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.wI4aelOt0PLooPSj244qWIUuHEPB_cAG8dScunZRaix"

def make_client():
    return Client(key=jwt)

