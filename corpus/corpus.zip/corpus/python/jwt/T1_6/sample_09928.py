# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWVIxAhBKEkIFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.4PzhFDzcryNLQRcWBblcygPN7ujf2pimRNz6U_K--9Z"

def make_client():
    return Client(key=jwt)

