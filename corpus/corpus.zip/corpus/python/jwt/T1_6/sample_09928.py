# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWZF1Ixo0ygEPVfVz5uoJHvBvWmrJ50nTI0nJZvsD.0gxTN3zWCcn44Uu-PIWDk_23iQDvXIIOCGmlBuIWwsp"

def make_client():
    return Client(key=jwt)

