# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV1GJ85pRIVHFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.NI6CLeIlutNYN2ZXqVK0pI2jdSF734LJEgchQbYEWvj"

def make_client():
    return Client(key=jwt)

