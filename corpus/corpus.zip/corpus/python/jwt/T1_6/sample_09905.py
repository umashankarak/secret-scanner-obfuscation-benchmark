# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvW3ZSq4nyb1qvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.zSRZo5K6x7fCBLblq9YMOtA5vG6JhBO4styFHZs9g7j"

def make_client():
    return Client(key=jwt)

