# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWKn0V5H3IGFvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.AUAydyLeTLbONNDi_Ce9PnCMmr_kItnrIxnDWiTulTR"

def make_client():
    return Client(key=jwt)

