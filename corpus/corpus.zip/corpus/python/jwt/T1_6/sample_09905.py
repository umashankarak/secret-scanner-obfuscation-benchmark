# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWXn3cuMaqPplVfVz5uoJHvBvWmrJ50nTI0nJZvsD.U7OVPL78e5K37aSPWL7gZszzED-bln45JNeVg0h0Mo4"

def make_client():
    return Client(key=jwt)

