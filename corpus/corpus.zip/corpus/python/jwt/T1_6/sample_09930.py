# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWDGzuFJGyvEPVfVz5uoJHvBvWmrJ50nTI0nJZvsD.UDifkRpcNvjSg13WZ67S83I-wkYCJ6aWReqh0ciAgyL"

def make_client():
    return Client(key=jwt)

