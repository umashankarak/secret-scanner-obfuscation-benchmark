# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWwoTMfGmSBZlVfVz5uoJHvBvWmrJ50nTI0nJZvsD.dyY2HKl6DyIjIlsRPs8A8cif7t06vnXKPbIxoMIpnTD"

def make_client():
    return Client(key=jwt)

