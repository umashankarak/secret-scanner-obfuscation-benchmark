# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV0GzMWAKD4ZPVfVz5uoJHvBvWmrJ50nTI0nJZvsD.HJeHS00gPtFu_56JiFZlBtgGhCDdrWXI092DOzmeVap"

def make_client():
    return Client(key=jwt)

