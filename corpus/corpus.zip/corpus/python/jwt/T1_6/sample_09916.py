# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWxJaSvIyAjplVfVz5uoJHvBvWmrJ50nTI0nJZvsD.4Vh0ek0JkiFEQa0qzLOI88vFcBlDQ2sVvmLLknn5qtt"

def make_client():
    return Client(key=jwt)

