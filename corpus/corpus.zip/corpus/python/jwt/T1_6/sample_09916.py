# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV4GHD4HKtkGFVfVz5uoJHvBvWmrJ50nTI0nJZvsD._Rkyvb4JttP8DZHOjmcMX0H-bgJiiBjBnWcrQm9y_pf"

def make_client():
    return Client(key=jwt)

