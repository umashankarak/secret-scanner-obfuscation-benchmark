# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWgMTulnR9SqlVfVz5uoJHvBvWmrJ50nTI0nJZvsD.bfOQMm26UvdVJ4KbZ5a4v6A31FemzGOGAFzwpKk1_SV"

def make_client():
    return Client(key=jwt)

