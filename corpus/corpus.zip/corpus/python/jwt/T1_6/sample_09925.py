# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWzAJ85Z0R4rFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.IAMrImmjInrTJZgNzAf4jX0HUy1BVshYKLcIDMFpoUH"

def make_client():
    return Client(key=jwt)

