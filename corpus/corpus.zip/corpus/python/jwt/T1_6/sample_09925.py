# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvW5GIqzoz5QEFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.kt4ilQJOwAmSrbx7JfsRN7qLNpW6sVfUi22yNfWmBrf"

def make_client():
    return Client(key=jwt)

