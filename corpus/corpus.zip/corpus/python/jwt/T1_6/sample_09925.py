# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWhJKN3o2cvMvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.fR9kwU3Kp0g_WqODCmRE-7sLkDGQ1ecGdjoY6NPWS7b"

def make_client():
    return Client(key=jwt)

