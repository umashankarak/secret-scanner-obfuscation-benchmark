# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWyDHAEnwIgGPVfVz5uoJHvBvWmrJ50nTI0nJZvsD.genR5BnnO_K0DthL3A7VkU-_P1IkS25Xw89d4HN_MiL"

def make_client():
    return Client(key=jwt)

