# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV0FKV5H0AQZvVfVz5uoJHvBvWmrJ50nTI0nJZvsD.EEKY7PxJl5adaWL2AXjejLBZIbkDaRHHyiruGpgxUlD"

def make_client():
    return Client(key=jwt)

