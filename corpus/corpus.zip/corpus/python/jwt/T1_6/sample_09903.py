# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWSExyvIxWDLFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.jaZ565Fs6T0yj9pbAMTIzEVszJR3CwwDgbwGAsMqtr8"

def make_client():
    return Client(key=jwt)

