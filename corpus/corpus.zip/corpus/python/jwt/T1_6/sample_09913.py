# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWEMx9kHRq6MFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.kGU7YI6kVVtpKWNIajGh_5vvYFOJg0Xg3Ohf7EA4tgj"

def make_client():
    return Client(key=jwt)

