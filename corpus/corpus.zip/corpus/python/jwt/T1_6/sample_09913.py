# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvV5D3M5AUOZrFVfVz5uoJHvBvWmrJ50nTI0nJZvsD.SRkvFsyJwuMhrj9DfuZT46rOrqzSmDLnHTOTb3QScY0"

def make_client():
    return Client(key=jwt)

