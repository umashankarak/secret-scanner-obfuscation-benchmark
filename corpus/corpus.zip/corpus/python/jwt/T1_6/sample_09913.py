# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "rlWuoTpvBvWVHmV1AvVfVaE5pPV6VxcKIPW9.rlWmqJVvBvWlJGx1IKH4ovVfVz5uoJHvBvWmrJ50nTI0nJZvsD.w9r6EXnOxSMFuWnlZNo8efFDGA3JnQOW4CPp8WkcvlZ"

def make_client():
    return Client(key=jwt)

