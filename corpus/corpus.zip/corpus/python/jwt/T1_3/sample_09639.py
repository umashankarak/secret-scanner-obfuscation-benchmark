# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cMG)-4dPfkQ+T1{z5b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Ek;RBacpBSI5%ZvM{i+OO>}y7SVd4qb5}?-F?df#H8*i_dNVRgPiQa"

def make_client():
    return Client(key=jwt)

