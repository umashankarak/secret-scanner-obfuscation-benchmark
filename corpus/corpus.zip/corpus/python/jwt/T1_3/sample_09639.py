# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNdR1$9Z%$P?dSZD=b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_LvBh`Xk~InIZHD`ZE878LoqOUPIYZcVNG^nc{w*?K}uz1W=>Z@Luq#"

def make_client():
    return Client(key=jwt)

