# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNRat9Ec~eGYa8yG{b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_XmC$cWnnpLK~7O~Saoe*Q&~oMZC6inbw@U8Pc%|rMqgAkOJZ(cQ8-Z"

def make_client():
    return Client(key=jwt)

