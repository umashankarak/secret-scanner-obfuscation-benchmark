# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNL{3#wSz1SAFjG@Wb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Zf#6vQFUTYGj2#}PDMdPOKm}GcQ!&~M_)O1W=>6CT3<6oHaRmyQh7l"

def make_client():
    return Client(key=jwt)

