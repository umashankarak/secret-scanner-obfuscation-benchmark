# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNb!0GTSy^syZB=PWb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_IYn$kP<m=KPIxV8Xjm<ASw~-5WOz<OI9Y9aH+nT|aYs&ZSvh)cHCk%"

def make_client():
    return Client(key=jwt)

