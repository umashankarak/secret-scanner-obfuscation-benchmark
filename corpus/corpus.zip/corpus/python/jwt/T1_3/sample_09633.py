# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNGGc0ESW{O@cT{;vb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_ZD~j`R7Nm3L{MXHHFq+3c`Z+FL3(v%Y;AXQYi)35b3|xzI8<g@O-o4"

def make_client():
    return Client(key=jwt)

