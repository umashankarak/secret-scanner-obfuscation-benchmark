# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNO;SZ@bz^EqY*cwkb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_RBli?Eln^(SZZ@(c5h)za!od9O;bpBEnzixaX4vtN@77}YfnmId2>Y"

def make_client():
    return Client(key=jwt)

