# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNZcQ>uF-}KDM_Fk}b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_HBw4aZ((XzcyVKActTlbRZCe%d1ZB3T3SnFP)|uqcQiFMX<s*JM`dp"

def make_client():
    return Client(key=jwt)

