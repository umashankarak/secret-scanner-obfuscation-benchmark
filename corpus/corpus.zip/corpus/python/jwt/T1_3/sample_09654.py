# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNS5Y%?Hd$CjFiulRb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_SY}}~IBs+}Pe(&{F*I>?H*YvgVnaeQT5DJ}Mm1$tEmuloP<cc!Ep<f"

def make_client():
    return Client(key=jwt)

