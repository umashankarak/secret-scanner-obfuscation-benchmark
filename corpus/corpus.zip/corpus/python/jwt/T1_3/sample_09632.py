# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNQ(|jULseIBb7FZ(b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Pe^w}FjPq`PIgI3b~$=cNlH^zY;$KxPDnU8bVF-)bXQh$Uo}WFEp}r"

def make_client():
    return Client(key=jwt)

