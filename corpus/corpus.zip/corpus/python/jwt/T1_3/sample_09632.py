# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNVPP;@a!o~SOHETrb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_W^6T9XhLE~PI7K|RWwm~S87gZM{Rg%Qgv@`V`+M3I9PgDcu;k0Zc;b"

def make_client():
    return Client(key=jwt)

