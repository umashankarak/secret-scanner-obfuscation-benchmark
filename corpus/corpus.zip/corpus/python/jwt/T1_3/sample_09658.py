# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNMN}{`F;z!rd1QG>b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_OIU1jazt=sb7oFTMo4-wO>#p|HE?8QT4-%8bZ<msIW{y(Q&(a!b1_8"

def make_client():
    return Client(key=jwt)

