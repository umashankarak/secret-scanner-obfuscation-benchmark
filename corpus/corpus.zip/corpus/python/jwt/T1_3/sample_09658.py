# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNPh@LWPf==UQ)FpLb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Fm6dmN_S62P)Ao#bvI3CIC@`2YFadSXje04UvE@NO;~zVK`mo#VQy6"

def make_client():
    return Client(key=jwt)

