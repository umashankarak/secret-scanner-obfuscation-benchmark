# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNT319;RZePFOIK4#b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_LU>nSa#1x=Rcvf+Vl!b-YeiXCRYO=UWHwr6VqsNyLNHf&SxR_MSb9+"

def make_client():
    return Client(key=jwt)

