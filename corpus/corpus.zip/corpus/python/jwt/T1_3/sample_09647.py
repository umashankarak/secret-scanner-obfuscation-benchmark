# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNF=SOvYf)8fL{~#eb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_cu{O@Zc<WuM`AL1VRce<Ze~_lQdW3Dcvm%4L3wmlRZKHBLSbKOLRwh"

def make_client():
    return Client(key=jwt)

