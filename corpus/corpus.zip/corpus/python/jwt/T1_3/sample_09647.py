# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNVPi)|aZN@_ab!bDb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_bwNj8bZ|FWRYz=1X;)ugH$ydLS3+cYOfhmeXHj%eRd;J`aawS1LwR="

def make_client():
    return Client(key=jwt)

