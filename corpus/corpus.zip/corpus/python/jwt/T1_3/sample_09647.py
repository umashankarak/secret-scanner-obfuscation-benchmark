# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNSWiYqN>x;7c~oghb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_V`(&XX>n;vO;K_+R4`*xNpoc}I7Bv3VRte&GFNPROky`MO;vX>MlE*"

def make_client():
    return Client(key=jwt)

