# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNOk!(rQe{V4dQ^Eyb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_No`t5Gfiq)Us-E1L{>CMNo!g}WO{3CO>kFcX?l8bVp2<KY&T3bOKWo"

def make_client():
    return Client(key=jwt)

