# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNa$`qMP)$`iaan0eb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_IdM}?G<9}WSz|?Uc|l`GST<`nNMkT*R!UecNo_%HP&rIcNP0w0YgA_"

def make_client():
    return Client(key=jwt)

