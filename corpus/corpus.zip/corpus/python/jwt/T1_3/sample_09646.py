# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNdQ(PdPE%}EF;hcHb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_RA_T#QCVS3M^8g&QE5VNOH@L4YeP6uW?DgVK~GCfZcR9Fc3)IbRykP"

def make_client():
    return Client(key=jwt)

