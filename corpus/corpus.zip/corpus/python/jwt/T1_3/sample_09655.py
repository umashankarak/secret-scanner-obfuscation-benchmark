# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNbW%lhMN?~5YEMH+b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Q)@+cb#-A%Q$ku#QdBTDYGzhePGvJScQk89P;o<HNoH0}SX6gSIeB9"

def make_client():
    return Client(key=jwt)

