# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNZDcV)cT#RnGi6grb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_G&x34YhhwyOht7{LQPUgIBZZ+O)^0@Yh*}DR7g;4WOg)iZ(~bGGiX@"

def make_client():
    return Client(key=jwt)

