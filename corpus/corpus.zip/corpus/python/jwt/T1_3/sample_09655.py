# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNOif2hGF3-OdSYowb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_GA(#zW<hjjdTLfeL2)fIH*hg<GIVlLL|-;-GIM7|Lqaq%H)K^-L}^U"

def make_client():
    return Client(key=jwt)

