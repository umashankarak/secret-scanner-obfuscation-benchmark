# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cMHB&K0YGiFSZeeLjb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_N@6isVoXC>VKz{BaC%B_IY%%^PEcu3PenIyWqMI>WKLIhG-PHuLUc3"

def make_client():
    return Client(key=jwt)

