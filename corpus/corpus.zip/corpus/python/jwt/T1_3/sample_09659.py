# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNR#9t8R!vxNcT_`3b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_bV74;PEAUBIeB?aGHz6EZf!ziH%v!Oa4>E(R9|>XGkQrvR5?dwLSaP"

def make_client():
    return Client(key=jwt)

