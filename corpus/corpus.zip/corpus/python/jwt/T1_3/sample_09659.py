# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNYGOq=F=0k*Qes0%b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_b5Jc;Gj>l+PIonSRx&azS$1|uM{{j@K~zR>R&q5oXlG_=Vs|Z3Z*p@"

def make_client():
    return Client(key=jwt)

