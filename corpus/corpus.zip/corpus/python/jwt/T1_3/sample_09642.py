# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNaAH+OG*d=WX=8awb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_G;}R7VN@+RWm-^KYG!g_T4FhJT25<cR8vA<Us^O$G--1-Q*S~|T2M&"

def make_client():
    return Client(key=jwt)

