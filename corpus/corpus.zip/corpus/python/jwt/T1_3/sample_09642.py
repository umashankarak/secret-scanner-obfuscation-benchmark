# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNHezdJOIk27S6O*Ub4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_YgJBKRA*9pPB2MrZh1*aRb+H#VR>>`RA?}GL_|k6Lo`@QHBx9rLvcj"

def make_client():
    return Client(key=jwt)

