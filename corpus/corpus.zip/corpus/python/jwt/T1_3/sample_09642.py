# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNZd6BFZ%%4aHDq~7b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_NpMa!Iaf$)Vp>L2NLNBmPEcw#Yjk;bWM)}XVQ5NKWN0~3VM%I2MOtq"

def make_client():
    return Client(key=jwt)

