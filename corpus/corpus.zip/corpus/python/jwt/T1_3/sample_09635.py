# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNY*bWDcx6;<HBv)Kb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_X-#%9cSKD|bXZqsZC`9saCmxJS3_(yVK#R*SYk+eQ&LhmIaEt`YIRu"

def make_client():
    return Client(key=jwt)

