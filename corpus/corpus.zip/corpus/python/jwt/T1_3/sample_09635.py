# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNZ)9p(Yhi6pZBcnib4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Qa5*2Ic{Y^QD$;xUtvozWMOt{M0IL&VM{_<G*M!CY)x}<Pcv^=Mo~B"

def make_client():
    return Client(key=jwt)

