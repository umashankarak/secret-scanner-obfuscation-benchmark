# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNXk#!{GEP=(S5`wwb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_R9`kmXJ0K-X>ngxGfPWaH%wV#H&b?LMrd<(MO8U6Omk9UZ%9f<LwR="

def make_client():
    return Client(key=jwt)

