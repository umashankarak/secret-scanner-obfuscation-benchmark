# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNHf2UaZd61`HBxy=b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Z9zzMOjk-{PcUP7Syn-CY+qPVS6DP@Y&CL1OldMmQ+PN_Nj7jsSYbE"

def make_client():
    return Client(key=jwt)

