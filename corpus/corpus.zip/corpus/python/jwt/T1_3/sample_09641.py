# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cMGf`D=Rbp#sQe#s|b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_a(H7$P&ZC6ZE$f%NJBSINoRF;ReE!BR5e6nRA)zWX=zABRAEa`d3He"

def make_client():
    return Client(key=jwt)

