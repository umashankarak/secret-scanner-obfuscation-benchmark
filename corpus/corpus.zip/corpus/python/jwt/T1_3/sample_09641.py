# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cMGEPNSYFSiDZ&ztab4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_GC^8SSZ--GRz!GWGg4+kLr*tjMQTJdQB`_LK{0MwW^XuGO<6=@Ggeg"

def make_client():
    return Client(key=jwt)

