# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNOkpx)cv4toG*xLyb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_cyv-<NN9Cha5Q>SN@!7VWp+4PK{G{DK~_UbRCZc-T2g6wYe7nQbwgP"

def make_client():
    return Client(key=jwt)

