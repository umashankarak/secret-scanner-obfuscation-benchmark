# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cMc~?ekZ)8+xQ&xFNb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_d2DB9IWaV6cTib4N=s>TEoWGHW@%+faaK5bcvfgect$mKZ7@$VL1be"

def make_client():
    return Client(key=jwt)

