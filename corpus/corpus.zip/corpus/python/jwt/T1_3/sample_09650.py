# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNc1~7rFkyOVaaKb~b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_GHy;*V{%z|Za8B`IWTr{H%l=>OG#f(a5YDDO-5OCaClQsaA{;Ya&I^"

def make_client():
    return Client(key=jwt)

