# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNYGG_fLu4{ddSg>bb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_F;O{LLpXJAQet*=d1zT#YeHmJNI_Y4dO~(~a&|&;VR%_Ic5Ql2VNEy"

def make_client():
    return Client(key=jwt)

