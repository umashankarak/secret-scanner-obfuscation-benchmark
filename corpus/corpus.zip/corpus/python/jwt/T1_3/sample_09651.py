# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cMGEOmUHe^(6Yhy!6b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_RaZ=TQa5R5O*u(ScusmjYDsKrG-`Hlbxt@|bXQ?XL{u_iX<Be%H%xB"

def make_client():
    return Client(key=jwt)

