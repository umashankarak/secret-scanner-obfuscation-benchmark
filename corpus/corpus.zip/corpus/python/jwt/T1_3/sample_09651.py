# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNcw<y-aA8zMcVk0Ib4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_c2{_FZDx38a%wVEY++e$O*Ls*XjMgObu@J_S!6>-T4r!=d2?-bY-e`"

def make_client():
    return Client(key=jwt)

