# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNS7U8XQdL(qP*hV%b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_G-XOkLqbL{Su$Z%Pg7@dV=-|wPi#_kdP8JUOGkBhba-z`aaCzBXKil"

def make_client():
    return Client(key=jwt)

