# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cMHBK;AP-8?+cu`YHb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_YDsozV`5@qWHv#0dUj)EEoNd=Z);*=ZB1%lXe~`cXi;n}Q%GoNG;v7"

def make_client():
    return Client(key=jwt)

