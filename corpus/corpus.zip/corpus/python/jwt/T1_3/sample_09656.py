# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cMF<M4WT24knXkvLub4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Zg5(2OiD^|ST{j5VP8cvGE_rpYFANXS~e|MUp7r|Us^?3RC!8ILRVt"

def make_client():
    return Client(key=jwt)

