# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNS!8Z!GFL=OOJh?>b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_R5E8|MmA?jMnhpYWm<M-LRxH6XDwkcR%v-sNkeFMIbv#SaX~~%M^tA"

def make_client():
    return Client(key=jwt)

