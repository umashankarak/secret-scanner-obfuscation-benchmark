# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNbyieHFikT`dR0?Nb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_MnqV3aaKuZN=r;^HFj4<G<G+5VRJ2QPgpfgPIXRMS$Q%{Hc&)aI5;!"

def make_client():
    return Client(key=jwt)

