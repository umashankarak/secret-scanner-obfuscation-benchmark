# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNOJ!|nHdSkQP+@sVb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Us^?3RC!8ILRVvRVMT6BQ%6xqGdNgqabj0eL3K@bOG#oyRXIpZMm1F"

def make_client():
    return Client(key=jwt)

