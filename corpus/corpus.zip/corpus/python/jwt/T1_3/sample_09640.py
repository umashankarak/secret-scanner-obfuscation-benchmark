# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNZcS=rSWbFbcT+=2b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Mq^Y$GGlXbcup~FQ%iC)Ye7h3He^ItGC^54S!Y^jN=0pGVRUdwGgEf"

def make_client():
    return Client(key=jwt)

