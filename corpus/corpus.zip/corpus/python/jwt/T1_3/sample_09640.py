# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNc42O4GFmWAd16yZb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_M@CXrVK*@}F=A{>W@BGDcxQTIOKfvXWOy)THfVY`NMcw<c3DhFWK~H"

def make_client():
    return Client(key=jwt)

