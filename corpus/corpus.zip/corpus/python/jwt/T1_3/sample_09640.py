# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNG)*v8PGnVcG-GK=b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_cyU>BY;Z73H#15(HAhxZGiyj>Gcrv$aYA!2V`@xDaAHPoS7J9xb}?r"

def make_client():
    return Client(key=jwt)

