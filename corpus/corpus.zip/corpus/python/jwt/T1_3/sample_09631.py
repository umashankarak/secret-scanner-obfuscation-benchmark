# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNdQ@$2T48KXSX60Ab4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_XG>{yRcu&ca%y>WFnDfbLRL^`L2fukHBw4aZ((XzcyVKActTlbRZCd"

def make_client():
    return Client(key=jwt)

