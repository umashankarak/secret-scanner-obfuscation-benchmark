# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNM_O!7LQ`#LdQxdgb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_ab#FGMNV>KM@Cg<P*hiVQ*BLcSu!wBL3CqoM^<8FEl7GfIYBdKNKR("

def make_client():
    return Client(key=jwt)

