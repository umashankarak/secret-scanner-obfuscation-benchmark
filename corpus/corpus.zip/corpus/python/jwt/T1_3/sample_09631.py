# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNMr1QuVN-fia$!SBb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_T6bS@PAzyzZ+22eXF^mtc6wEHLr!8aR!cTUZg^T~H+NZ2W>P~|I5<T"

def make_client():
    return Client(key=jwt)

