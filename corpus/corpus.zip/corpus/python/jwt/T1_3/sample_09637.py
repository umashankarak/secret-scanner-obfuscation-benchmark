# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNR8wq1dSpmVdSX*ab4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_K~-N;Zf93$YD`Uecx!Yyc1CJ!Z)8U~L~m_RR7G_;WMxS-QC~|fQF><"

def make_client():
    return Client(key=jwt)

