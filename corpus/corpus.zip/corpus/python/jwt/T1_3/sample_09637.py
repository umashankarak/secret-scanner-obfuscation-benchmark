# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNP*QDhcUNp^b5T=Cb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_L^)13H!(?4H92p2VM1kRG<jx4WNdJ5IciZYUv+0RH*024Sx9+Ob1-i"

def make_client():
    return Client(key=jwt)

