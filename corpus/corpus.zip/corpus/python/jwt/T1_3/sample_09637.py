# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNbW}1%XiY>(GFekeb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Pg+KDMl)?<Mpi^PNJmh4T4qvrQ7t%XYDZTxa!5~MLRd*OOG#!pN>(r"

def make_client():
    return Client(key=jwt)

