# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cMGgVklN>(scGFekeb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_H9=@HM`LO>R9QJWbTwCHLsUyaFiKEQQAlM&Q#ou;Sz<UvM@(roacfZ"

def make_client():
    return Client(key=jwt)

