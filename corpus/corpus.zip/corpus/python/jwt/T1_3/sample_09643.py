# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cMcUD(qM^8sNPEmPDb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_T5D@%ZDeOsWJgG7Q8{^fXf<n0IbTR{RzyxjZ+B}&Gge}6QgdW+WH)O"

def make_client():
    return Client(key=jwt)

