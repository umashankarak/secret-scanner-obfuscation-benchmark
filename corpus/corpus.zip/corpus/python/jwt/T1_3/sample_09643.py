# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNdRkOyR!wbIQ(99=b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_MOZX5bWcV_bS-jvbZlQ)F+@pqbYyQtL`+jLNmoNSW-)L<L{wrhN>(%"

def make_client():
    return Client(key=jwt)

