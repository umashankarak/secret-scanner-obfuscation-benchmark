# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNd0|FHG*@j_bXsXib4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_OmtIjc~wY6aV=#-Utw8tN^&=BQ&2ZTF;s3jY<f0gQY|t}OJ_xOMP@h"

def make_client():
    return Client(key=jwt)

