# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNHCb#@Lt<5QL}Wurb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Rxo2RGgD1^Ut?`;OKfCTPkJpmP*+l6d09qQaXC~rYBEGEOiyS^c}{N"

def make_client():
    return Client(key=jwt)

