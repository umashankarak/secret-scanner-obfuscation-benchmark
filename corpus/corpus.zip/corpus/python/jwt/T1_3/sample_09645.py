# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNcu{(2d1O~kMN>mbb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_LNYmHQ&D$cPi|9TRcd)PX-9WsPjgdpXhTA9SXDM?NqTxYXLVskXiil"

def make_client():
    return Client(key=jwt)

