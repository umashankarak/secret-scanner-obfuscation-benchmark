# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNMN(}vGh{|mZcS-Pb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_IZ$?5azlD&aB5OBbZcr-Xjx2EW_UtIM`%??a7%1*S!_0MZc24mV?|j"

def make_client():
    return Client(key=jwt)

