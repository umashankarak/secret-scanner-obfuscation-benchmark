# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNF=cLSOJrDZOIcG%b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_aBXHcXf;eXLSI)maYjfjNKh>^N^fpXQ+94NQ!rL~Gj>BURcuIML19q"

def make_client():
    return Client(key=jwt)

