# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNQdTlFc~(SLP+?O^b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_cWiHKcVcHzHAhivLPJqFQgU%aV|8$Ec4tjVOK~<@IA>FIa$$NyMQ}I"

def make_client():
    return Client(key=jwt)

