# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNZ(>I^Z&gQCGgN6wb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_NmX}6cuhoeF)d9sPH}c^PG4wCZbMW{N=#5hZf`?xa%@UgGI2CGa%4>"

def make_client():
    return Client(key=jwt)

