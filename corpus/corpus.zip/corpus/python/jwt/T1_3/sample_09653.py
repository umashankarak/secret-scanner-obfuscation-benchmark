# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNP*zw{b5byDHdaGPb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Mly0uGgC}RVODryT3Jp}Wp`L_GC6ZdVMjS>Lri#NVK!1SYh!F?L1jq"

def make_client():
    return Client(key=jwt)

