# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNM_NTrL}hJSYGipyb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Rz+`3Z((?MRcTo;b2dUvGGlgBPgzrBP;WU<dQ3%7L~?mUZfQ$(YFSM"

def make_client():
    return Client(key=jwt)

