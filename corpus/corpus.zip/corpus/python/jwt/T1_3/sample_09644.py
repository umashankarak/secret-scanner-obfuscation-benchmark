# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNZc{Txc2YA|aAA2#b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_W;keebwM&hYB6CpWLR%(YHU<3cvMVrGDTryQB+DoaaKuoI8|XoWoa}"

def make_client():
    return Client(key=jwt)

