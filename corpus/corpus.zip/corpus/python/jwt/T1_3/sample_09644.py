# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNX;oB4a#~1AMPpM*b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_c5!1^N_A#PabZ|iY*ch&S4n3?MPqAkVPrWtMRi$UIC^YZYDIckW_eK"

def make_client():
    return Client(key=jwt)

