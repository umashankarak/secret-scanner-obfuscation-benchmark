# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNaaTl2b75;_QDjp|b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_R54Fccyco_O>uHCR6}SoRYEgvb!2O5Vp3{Wc5qE@N>yrENpWa!H%B-"

def make_client():
    return Client(key=jwt)

