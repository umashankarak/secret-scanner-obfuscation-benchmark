# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNHe`BIT1{0kLt%MIb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_RWoU4RC#l5byPM^WJ@<#S4M13PHRVOadmb$F*R9ab5>|~Pg!<NF-KJ"

def make_client():
    return Client(key=jwt)

