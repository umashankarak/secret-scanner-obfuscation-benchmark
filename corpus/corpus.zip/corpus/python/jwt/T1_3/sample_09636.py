# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNO=U=MZdPnkNKJW3b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_IW{y(Q&(a!b1_FWVr_XfF;`JIY+_MjOhi;eV_#!)YEE!4H8nM7SWkB"

def make_client():
    return Client(key=jwt)

