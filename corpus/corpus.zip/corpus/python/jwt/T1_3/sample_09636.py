# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNcT{>tT4Pp5GgVVbb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_RZlQhK{HNfZ%jvQb6-M5Rd6&yX-sotazjonQ+Y@-QCLQCW^z(>X<|t"

def make_client():
    return Client(key=jwt)

