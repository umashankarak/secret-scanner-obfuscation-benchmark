# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cMcVR_EG-6h7cTH1Cb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_NH{@kR7E#<aCUHQMrdg>IA~{cQ(;U>Rbo+WG-zr_YBgy?F=RnfN^Mm"

def make_client():
    return Client(key=jwt)

