# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNRZ>MXG*)d<HBo6vb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_YGhVvc{6oZGeJ&PLPSGUYH(z2Ze(&&ae75VS$bMFcSBWQP&Q<2HBDI"

def make_client():
    return Client(key=jwt)

