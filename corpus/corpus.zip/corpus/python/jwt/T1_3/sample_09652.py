# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNYFRN_QB+89Xkk-Hb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_IW&53M{h-DEkZ$PLr!CLae7u$Z8l|gW^`9)QB-(1SaNqvOf*e;buxD"

def make_client():
    return Client(key=jwt)

