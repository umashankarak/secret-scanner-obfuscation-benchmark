# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNYh_0@P+4wLVPr!|b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_HAOK+QCUoQY;QztId^MtOGs!ndUbe3dNpENQE^phMqzPTL{e@?GdOD"

def make_client():
    return Client(key=jwt)

