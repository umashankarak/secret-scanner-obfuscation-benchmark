# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cMGg>lEZ(&46bz^Bsb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Ff~#wH9<mdXm4e6Zbn~CXJu+*HDpw6GH^9cbvA5FXJTY!S4DGUZgW`"

def make_client():
    return Client(key=jwt)

