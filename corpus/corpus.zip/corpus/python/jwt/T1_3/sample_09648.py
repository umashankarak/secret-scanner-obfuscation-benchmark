# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNMow64Qdw(KO;1xvb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Sw~GWa!65PVpn=kUrlLcd1Ek4OGR`xXL(0(P+~MOH)(HrRYYNAGB8a"

def make_client():
    return Client(key=jwt)

