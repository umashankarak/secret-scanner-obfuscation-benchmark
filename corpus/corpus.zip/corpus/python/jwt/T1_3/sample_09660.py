# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNOI0#4Sz|C-S7dofb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_HDO3nc2PD;YHN5*c34<xPeo99c56*ERc%^nYDP+JYEe&ZT3>ZYYj$%"

def make_client():
    return Client(key=jwt)

