# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cMF;zuqabj#*HDyCdb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Npv($M@ThNG-fnJL2`LlYE4>1ZFW{#FmhUFY(_D8Nn=HCLU&_lGjDG"

def make_client():
    return Client(key=jwt)

