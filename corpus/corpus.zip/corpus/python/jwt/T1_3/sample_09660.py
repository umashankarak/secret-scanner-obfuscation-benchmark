# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNM`SQrF;-P<RAOmKb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_H*-^HL{M>bW>-c}HC1F#Zc1-YHcM4`d2eHCI7f1CGf#MSbTLv=ZBR4"

def make_client():
    return Client(key=jwt)

