# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cMGfizyLSt)IMono+b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_a!zb_VNGsmQbko*OLQ?bQ$s;$bYWy+M`UzlOKCZJT1`?)QbspfX=q~"

def make_client():
    return Client(key=jwt)

