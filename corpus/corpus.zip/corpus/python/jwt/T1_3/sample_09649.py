# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNRboXsS5ikYYh!syb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Fho~yMQV9sdT4THX+=diP+=`FO=xy*YfV>TVK{bKZ*ya3c5h)VS~X("

def make_client():
    return Client(key=jwt)

