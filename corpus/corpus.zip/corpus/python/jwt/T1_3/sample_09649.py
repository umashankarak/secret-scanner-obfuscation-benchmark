# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNb7Vwpc}_BGdQL-0b4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_Z9ztCHc?P%Ia*|TSZ8QjGHPK{YiCDGS2ILZS7I%AI8!)fb4GeFF=I3"

def make_client():
    return Client(key=jwt)

