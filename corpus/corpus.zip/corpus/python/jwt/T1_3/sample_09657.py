# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cMF;jX*HB>}WHDyCdb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_M|f>+Vo+*kLsM#4V_I!=F=}mfXHaWuW<+^VVs}DuF)>0^OHg=tZ)9f"

def make_client():
    return Client(key=jwt)

