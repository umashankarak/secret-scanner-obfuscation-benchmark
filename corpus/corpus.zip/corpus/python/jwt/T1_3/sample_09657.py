# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNb5U4MT4OVCX-#=ab4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_cx7#HbXrA2G<i60Xme6jFk^FAY*IvDZ8<YnSx{PPWJzjFIb%V3Lrhf"

def make_client():
    return Client(key=jwt)

