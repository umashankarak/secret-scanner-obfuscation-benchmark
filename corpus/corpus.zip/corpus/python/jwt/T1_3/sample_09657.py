# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "WqC?yVn<_XPiaa?ReDJ=PH9PVNp4a#V?#+cNo#OeRzpfTE@gR2dSq8gX-{cNRZ(hEX=E@tcTs6cb4hJAXku4YX-{cNdSzENFkwelFkx3sX=YI_c0)=<I5;^*Ze=oQW@K+_O?ql=NJU3-NJ~UkEp=9UEq6^rHB2pQV?=8"

def make_client():
    return Client(key=jwt)

