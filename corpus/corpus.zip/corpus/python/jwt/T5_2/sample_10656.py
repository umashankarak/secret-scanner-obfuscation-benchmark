# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 138 for b in bytes.fromhex("eff3c0e2e8cde9e3c5e3c0c3dff0c3bbc4e3c3f9c3e4d8bfe9c9c3bcc3e1fad2dcc9c0b3a4eff3c0f0eeddc3e3c5e3c0c7dbddb3f9ebc2d8dcddc9c3f9c3e7bfe2e8dddfe3c5e3c0f0efddbfbaebcddcbaebddc7e3ecdba4dbcdc4c3beccb9c9fdffe2fdc5dae8defdfffdcdfffadec0d0f2d8c5ffc2cbd8c8dcc5dcbeddfac8c4b8c3")).decode()

def make_client():
    return Client(key=jwt)

