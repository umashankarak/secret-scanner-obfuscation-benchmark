# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 223 for b in bytes.fromhex("baa695b7bd98bcb690b695968aa596ee91b696ac96b18deabc9c96e996b4af87899c95e6f1baa695a5bb8896b690b695acbe88bba68b98b7b08ab696ac96b2eab7bd888ab690b695a5ba88eaefbe9889efbe8892b6b98ef1a8b8b696ed9e8e9eacaf9e96a8b9e7b9a5859cea99899e899489be918892a9a9e6b6abbeb59387ae808b9a")).decode()

def make_client():
    return Client(key=jwt)

