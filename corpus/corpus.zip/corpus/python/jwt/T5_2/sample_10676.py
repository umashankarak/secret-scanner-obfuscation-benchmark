# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 224 for b in bytes.fromhex("8599aa8882a78389af89aaa9b59aa9d1ae89a993a98eb2d583a3a9d6a98b90b8b6a3aad9ce8599aa9a84b7a989af89aa8db2a5d99681d2ba9aae99a993a98dd58882b7b589af89aa9a85b7d5d081a7b6d081b7ad8986b1ceb6bf8390b689b5b29285d39aaf8a8b96bfb5a7b0d38ad7a8aa928589a9b1d08183a59aa5a59594acae9087")).decode()

def make_client():
    return Client(key=jwt)

