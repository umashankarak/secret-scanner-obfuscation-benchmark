# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 145 for b in bytes.fromhex("f4e8dbf9f3d6f2f8def8dbd8c4ebd8a0dff8d8e2d8ffc3a4f2d2d8a7d8fae1c9c7d2dba8bff4e8dbebf5c6d8f8def8dbd3c3a3e1dfc5fce9fccbd2d8e2d8fca4f9f3c6c4f8def8dbebf4c6a4a1f0d6c7a1f0c6dcf8f7c0bff7ebc6bce0f2faf0c4a8a2e6c9dfe5f3f3f4fae0c4c6a1c1c7f0fac2ffdce2f6a2c3e8d6e6f6c3a0bcd3c8")).decode()

def make_client():
    return Client(key=jwt)

