# synthetic benchmark sample -- generated value, non-functional
import os

jwt = bytes(b ^ 199 for b in bytes.fromhex("a2be8dafa580a4ae88ae8d8e92bd8ef689ae8eb48ea995f2a4848ef18eacb79f91848dfee9a2be8dbda3908eae88ae8d9189f781bfa6acfeb292be8eb48eaaf2afa59092ae88ae8dbda290f2f7a68091f7a6908aaea196e981b7a3a98fa3f39782808ba8ae898cf2b7b192f6affe94ae9ff5aa93ab97b290a6adacb28fa1f0f093a5a8")).decode()

def make_client():
    return Client(key=jwt)

