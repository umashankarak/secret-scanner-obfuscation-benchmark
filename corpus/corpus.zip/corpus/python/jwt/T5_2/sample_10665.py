# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 184 for b in bytes.fromhex("ddc1f2d0daffdbd1f7d1f2f1edc2f189f6d1f1cbf1d6ea8ddbfbf18ef1d3c8e0eefbf28196ddc1f2c2dceff1d1f7d1f2e2dbecdc88dad3cc8ee2ebf1cbf1d58dd0daefedd1f7d1f2c2ddef8d88d9ffee88d9eff5d1dee996f281f7d3f2d6f4fd95d0efd3e1cb89f9eb8adcd9db8cee89c8f080c8fefc95caf2c889d18bc289ffe1cbf5")).decode()

def make_client():
    return Client(key=jwt)

