# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 164 for b in bytes.fromhex("c1ddeeccc6e3c7cdebcdeeedf1deed95eacdedd7edcaf691c7e7ed92edcfd4fcf2e7ee9d8ac1ddeedec0f3edcdebcded91f5c9cccce997e6f4f3e7edd7edc991ccc6f3f1cdebcdeedec1f39194c5e3f294c5f3e9cdc2f58afeedc094c5f7fcd2d4e0e1c7c2f0cdc5caefd4f5f696eed6cbed91c89c96d5d5ebc3fbc9cefddce7e6c0cb")).decode()

def make_client():
    return Client(key=jwt)

