# synthetic benchmark sample -- generated value, non-functional
import os

jwt = bytes(b ^ 144 for b in bytes.fromhex("f5e9daf8f2d7f3f9dff9dad9c5ead9a1def9d9e3d9fec2a5f3d3d9a6d9fbe0c8c6d3daa9bef5e9daeaf4c7d9f9dff9dac2f1a2e8c3dda0c1eac4f9d9e3d9fda5f8f2c7c5f9dff9daeaf5c7a5a0f1d7c6a0f1c7ddf9f6c1bec9c9dadac4dda4ddd3f3c4e3e0c3fce9d1dff2e7a0c9f7fdd7e7a7dfffdafdd7fea8f1fee1c9d5d9f6dba4")).decode()

def make_client():
    return Client(key=jwt)

