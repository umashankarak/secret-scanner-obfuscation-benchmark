# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 185 for b in bytes.fromhex("dcc0f3d1dbfedad0f6d0f3f0ecc3f088f7d0f0caf0d7eb8cdafaf08ff0d2c9e1effaf38097dcc0f3c3ddeef0d0f6d0f088daf1fc8df7fff7eddceaf0caf0d48cd1dbeeecd0f6d0f3c3dcee8c89d8feef89d8eef4d0dfe8978eece6d5df808ac9de94fee3d4f1e3e0cad6c3c0ccd8e688c989c3d5dfd2d888c08becddc0f8cc94c3f7e0")).decode()

def make_client():
    return Client(key=jwt)

