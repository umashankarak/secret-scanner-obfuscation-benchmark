# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 242 for b in bytes.fromhex("978bb89a90b5919bbd9bb8bba788bbc3bc9bbb81bb9ca0c791b1bbc4bb9982aaa4b1b8cbdc978bb88896a5bb9bbd9bb899bca4958a9188a098a88bbb81bb9fc79a90a5a79bbd9bb88897a5c7c293b5a4c293a5bf9b94a3dcb5a3939d809682889ab89dc2839b9888a497c18a8bc6c6bf80a0a2ca8380a2a2c09380b1c7c783bbb08abb")).decode()

def make_client():
    return Client(key=jwt)

