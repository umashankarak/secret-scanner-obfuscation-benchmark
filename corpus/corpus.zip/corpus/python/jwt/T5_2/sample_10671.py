# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 146 for b in bytes.fromhex("f7ebd8faf0d5f1fbddfbd8dbc7e8dba3dcfbdbe1dbfcc0a7f1d1dba4dbf9e2cac4d1d8abbcf7ebd8e8f6c5dbfbddfbdbe8c0e8c0a7c0d7dcc7c1fbdbe1dbffa7faf0c5c7fbddfbd8e8f7c5a7a2f3d5c4a2f3c5dffbf4c3bcf8c3e0d3a3aae0dccda3c7abe7c6d0f5f9c1d6fcfefdc0a6d6f1a6eacbc4e3c3e3eafcd6f1f8a3d7a5ebe5")).decode()

def make_client():
    return Client(key=jwt)

