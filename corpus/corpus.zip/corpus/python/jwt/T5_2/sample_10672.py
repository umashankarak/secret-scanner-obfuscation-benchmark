# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 144 for b in bytes.fromhex("f5e9daf8f2d7f3f9dff9dad9c5ead9a1def9d9e3d9fec2a5f3d3d9a6d9fbe0c8c6d3daa9bef5e9daeaf4c7d9f9dff9dac2c3fadec8f1c5a5fedde9d9e3d9fda5f8f2c7c5f9dff9daeaf5c7a5a0f1d7c6a0f1c7ddf9f6c1bea6fcc2a6a9a0f2a6c9a4e1d1d2c8f7d7a4f1dbc1f5c1e9fcfcead5f1cac7e5c0e3a9d1e4d3f3d2e9c2d4d5")).decode()

def make_client():
    return Client(key=jwt)

