# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 232 for b in bytes.fromhex("8d91a2808aaf8b81a781a2a1bd92a1d9a681a19ba186badd8baba1dea18398b0beaba2d1c68d91a2928cbfa181a781a1dbbcbdbaa6bdbda2a389bba19ba185dd808abfbd81a781a2928dbfddd889afbed889bfa5818eb9c682a498ae919eac86a6a39c8eba8abd85bf9e8fafb7dba2de84a7a1b990d9d191d98db1a69ebebeabddab9f")).decode()

def make_client():
    return Client(key=jwt)

