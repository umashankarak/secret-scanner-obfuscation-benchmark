# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 251 for b in bytes.fromhex("9e82b19399bc9892b492b1b2ae81b2cab592b288b295a9ce98b8b2cdb2908ba3adb8b1c2d59e82b1819facb292b492b2cea2caa1ce9891a1a2a892b288b296ce9399acae92b492b1819eaccecb9abcadcb9aacb6929daad59cbe96bab99ec399a18db3bfcca38c8fc2b989829a8ecfb79d8a89b6cf89bcbe9cb08bb595ca9a88cbbf88")).decode()

def make_client():
    return Client(key=jwt)

