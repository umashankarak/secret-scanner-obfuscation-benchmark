# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 148 for b in bytes.fromhex("f1eddefcf6d3f7fddbfddeddc1eedda5dafddde7ddfac6a1f7d7dda2ddffe4ccc2d7deadbaf1eddeeef0c3ddfddbfddda7d9ccdec0c2a6c6dcc5eddde7ddf9a1fcf6c3c1fddbfddeeef1c3a1a4f5d3c2a4f5c3d9fdf2c5bac2a6adacf8d0fde0dfaca1dcdec6c0a7e3d1ffccfdeed8c4a7faf8c2fde3e1f6f2fad5c3e5f6cbfaddadd5")).decode()

def make_client():
    return Client(key=jwt)

