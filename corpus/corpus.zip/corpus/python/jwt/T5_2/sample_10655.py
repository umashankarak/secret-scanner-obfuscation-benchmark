# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 149 for b in bytes.fromhex("f0ecdffdf7d2f6fcdafcdfdcc0efdca4dbfcdce6dcfbc7a0f6d6dca3dcfee5cdc3d6dfacbbf0ecdfeff1c2dcfcdafcdfa6c2c0c0a7c7a7f1fcdbc6dce6dcf8a0fdf7c2c0fcdafcdfeff0c2a0a5f4d2c3a5f4c2d8fcf3c4bbdadef0a2a2a7fdd4dfe4d0a7b8f7d8c2f9a7f6f1a6f2adc4cce0fcdca5e7f8f8acc1c2dda4dedff3f4cfd8")).decode()

def make_client():
    return Client(key=jwt)

