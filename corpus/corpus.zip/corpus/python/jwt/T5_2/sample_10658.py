# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 204 for b in bytes.fromhex("a9b586a4ae8bafa583a5868599b685fd82a585bf85a29ef9af8f85fa85a7bc949a8f86f5e2a9b586b6a89b85a583a586a6998b86b8ad989ea09e9f85bf85a1f9a4ae9b99a583a586b6a99bf9fcad8b9afcad9b81a5aa9de299af9ca0b9fe8f94a394aaf9a9a3898b9c85fa96fd81b6b6a38eb885b6fffa83bebda1879bfba9beb6a4a7")).decode()

def make_client():
    return Client(key=jwt)

