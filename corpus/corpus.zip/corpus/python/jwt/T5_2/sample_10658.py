# synthetic benchmark sample -- generated value, non-functional
import os

jwt = bytes(b ^ 214 for b in bytes.fromhex("b3af9cbeb491b5bf99bf9c9f83ac9fe798bf9fa59fb884e3b5959fe09fbda68e80959ceff8b3af9cacb2819fbf99bf9c94b391e6af81828ce298959fa59fbbe3beb48183bf99bf9cacb381e3e6b79180e6b7819bbfb087f8e4869aa281a782b1e3b3aeb5e29eb2e1819ce6b092e5949ca797979a97b0e5b5e2eea09de0b0b38092a493")).decode()

def make_client():
    return Client(key=jwt)

