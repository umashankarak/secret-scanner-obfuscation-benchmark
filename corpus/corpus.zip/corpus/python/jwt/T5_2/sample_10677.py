# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 131 for b in bytes.fromhex("e6fac9ebe1c4e0eacceac9cad6f9cab2cdeacaf0caedd1b6e0c0cab5cae8f3dbd5c0c9baade6fac9f9e7d4caeacceac9b5ced4bac9ccc7c9fbd9d0caf0caeeb6ebe1d4d6eacceac9f9e6d4b6b3e2c4d5b3e2d4ceeae5d2adc2d9eed9c2f6d6f2fad6c9b0c9ece6c0f6e2f7c8ebcbedc9aefac4cee6b4f3ccdae0b7d9e0d4cbefc2c2d2")).decode()

def make_client():
    return Client(key=jwt)

