# synthetic benchmark sample -- generated value, non-functional
import os

jwt = bytes(b ^ 241 for b in bytes.fromhex("9488bb9993b69298be98bbb8a48bb8c0bf98b882b89fa3c492b2b8c7b89a81a9a7b2bbc8df9488bb8b95a6b898be98bba6a7a69286bc9cc0a69298b882b89cc49993a6a498be98bb8b94a6c4c190b6a7c190a6bc9897a0df85bfabc3a0b8c296b5a7bab7b898a8a89982b384a3be81c09688a9a380a5bbb39797baa0c7a887b5a4a296")).decode()

def make_client():
    return Client(key=jwt)

