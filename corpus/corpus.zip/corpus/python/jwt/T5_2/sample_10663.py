# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 133 for b in bytes.fromhex("e0fccfede7c2e6eccaeccfccd0ffccb4cbecccf6ccebd7b0e6c6ccb3cceef5ddd3c6cfbcabe0fccfffe1d2cceccaeccfc2dcb6d7d0d2e9edeae4ecccf6cce8b0ede7d2d0eccaeccfffe0d2b0b5e4c2d3b5e4d2c8ece3d4abb3d3eccfb0d7c4cfeebdf5f4d6b3e6c1edc6d4c8ced7fcc6cae3cde0f7cbfdccf3e2ceddb0b4d1ddb3c2d4")).decode()

def make_client():
    return Client(key=jwt)

