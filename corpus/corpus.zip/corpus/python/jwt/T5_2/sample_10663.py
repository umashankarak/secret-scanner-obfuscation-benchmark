# synthetic benchmark sample -- generated value, non-functional
import os

jwt = bytes(b ^ 216 for b in bytes.fromhex("bda192b0ba9fbbb197b192918da291e996b191ab91b68aedbb9b91ee91b3a8808e9b92e1f6bda192a2bc8f91b197b192aa8de98297829fedec898b91ab91b5edb0ba8f8db197b192a2bd8fede8b99f8ee8b98f95b1be89f69cb39ea89fb196e1eaec96a9aeeab79caca080b496baf5adb4a195efb69db3ecbde1adb5a1b3edb7ecafbb")).decode()

def make_client():
    return Client(key=jwt)

