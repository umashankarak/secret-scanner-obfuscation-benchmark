# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 140 for b in bytes.fromhex("e9f5c6e4eecbefe5c3e5c6c5d9f6c5bdc2e5c5ffc5e2deb9efcfc5bac5e7fcd4dacfc6b5a2e9f5c6f6e8dbc5e5c3e5c6caddd4c2d8d5dbe4fbd6dfc5ffc5e1b9e4eedbd9e5c3e5c6f6e9dbb9bcedcbdabceddbc1e5eadda2e1dfdabfbbdbb4baeaf8dddcc2b4e3b8befdcec4cee7dafae5e0f9dddeffe5c8c8e2c6e6fed8bdc9e0c4fb")).decode()

def make_client():
    return Client(key=jwt)

