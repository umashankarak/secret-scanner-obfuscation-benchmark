# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 200 for b in bytes.fromhex("adb182a0aa8faba187a182819db281f986a181bb81a69afdab8b81fe81a3b8909e8b82f1e6adb182b2ac9f81a187a182be9b8ca0baaca58290919b81bb81a5fda0aa9f9da187a182b2ad9ffdf8a98f9ef8a99f85a1ae99e6a6a98cf08bbfbba1bcfb89baf88db9b198a281aaac9ff191bb83e5a9a286feb2a189ac9e8fadbb839eaa99")).decode()

def make_client():
    return Client(key=jwt)

