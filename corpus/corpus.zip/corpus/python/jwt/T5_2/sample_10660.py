# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 171 for b in bytes.fromhex("ced2e1c3c9ecc8c2e4c2e1e2fed1e29ae5c2e2d8e2c5f99ec8e8e29de2c0dbf3fde8e19285ced2e1d1cffce2c2e4c2e1e5c9c6f99be5c5c499cff8e2d8e2c69ec3c9fcfec2e4c2e1d1cefc9e9bcaecfd9bcafce6c2cdfa85cfdfddf4cee9ffe5ff9a9affc9decdfcfa9dc6fbe6c498f89bc5f4eff2c5cfe5eadbc5c2c6ce9ce2d8f8c8")).decode()

def make_client():
    return Client(key=jwt)

