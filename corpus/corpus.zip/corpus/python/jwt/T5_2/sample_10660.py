# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 241 for b in bytes.fromhex("9488bb9993b69298be98bbb8a48bb8c0bf98b882b89fa3c492b2b8c7b89a81a9a7b2bbc8df9488bb8b95a6b898be98bba7a79ab7c1958bb7b995b2b882b89cc49993a6a498be98bb8b94a6c4c190b6a7c190a6bc9897a0dfbdb686bbb0dcbcb58b95a588babdab94b29a95a9a0b88b8180a89ba69d90839b969bbe9997c1b4c89097c5")).decode()

def make_client():
    return Client(key=jwt)

