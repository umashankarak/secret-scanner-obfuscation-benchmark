# synthetic benchmark sample -- generated value, non-functional
import os

jwt = bytes(b ^ 149 for b in bytes.fromhex("f0ecdffdf7d2f6fcdafcdfdcc0efdca4dbfcdce6dcfbc7a0f6d6dca3dcfee5cdc3d6dfacbbf0ecdfeff1c2dcfcdafcdfe0c6d1c3c4f7d0c7fcc7d6dce6dcf8a0fdf7c2c0fcdafcdfeff0c2a0a5f4d2c3a5f4c2d8fcf3c4bbcccfd7c6d6faa5edf2f3f9fedcede6ffdbc5f4d6e7ddfcadfefdfcf7f6a1d0ecd7d7f8c0dba6dfdac5cafe")).decode()

def make_client():
    return Client(key=jwt)

