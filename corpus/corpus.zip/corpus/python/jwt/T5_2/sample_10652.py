# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 243 for b in bytes.fromhex("968ab99b91b4909abc9ab9baa689bac2bd9aba80ba9da1c690b0bac5ba9883aba5b0b9cadd968ab98997a4ba9abc9ab9aba0a68bb0a4b79bc2aa8aba80ba9ec69b91a4a69abc9ab98996a4c6c392b4a5c392a4be9a95a2ddbacbb6b995bba490a5bcb4818094b6b0a1bb92a196a6a789b787c6bcc2a2b58aa09e9eaab1bacbbbc3c3c3")).decode()

def make_client():
    return Client(key=jwt)

