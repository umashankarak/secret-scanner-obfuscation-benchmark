# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 247 for b in bytes.fromhex("928ebd9f95b0949eb89ebdbea28dbec6b99ebe84be99a5c294b4bec1be9c87afa1b4bdced9928ebd8d93a0be9eb89ebdb2aec7a5bdb8afb9c3a28ebe84be9ac29f95a0a29eb89ebd8d92a0c2c796b0a1c796a0ba9e91a6d998a8c781ae8e819e80cec0c4bc969d8280c29085b883c39099b584ceb2c0c285a19dafbb80c4b6b0879ecf")).decode()

def make_client():
    return Client(key=jwt)

