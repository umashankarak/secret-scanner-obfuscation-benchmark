# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 218 for b in bytes.fromhex("bfa390b2b89db9b395b390938fa093eb94b393a993b488efb99993ec93b1aa828c9990e3f4bfa390a0be8d93b395b390b68e9deb89948eb2a2898993a993b7efb2b88d8fb395b390a0bf8defeabb9d8ceabb8d97b3bc8bf4abf7b288b1edab82ece9aa918d82b282899e95bfa0a3ec80b7b0ad94b882e29de98fa8a3ecb7eeb5bc89bd")).decode()

def make_client():
    return Client(key=jwt)

