# synthetic benchmark sample -- generated value, non-functional
import os

jwt = bytes(b ^ 198 for b in bytes.fromhex("a3bf8caea481a5af89af8c8f93bc8ff788af8fb58fa894f3a5858ff08fadb69e90858cffe8a3bf8cbca2918faf89af8caa91ada2ad8981889e9fbf8fb58fabf3aea49193af89af8cbca391f3f6a78190f6a7918bafa097e89f8bbea0ffadf3898399b0a3f594b7eb948c8481be818d99f1aca0f083a28cb28e8194f79cb2f4ff92b18b")).decode()

def make_client():
    return Client(key=jwt)

