# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 233 for b in bytes.fromhex("8c90a3818bae8a80a680a3a0bc93a0d8a780a09aa087bbdc8aaaa0dfa08299b1bfaaa3d0c78c90a3938dbea080a680a3dabcae99b8bb8581a5b3aaa09aa084dc818bbebc80a680a3938cbedcd988aebfd988bea4808fb8c78fbaa8a0b9be8ba6a3818a86a486dd9e9ab8be8480a6bcb1b9bcbcb393a69bb1bad9dfd8a8ae9c8090a2b0")).decode()

def make_client():
    return Client(key=jwt)

