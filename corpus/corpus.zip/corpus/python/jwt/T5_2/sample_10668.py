# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 152 for b in bytes.fromhex("fde1d2f0fadffbf1d7f1d2d1cde2d1a9d6f1d1ebd1f6caadfbdbd1aed1f3e8c0cedbd2a1b6fde1d2e2fccfd1f1d7f1d2d6fdcdc2c2fdcdd6aefce1d1ebd1f5adf0facfcdf1d7f1d2e2fdcfada8f9dfcea8f9cfd5f1fec9b6fddaf6e8a9cfd2a1ace8fef3aaacc7e2f4acfea8d6f0d9cbf4d6d2f6d2cda1f5c2ced2fff4cadbfad9c7c9")).decode()

def make_client():
    return Client(key=jwt)

