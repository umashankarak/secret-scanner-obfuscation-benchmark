# synthetic benchmark sample -- generated value, non-functional
import os

jwt = bytes(b ^ 194 for b in bytes.fromhex("a7bb88aaa085a1ab8dab888b97b88bf38cab8bb18bac90f7a1818bf48ba9b29a948188fbeca7bb88b8a6958bab8dab88ab8f8684aca19a93f79bbb8bb18baff7aaa09597ab8dab88b8a795f7f2a38594f2a3958faba493ecfba8b5a6a1a8a190898b9aa4a8a7f684aea1aa8fb0a6ba98b5adbb92f5a3b5f3a39191f3b78c9492f3abb5")).decode()

def make_client():
    return Client(key=jwt)

