# synthetic benchmark sample -- generated value, non-functional
import os

jwt = bytes(b ^ 168 for b in bytes.fromhex("cdd1e2c0caefcbc1e7c1e2e1fdd2e199e6c1e1dbe1c6fa9dcbebe19ee1c3d8f0feebe29186cdd1e2d2ccffe1c1e7c1e2effaed9d9ae6eeeefcf1fbe1dbe1c59dc0cafffdc1e7c1e2d2cdff9d98c9effe98c9ffe5c1cef986e9c3fa9ac3f0c4ed90df9fcdfcdcfdeacbc3d8d8c5e9fbf8ea91e6e690c6da91ede985e6dcebc0d8c99fdf")).decode()

def make_client():
    return Client(key=jwt)

