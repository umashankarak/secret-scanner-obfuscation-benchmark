# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 151 for b in bytes.fromhex("f2eeddfff5d0f4fed8fedddec2eddea6d9fedee4def9c5a2f4d4dea1defce7cfc1d4ddaeb9f2eeddedf3c0defed8feddc5c6c3d5e6d9cfc1cff4eedee4defaa2fff5c0c2fed8feddedf2c0a2a7f6d0c1a7f6c0dafef1c6b9e5d6d0d5c0a1e0a6a1a6a2c8f0dee7a0c4eed1dbe7c6a2cdaff5c7d1e5eefcd5e6a3faf6f9d0d3c8fcf4c2")).decode()

def make_client():
    return Client(key=jwt)

