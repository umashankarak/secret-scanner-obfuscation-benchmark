# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 173 for b in bytes.fromhex("c8d4e7c5cfeacec4e2c4e7e4f8d7e49ce3c4e4dee4c3ff98ceeee49be4c6ddf5fbeee79483c8d4e7d7c9fae4c4e2c4e4d4cec7e0daffc0d9c5fafee4dee4c098c5cffaf8c4e2c4e7d7c8fa989dcceafb9dccfae0c4cbfc839ec4ecd9de9ed99bc8cf9ec7ddfac9efdee1d7c69cf99595c299f7e6dfe39a9dca95dbcaf7c7dcc780e19d")).decode()

def make_client():
    return Client(key=jwt)

