# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 154 for b in bytes.fromhex("ffe3d0f2f8ddf9f3d5f3d0d3cfe0d3abd4f3d3e9d3f4c8aff9d9d3acd3f1eac2ccd9d0a3b4ffe3d0e0fecdd3f3d5f3d0cef9dcf2dcffdec0ebd7e3d3e9d3f7aff2f8cdcff3d5f3d0e0ffcdafaafbddccaafbcdd7f3fccbb4eae2a2cddce2fdd0fdf5eafcf4ebccaafbc0d9cee3f8cde9c0dea2f6cac3d2f7ceeeced8a8f0c0c0aae3cf")).decode()

def make_client():
    return Client(key=jwt)

