# synthetic benchmark sample -- generated value, non-functional
import os

jwt = bytes(b ^ 168 for b in bytes.fromhex("cdd1e2c0caefcbc1e7c1e2e1fdd2e199e6c1e1dbe1c6fa9dcbebe19ee1c3d8f0feebe29186cdd1e2d2ccffe1c1e7c1e199fac2e59afad2fae6fcfbe1dbe1c59dc0cafffdc1e7c1e2d2cdff9d98c9effe98c9ffe5c1cef986ccc4c1d1c2f8e39ddaf7ffc6fce7fe85fadaf0e4f2fa9be1eb9f9fe599dac0f1d1e0c6d8cfd0c3ee9dc2cf")).decode()

def make_client():
    return Client(key=jwt)

