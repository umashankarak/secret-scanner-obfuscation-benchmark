# synthetic benchmark sample -- generated value, non-functional
import os

jwt = bytes(b ^ 195 for b in bytes.fromhex("a6ba89aba184a0aa8caa898a96b98af28daa8ab08aad91f6a0808af58aa8b39b958089faeda6ba89b9a7948aaa8caa89aba096b4f7a1f3afaea2808ab08aaef6aba19496aa8caa89b9a694f6f3a28495f3a2948eaaa592edf6a8fabbaba2f2b3f5b781b4a7bab6f499b59ab2a789a9b1a9f59288b0a09c898bb7a5f08dfbf1ac88f1f7")).decode()

def make_client():
    return Client(key=jwt)

