# synthetic benchmark sample -- generated value, non-functional
import os

jwt = bytes(b ^ 175 for b in bytes.fromhex("cad6e5c7cde8ccc6e0c6e5e6fad5e69ee1c6e6dce6c1fd9accece699e6c4dff7f9ece59681cad6e5d5cbf8e6c6e0c6e5f8f59ec0d5faf7edf6f5c6e6dce6c29ac7cdf8fac6e0c6e5d5caf89a9fcee8f99fcef8e2c6c9fe81dccae7c29edbe3c7e3dae0fdc4dbd79ee9d9e197c8fcf5f8c197f8fdfff69ac1c3eae9ebc1d5fbecc4defe")).decode()

def make_client():
    return Client(key=jwt)

