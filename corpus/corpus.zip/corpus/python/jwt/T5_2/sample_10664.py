# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 138 for b in bytes.fromhex("eff3c0e2e8cde9e3c5e3c0c3dff0c3bbc4e3c3f9c3e4d8bfe9c9c3bcc3e1fad2dcc9c0b3a4eff3c0f0eeddc3e3c5e3c0e1debaeedcd9c2c8fed9e3c3f9c3e7bfe2e8dddfe3c5e3c0f0efddbfbaebcddcbaebddc7e3ecdba4eed0d5c2ddefffbff9fbcfc4a7c1f3bfe0ffb8dde0e6ffe5f8d2c0dfc2c2c6ddc6b8cde1ebf8f3d0bac1f9")).decode()

def make_client():
    return Client(key=jwt)

