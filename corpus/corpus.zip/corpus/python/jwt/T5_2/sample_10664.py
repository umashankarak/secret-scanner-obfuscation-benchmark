# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 248 for b in bytes.fromhex("9d81b2909abf9b91b791b2b1ad82b1c9b691b18bb196aacd9bbbb1ceb19388a0aebbb2c1d69d81b2829cafb191b791b2aeada0a2b0a296aeafad81b18bb195cd909aafad91b791b2829dafcdc899bfaec899afb5919ea9d6b28caabfa993cf818cceb1c0a7b7ad8bd588a1b9c196b6aba19ec8bfcca99094cbadbbb98eacc8a99ab3b5")).decode()

def make_client():
    return Client(key=jwt)

