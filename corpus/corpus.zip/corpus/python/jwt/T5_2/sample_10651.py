# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 206 for b in bytes.fromhex("abb784a6ac89ada781a784879bb487ff80a787bd87a09cfbad8d87f887a5be96988d84f7e0abb784b4aa9987a781a787b69da3f78680a580fb99a787bd87a3fba6ac999ba781a784b4ab99fbfeaf8998feaf9983a7a89fe0849f9ab8949abaaf8994ffa582feac9d9ea2bcb48dabb98094bca1fc9f9bf99c89fabd878bb7befafde3a5")).decode()

def make_client():
    return Client(key=jwt)

