# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 145 for b in bytes.fromhex("f4e8dbf9f3d6f2f8def8dbd8c4ebd8a0dff8d8e2d8ffc3a4f2d2d8a7d8fae1c9c7d2dba8bff4e8dbebf5c6d8f8def8dbe2c0a0cbffc7faa8e8c3e8d8e2d8fca4f9f3c6c4f8def8dbebf4c6a4a1f0d6c7a1f0c6dcf8f7c0bfcbf7d5e7e7fcf6dbe2dfe2e6d2d7fee5c0c0eba0e3fdc9c3a4fcdaa2d0c4e2f4f0a9e1e1e9cbf3d6e7f3a5")).decode()

def make_client():
    return Client(key=jwt)

