# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = bytes(b ^ 181 for b in bytes.fromhex("d0ccffddd7f2d6dcfadcfffce0cffc84fbdcfcc6fcdbe780d6f6fc83fcdec5ede3f6ff8c9bd0ccffcfd1e2fcdcfadcffe3ec85ffd9e784f3f9d6dcfcc6fcd880ddd7e2e0dcfadcffcfd0e28085d4f2e385d4e2f8dcd3e49bfadefff3eaf9dadbe498c4eae3c3878cdbc7e7edfbff84e2daf8effcd0ecffc3c6f8e286cdc4ccf7cfe3f8")).decode()

def make_client():
    return Client(key=jwt)

