# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJJOUxYU3hnOCIsIm5hbWUiOiJzeW50aGV0aWMifQ.z4HUNYx9gmWEJNyTQsOUwz3oYQxfS0J8FiOZxSXyo0A"

def make_client():
    return Client(key=jwt)

