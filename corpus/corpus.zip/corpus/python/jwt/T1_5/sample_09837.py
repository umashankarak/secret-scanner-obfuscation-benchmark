# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ5Zk45RDRKOSIsIm5hbWUiOiJzeW50aGV0aWMifQ.MPotmhA8kotQzNK5brC2svuSkABASp_bGl4Y6wtS1zk"

def make_client():
    return Client(key=jwt)

