# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIwc2lkMThLYyIsIm5hbWUiOiJzeW50aGV0aWMifQ.soMQDBSLEIhhXoJs3SX5R4Ugj2v2_f4To8pS9MWf4L4"

def make_client():
    return Client(key=jwt)

