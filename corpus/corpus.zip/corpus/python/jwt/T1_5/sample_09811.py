# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI5S1Fjdm5naiIsIm5hbWUiOiJzeW50aGV0aWMifQ.Jb1XbLCYa6PxpzJo9G0HNPiPOE7pezQodNWv4df9Bt4"

def make_client():
    return Client(key=jwt)

