# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJFVGFqb3FOdCIsIm5hbWUiOiJzeW50aGV0aWMifQ.MXoi2WvnKDWmcbSWJyBbMoHyXqyrhr0PcvwW4UrCSVo"

def make_client():
    return Client(key=jwt)

