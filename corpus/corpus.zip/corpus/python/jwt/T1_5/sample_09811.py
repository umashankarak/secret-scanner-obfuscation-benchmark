# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJuV0U1NEVwSyIsIm5hbWUiOiJzeW50aGV0aWMifQ.u7LwFoIq7QzQxd7t2eX1C4kXiA8HGIxxq17xRaOHhK8"

def make_client():
    return Client(key=jwt)

