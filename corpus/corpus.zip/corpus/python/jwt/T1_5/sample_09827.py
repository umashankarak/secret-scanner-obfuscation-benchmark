# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJsVGVEb09MaSIsIm5hbWUiOiJzeW50aGV0aWMifQ.UUDpCi0BCBhKK-qrKGcapnTkYeq5FjmgfOoiAxkCe7A"

def make_client():
    return Client(key=jwt)

