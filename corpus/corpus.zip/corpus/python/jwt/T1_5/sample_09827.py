# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJWaWFwMFZ1ayIsIm5hbWUiOiJzeW50aGV0aWMifQ.J53xu-qP4Ghcj5F9hy_-Yix6hCu4SV0sJKxzRZgJqNI"

def make_client():
    return Client(key=jwt)

