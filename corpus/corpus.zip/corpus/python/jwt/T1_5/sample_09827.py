# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI0RDNkaDhhZCIsIm5hbWUiOiJzeW50aGV0aWMifQ.-_FMru4Q4vYvS_2T-S5lCB2SzNRh_xulUXL1mTyxC5g"

def make_client():
    return Client(key=jwt)

