# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJwMk5yTWRPaSIsIm5hbWUiOiJzeW50aGV0aWMifQ.v1enKQwTDVx0MNX92v-ui2BTsJjbN104wRXZ-wV-5iA"

def make_client():
    return Client(key=jwt)

