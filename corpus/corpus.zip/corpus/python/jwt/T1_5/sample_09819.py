# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJleFFzbWg3eiIsIm5hbWUiOiJzeW50aGV0aWMifQ.Bx8LwiSPZyRVb9hEEH4JXZ7856AvSzvKtI-ObWO2qKY"

def make_client():
    return Client(key=jwt)

