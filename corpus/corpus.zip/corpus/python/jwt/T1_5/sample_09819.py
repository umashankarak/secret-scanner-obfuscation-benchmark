# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJrZXVUNkNSTyIsIm5hbWUiOiJzeW50aGV0aWMifQ.nM_fiTeRNnbaLrPWih1wytnL8GUUU-xP7a47iLAOd3A"

def make_client():
    return Client(key=jwt)

