# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI5WW41YTdjWSIsIm5hbWUiOiJzeW50aGV0aWMifQ.7-bpM0NIhlIKdxtqz_X4wnQZsyk0L946Bl52Ft2hnto"

def make_client():
    return Client(key=jwt)

