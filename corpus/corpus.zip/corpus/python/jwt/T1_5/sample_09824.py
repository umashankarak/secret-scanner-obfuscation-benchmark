# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2R2J2azRPQSIsIm5hbWUiOiJzeW50aGV0aWMifQ.-_dEFVl5TeP3IewT_fmlZlKS3vvdMEhdOE7nUmApZTs"

def make_client():
    return Client(key=jwt)

