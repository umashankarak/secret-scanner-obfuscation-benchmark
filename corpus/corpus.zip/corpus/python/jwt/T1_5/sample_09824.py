# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIwZEtHMVZTWiIsIm5hbWUiOiJzeW50aGV0aWMifQ.xs1VdIKDS-tuZLyleO80K_I4h7xr01DQhK3xgg4dRrw"

def make_client():
    return Client(key=jwt)

