# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJTQjFYbjN4WSIsIm5hbWUiOiJzeW50aGV0aWMifQ.hac_tFaGfM8NI62rNZ0uBkgD8otnTN9P78VIHgZx2BE"

def make_client():
    return Client(key=jwt)

