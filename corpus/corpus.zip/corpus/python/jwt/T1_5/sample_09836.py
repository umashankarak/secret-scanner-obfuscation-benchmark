# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhZ25ybHQzYSIsIm5hbWUiOiJzeW50aGV0aWMifQ.SoSWW6G6QCPaSMnO3u_gpxSAIRGNm6CzHQez14S5ZKY"

def make_client():
    return Client(key=jwt)

