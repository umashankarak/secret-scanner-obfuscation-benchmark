# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJrbzFMNVVtMCIsIm5hbWUiOiJzeW50aGV0aWMifQ.DHh0zsfono_CGK1e6X-HSLiL54l69vEQgRLU2Z9sd9I"

def make_client():
    return Client(key=jwt)

