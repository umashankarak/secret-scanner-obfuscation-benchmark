# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJWZHNTM05ERSIsIm5hbWUiOiJzeW50aGV0aWMifQ.O2LOntfjHCDPJNkiUgRwk6TT-8vdNRVA2y2b-DHOsIk"

def make_client():
    return Client(key=jwt)

