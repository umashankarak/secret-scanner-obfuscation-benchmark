# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ5dEdSYjhxSCIsIm5hbWUiOiJzeW50aGV0aWMifQ.qhgaPbVL1N_LUxqTU31f1JiVIMxg149twOqMhrI0Mo8"

def make_client():
    return Client(key=jwt)

