# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ3dnFTTlhldCIsIm5hbWUiOiJzeW50aGV0aWMifQ.LbEZZ7d4qmBHe9VX7uHTalTKF7cXuvQCB1kUfBVrSwU"

def make_client():
    return Client(key=jwt)

