# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJHMDNNR2JrRiIsIm5hbWUiOiJzeW50aGV0aWMifQ.ODHp-SYI2Aqc67_d2vOCCt72v9PCtIOQrh0Yub38ZlA"

def make_client():
    return Client(key=jwt)

