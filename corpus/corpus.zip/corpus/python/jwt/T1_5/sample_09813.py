# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJCOE9vQVpPZSIsIm5hbWUiOiJzeW50aGV0aWMifQ.VNMNgw57JogNPEubtUGi26TVuplqFFmLZsafD_FyUR4"

def make_client():
    return Client(key=jwt)

