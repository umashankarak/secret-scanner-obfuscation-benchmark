# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ0Y1NCMVhuMyIsIm5hbWUiOiJzeW50aGV0aWMifQ.XsuFpz-0VoZ8zw0jras1nS4GSAPyi2dM30_vxUgeBnE"

def make_client():
    return Client(key=jwt)

