# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJlb3VSQjFRYSIsIm5hbWUiOiJzeW50aGV0aWMifQ.qTcsIs9iiFA2v_WmH62i2sbJhSQSa9iW7NVSZrAPRo8"

def make_client():
    return Client(key=jwt)

