# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJDU2JjVm50TCIsIm5hbWUiOiJzeW50aGV0aWMifQ.UIr28nY6FLof0kqnIaw8ZbNDiggJItuZx0NkWyI6mhE"

def make_client():
    return Client(key=jwt)

