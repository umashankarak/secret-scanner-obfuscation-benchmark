# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJtUVdHZGJEdiIsIm5hbWUiOiJzeW50aGV0aWMifQ.4tOJh9n2vf0N0z7WwTK900rFyb0ow15864GEB0PlH1U"

def make_client():
    return Client(key=jwt)

