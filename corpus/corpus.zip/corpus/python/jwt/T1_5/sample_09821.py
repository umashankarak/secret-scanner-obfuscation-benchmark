# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJaVTBVeHBGaCIsIm5hbWUiOiJzeW50aGV0aWMifQ.Wh-3Qd1EbwusD9JnLQ3-AoyzGyMz0QyEHWZfdyog2GI"

def make_client():
    return Client(key=jwt)

