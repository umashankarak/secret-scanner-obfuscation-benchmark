# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIwMHlPYmhtaCIsIm5hbWUiOiJzeW50aGV0aWMifQ.B751_op7Zx6MMSDcvGksJDxh5IXDRHRq2YH_8aRrfKs"

def make_client():
    return Client(key=jwt)

