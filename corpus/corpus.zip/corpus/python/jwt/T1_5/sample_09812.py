# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJubVk1THhPTCIsIm5hbWUiOiJzeW50aGV0aWMifQ.Otdsr4SzZOtFNJTqxWXn-jE5ZctcMpvs3DKb6hWYA5U"

def make_client():
    return Client(key=jwt)

