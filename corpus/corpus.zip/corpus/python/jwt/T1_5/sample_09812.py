# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJtS1VKNXY3OSIsIm5hbWUiOiJzeW50aGV0aWMifQ.mhuUo7umRu-vReoejoMN1-inBhC_sDu8Xp0yug52p98"

def make_client():
    return Client(key=jwt)

