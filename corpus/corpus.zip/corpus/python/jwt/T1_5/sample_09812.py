# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI1UEhqblZ5eCIsIm5hbWUiOiJzeW50aGV0aWMifQ.It4NGH5R4f4DAryWjMZDmvVZ0rZglF1yIcEoBwcg3oo"

def make_client():
    return Client(key=jwt)

