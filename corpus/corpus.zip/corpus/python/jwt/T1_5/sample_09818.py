# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJOTzdFRVRjTyIsIm5hbWUiOiJzeW50aGV0aWMifQ.ggLmf5PsFm0MU7Ee-NGYKMhUVo74N_inwoOmrgEukxg"

def make_client():
    return Client(key=jwt)

