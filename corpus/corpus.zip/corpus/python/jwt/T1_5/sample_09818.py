# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJBc2JRUlF0aiIsIm5hbWUiOiJzeW50aGV0aWMifQ._vioqkZ3eyNJ4d0CchyBSWe3nitzZLoSYjaFO19rNzk"

def make_client():
    return Client(key=jwt)

