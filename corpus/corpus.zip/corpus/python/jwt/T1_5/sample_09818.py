# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJKVzI0QTljWiIsIm5hbWUiOiJzeW50aGV0aWMifQ.AY1ZM4FwDxQ-wUAhZeq4NhS2defU4rFRvZ_yT6i6yMs"

def make_client():
    return Client(key=jwt)

