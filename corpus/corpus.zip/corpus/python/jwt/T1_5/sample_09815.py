# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJRdG5PcXNIUyIsIm5hbWUiOiJzeW50aGV0aWMifQ.N09et8II0TLaHzXSHtaLMfNrPm0Pp_eSIQvGLrdN08U"

def make_client():
    return Client(key=jwt)

