# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ3ZUhTb0VoMCIsIm5hbWUiOiJzeW50aGV0aWMifQ.UPqwbCs6zKFF3anPJUpvaqZM8Qvcc0vWOmV8-d5oU9U"

def make_client():
    return Client(key=jwt)

