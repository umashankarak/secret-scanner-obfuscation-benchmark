# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI0VmVvdVJCMSIsIm5hbWUiOiJzeW50aGV0aWMifQ.qv0CqTcsIs9iiFA2v_WmH62i2sbJhSQSa9iW7NVSZrA"

def make_client():
    return Client(key=jwt)

