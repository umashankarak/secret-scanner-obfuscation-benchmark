# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJLMkE1dWtGdCIsIm5hbWUiOiJzeW50aGV0aWMifQ.IbWTUcsSod7OcSRqlFQLzvxM2PRXUsced9BzzQhkNcA"

def make_client():
    return Client(key=jwt)

