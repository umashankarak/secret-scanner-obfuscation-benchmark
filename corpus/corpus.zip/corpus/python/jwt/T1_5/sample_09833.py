# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJHek9NUWF4SSIsIm5hbWUiOiJzeW50aGV0aWMifQ.EsMqUwVwKxmBE9NEiTmoeEoEuTCFsCjyTJNOENFjogU"

def make_client():
    return Client(key=jwt)

