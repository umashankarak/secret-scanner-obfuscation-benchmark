# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJZMjRxQW5ONCIsIm5hbWUiOiJzeW50aGV0aWMifQ.3HBo5C0qrO1KVE5y7eFtjaJv9APTlGV8WQJqieSD0dA"

def make_client():
    return Client(key=jwt)

