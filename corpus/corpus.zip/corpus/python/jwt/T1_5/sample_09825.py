# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJGV1lDUDJrWiIsIm5hbWUiOiJzeW50aGV0aWMifQ.cERT9QsH3GaJUzvARjqqIvQvbJxc_VrZitFP07qEdZY"

def make_client():
    return Client(key=jwt)

