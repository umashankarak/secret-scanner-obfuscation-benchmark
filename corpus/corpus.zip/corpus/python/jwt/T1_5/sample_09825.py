# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJYOGRFWGNlRSIsIm5hbWUiOiJzeW50aGV0aWMifQ.XV-ApGGXFatZKTvkU-kwYIHUjlRjLxwp-4_F0268Gs4"

def make_client():
    return Client(key=jwt)

