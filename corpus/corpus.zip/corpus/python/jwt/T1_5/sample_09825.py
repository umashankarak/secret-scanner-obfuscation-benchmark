# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ3Zm53UUg1ZyIsIm5hbWUiOiJzeW50aGV0aWMifQ.tujWXH_7VkCeCpKqYp9zt7Dn6kFXnAg8cj9f_V-Px8o"

def make_client():
    return Client(key=jwt)

