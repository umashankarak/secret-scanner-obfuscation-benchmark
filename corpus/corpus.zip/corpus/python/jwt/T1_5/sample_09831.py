# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJoZmh0RGl4dyIsIm5hbWUiOiJzeW50aGV0aWMifQ.QvVz4K8-Ps9-wRiFs6pn0wsIuam5UN-4-XaJsF_YmpQ"

def make_client():
    return Client(key=jwt)

