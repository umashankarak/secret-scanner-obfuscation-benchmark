# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJuMmN5TmFNVCIsIm5hbWUiOiJzeW50aGV0aWMifQ.Ea797rfUe8gjA9wKNWBZuWobNrEYqKEaXsKfX6vTI2k"

def make_client():
    return Client(key=jwt)

