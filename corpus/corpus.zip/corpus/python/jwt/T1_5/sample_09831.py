# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJOMks5WVczWCIsIm5hbWUiOiJzeW50aGV0aWMifQ.PE7_G9-R0FLDoyVMY3Mfpy2xWDex6-V6jhAC834UXYw"

def make_client():
    return Client(key=jwt)

