# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkckpqTmZUVyIsIm5hbWUiOiJzeW50aGV0aWMifQ.rFmnhqApoAiGsag7lo6nvFSugJbLP0sLD3jH_LUzPas"

def make_client():
    return Client(key=jwt)

