# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJrSTFuVTlyaCIsIm5hbWUiOiJzeW50aGV0aWMifQ.Dja4sMTdMVwQJ53St0JvnpRuq-oer5mtFzSufSe4Z4o"

def make_client():
    return Client(key=jwt)

