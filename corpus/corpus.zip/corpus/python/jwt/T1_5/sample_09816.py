# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJYUnozUzJQNSIsIm5hbWUiOiJzeW50aGV0aWMifQ.8f4C-Q1eE-5oCMRfvOgrLYfPrLDU5zx3jEcDou29Gg4"

def make_client():
    return Client(key=jwt)

