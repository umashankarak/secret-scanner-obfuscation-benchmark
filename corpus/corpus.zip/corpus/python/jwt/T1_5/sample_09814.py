# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJxeUprdnFqeiIsIm5hbWUiOiJzeW50aGV0aWMifQ.z4CskuGF4f-ERq7Pvqkv-AH-HNMqXnLMlpO-VvNMy_M"

def make_client():
    return Client(key=jwt)

