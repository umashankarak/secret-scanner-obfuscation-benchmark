# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJqV01QUXhDbiIsIm5hbWUiOiJzeW50aGV0aWMifQ.yndhuAG3Tz7vOKHj1-9sJmaC3g8v4IOdge7cY5PZFtU"

def make_client():
    return Client(key=jwt)

