# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJQQ0tLZ0JSNCIsIm5hbWUiOiJzeW50aGV0aWMifQ.O374SqF_o2wsy898XqUcbFQed-P407NKVDbN3S9g09M"

def make_client():
    return Client(key=jwt)

