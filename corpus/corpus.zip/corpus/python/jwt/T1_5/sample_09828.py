# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJYYWJIdUJ6RCIsIm5hbWUiOiJzeW50aGV0aWMifQ.XX-xdqJ9mYblyqrnuMZhiIXxCUBwDxC9BOsGpUn_sEI"

def make_client():
    return Client(key=jwt)

