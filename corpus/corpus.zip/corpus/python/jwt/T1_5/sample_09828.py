# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJmOGFRSVZkTyIsIm5hbWUiOiJzeW50aGV0aWMifQ.fno_iDyeXR1tq0O6SmH9FOYHVXymvEceDCs0A1_D2TI"

def make_client():
    return Client(key=jwt)

