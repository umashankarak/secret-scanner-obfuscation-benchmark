# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI3SkdnVWF0aSIsIm5hbWUiOiJzeW50aGV0aWMifQ.W0epZyIBSzd7gNIsytd0Kjv0QppAsJXhGmmtnXeed5A"

def make_client():
    return Client(key=jwt)

