# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJFTDNBd0lyUSIsIm5hbWUiOiJzeW50aGV0aWMifQ.a9WrS5jDD9K5Dvd962fBY5kz-afWnvg8nlhhjmS1txI"

def make_client():
    return Client(key=jwt)

