# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJDZE5qbUw2RiIsIm5hbWUiOiJzeW50aGV0aWMifQ.Iieugrl3ouE8lTl6NinQHvp7DyTP-4eJ-Bns3J7pAPg"

def make_client():
    return Client(key=jwt)

