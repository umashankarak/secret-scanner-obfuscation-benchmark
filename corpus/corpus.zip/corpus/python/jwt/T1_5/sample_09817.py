# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJOaTF2WXppaiIsIm5hbWUiOiJzeW50aGV0aWMifQ.guyck_qq9wKmmYJyW7q-Ntnu6gQsWTacxvgxokvR4oo"

def make_client():
    return Client(key=jwt)

