# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhQzFtSHFiYyIsIm5hbWUiOiJzeW50aGV0aWMifQ.quI3lPQPLZBhqm8osdTByYyI0Geek3UicXMtr0OofpQ"

def make_client():
    return Client(key=jwt)

