# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJZUzJ3dnFTTiIsIm5hbWUiOiJzeW50aGV0aWMifQ.xRBNLbEZZ7d4qmBHe9VX7uHTalTKF7cXuvQCB1kUfBU"

def make_client():
    return Client(key=jwt)

