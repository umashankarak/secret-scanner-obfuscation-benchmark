# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJBcGxDSkNxbCIsIm5hbWUiOiJzeW50aGV0aWMifQ.faR-Bt9ndVwJbTwL3tXMTYKt4RvCbeVjaOqAxA4QZwQ"

def make_client():
    return Client(key=jwt)

