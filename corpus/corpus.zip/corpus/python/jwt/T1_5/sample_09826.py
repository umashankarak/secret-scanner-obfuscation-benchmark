# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJSbHEzelBKaCIsIm5hbWUiOiJzeW50aGV0aWMifQ.j8tNvqPHhcTyKc9Mm4E4NjHFdnqfaz7bSYLOXvaQzbs"

def make_client():
    return Client(key=jwt)

