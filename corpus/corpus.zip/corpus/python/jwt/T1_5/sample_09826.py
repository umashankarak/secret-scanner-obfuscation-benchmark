# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ3UHhROFVudyIsIm5hbWUiOiJzeW50aGV0aWMifQ.En0FCXtLITK94F4z6bBH9CsqNMytieuSCjADri80by4"

def make_client():
    return Client(key=jwt)

