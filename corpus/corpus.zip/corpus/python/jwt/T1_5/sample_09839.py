# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJqTmZUV1J3UCIsIm5hbWUiOiJzeW50aGV0aWMifQ.hqApoAiGsag7lo6nvFSugJbLP0sLD3jH_LUzPavIsdk"

def make_client():
    return Client(key=jwt)

