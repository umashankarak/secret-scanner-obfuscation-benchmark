# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJtaEtHanNrUSIsIm5hbWUiOiJzeW50aGV0aWMifQ.K7R7RpGcXAmDmAlsSx-cucYcIJAKJ-jPVIL3anQx_ZM"

def make_client():
    return Client(key=jwt)

