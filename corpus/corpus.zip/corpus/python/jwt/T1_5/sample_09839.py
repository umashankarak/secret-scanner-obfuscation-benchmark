# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJsaXlablN5UiIsIm5hbWUiOiJzeW50aGV0aWMifQ.RGh-nNbPS8ax2C2bNqmSe_ZvYD4zvUYSgfrCapSKXHY"

def make_client():
    return Client(key=jwt)

