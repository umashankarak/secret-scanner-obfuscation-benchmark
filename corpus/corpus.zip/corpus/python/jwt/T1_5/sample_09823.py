# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxUVdGa05xciIsIm5hbWUiOiJzeW50aGV0aWMifQ.98iqDPBa3IPUI7Qd72gjscKGHfC8IIitz6gsWM7c_zI"

def make_client():
    return Client(key=jwt)

