# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJKR3hYRktaQSIsIm5hbWUiOiJzeW50aGV0aWMifQ.PVcW7bcVYHk-jCSxHGkxVojmm8qoi8BMqkwUzFDfgGo"

def make_client():
    return Client(key=jwt)

