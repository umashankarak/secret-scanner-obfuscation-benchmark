# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJiWVp1MkpiaCIsIm5hbWUiOiJzeW50aGV0aWMifQ.6IN9HM4mg-r9vWOzxOn0b1Vsvz_6QTgaAVbp2DjP3QE"

def make_client():
    return Client(key=jwt)

