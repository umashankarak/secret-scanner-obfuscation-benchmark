# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJpcDVGa2NqaCIsIm5hbWUiOiJzeW50aGV0aWMifQ.2yBqu4XKbffbc9V8R16b4c-LvXftfGmsdvCa7mYKdvc"

def make_client():
    return Client(key=jwt)

