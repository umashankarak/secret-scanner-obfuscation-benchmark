# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJMcGowU1dJViIsIm5hbWUiOiJzeW50aGV0aWMifQ.sZ8KSsHgjrdXnKOZtg-eqnZEp3K28P2QYYtOlJ6swD0"

def make_client():
    return Client(key=jwt)

