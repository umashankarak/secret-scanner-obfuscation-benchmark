# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJVSjV2NzlNZyIsIm5hbWUiOiJzeW50aGV0aWMifQ.lKO7pkbvr0XqHo6DDdfopwYQv7A7vF6dMroOdqffTAk"

def make_client():
    return Client(key=jwt)

