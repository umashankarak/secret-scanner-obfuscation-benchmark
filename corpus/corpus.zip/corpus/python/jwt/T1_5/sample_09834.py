# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJobEpCN0prOCIsIm5hbWUiOiJzeW50aGV0aWMifQ.H6JRU74HM6seWRh_vfqIGQmxc_X4pjoNjMbfeBcnklw"

def make_client():
    return Client(key=jwt)

