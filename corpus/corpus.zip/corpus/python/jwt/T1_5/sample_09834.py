# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJFNTRFcEtVUyIsIm5hbWUiOiJzeW50aGV0aWMifQ.8BaCKu0M0MXe7dnl9QuJF4gPBxiMcate8UWjh4SvM5A"

def make_client():
    return Client(key=jwt)

