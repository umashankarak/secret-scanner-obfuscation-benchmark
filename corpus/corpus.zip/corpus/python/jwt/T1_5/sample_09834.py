# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJocGhPSUYzTiIsIm5hbWUiOiJzeW50aGV0aWMifQ.pZ88zjKF0qwH__OxFenkAE02Gh_9GwEcvu4FoRIYTQY"

def make_client():
    return Client(key=jwt)

