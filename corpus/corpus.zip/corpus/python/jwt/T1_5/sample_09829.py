# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJianJ4RUI0cSIsIm5hbWUiOiJzeW50aGV0aWMifQ.nhRq5gYZhRwveViBr-D1ZYwCpYrlO0NK1zIM6pPUmG0"

def make_client():
    return Client(key=jwt)

