# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJNaU9FS01QaiIsIm5hbWUiOiJzeW50aGV0aWMifQ.aN1E9EZ9--OOvNzVruw_p4utYk2ZuEfcbuQkJFY5I04"

def make_client():
    return Client(key=jwt)

