# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJIVGhRd2dWZSIsIm5hbWUiOiJzeW50aGV0aWMifQ.uTVWLQLFPdIZOjdA5Kxw5Ho1ErFYqan0gtDFnkEAFus"

def make_client():
    return Client(key=jwt)

