# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJYR0h6T0JVMSIsIm5hbWUiOiJzeW50aGV0aWMifQ.U3HiX1JYO6dG1GppwT2DSTtFGmKNBO2ksW4oJEqCD1Y"

def make_client():
    return Client(key=jwt)

