# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjb1R2QmxORCIsIm5hbWUiOiJzeW50aGV0aWMifQ.MOVMatXW1GLVkH3zIkgFBcUM4MxOW1EtAxfDOb7-Fu8"

def make_client():
    return Client(key=jwt)

