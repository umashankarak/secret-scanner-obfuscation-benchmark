# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ5b01tMlR3RiIsIm5hbWUiOiJzeW50aGV0aWMifQ.OJunb25FrGTHhpr0f8mdeuxGyAUDLO66akII4kjtolo"

def make_client():
    return Client(key=jwt)

