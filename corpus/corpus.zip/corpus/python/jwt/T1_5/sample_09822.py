# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJVRjU4bHh1USIsIm5hbWUiOiJzeW50aGV0aWMifQ.Yxzls-DNp3FitqTomvTjipcwArRg-xey8nJKggv8bUM"

def make_client():
    return Client(key=jwt)

