# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJTOE9ja21PSyIsIm5hbWUiOiJzeW50aGV0aWMifQ.D2Ca5rwl881alWs0u2faLrNc2sf9CSAF85iK6NFHAY8"

def make_client():
    return Client(key=jwt)

