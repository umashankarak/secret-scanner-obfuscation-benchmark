# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJpTlcwSll2UiIsIm5hbWUiOiJzeW50aGV0aWMifQ.cZlEjy8RAkCXLn9YY-tFF7qlUxajpuMJIF1QXidFPAg"

def make_client():
    return Client(key=jwt)

