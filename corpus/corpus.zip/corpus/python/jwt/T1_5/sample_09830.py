# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzTzdBMTJCQyIsIm5hbWUiOiJzeW50aGV0aWMifQ.VBvWc19lGzKUgzTp0gb8dX_DjlvTAZCyqhkw2skTbYs"

def make_client():
    return Client(key=jwt)

