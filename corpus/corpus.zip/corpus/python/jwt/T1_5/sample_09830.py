# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJPQmZKTGxlVSIsIm5hbWUiOiJzeW50aGV0aWMifQ.o80tioObninRZccVT1WBmYk_OUCAObaollGUqYh40JU"

def make_client():
    return Client(key=jwt)

