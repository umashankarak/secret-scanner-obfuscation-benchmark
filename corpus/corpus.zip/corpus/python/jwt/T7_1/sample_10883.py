# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("Z" + "XlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKRlpsWllabFJtTkNJc0ltNWhiV1VpT" + "2lKemVXNTBhR1YwYVdNaWZRLnA3Z2tuM0U" + "4NzdjOWZ6VGpQMW5mX3diODFtOWkxM0czQm1yamJRWWhKOTQ=").decode()

def make_client():
    return Client(key=jwt)

