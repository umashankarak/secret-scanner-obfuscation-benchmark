# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUp" + "JVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJM2FtcHZibmN6YXlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLk1wWU1NT1ZYM3FFVWxWYWs2" + "aGdCSVdyNkQyT3J2aDJUOVJVb" + "XBSSWo2aTg=").decode()

def make_client():
    return Client(key=jwt)

