# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJH" + "Y2lPaUpJVXpJMU5pSXNJb" + "lI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKc1J6aHNNVE56YlNJc0" + "ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlhxM3lLRDZNNWFvS1ZxTkR1QmJ4S2ZablB5bFpfZG9XdFlQU1hIN3NyVkU=").decode()

def make_client():
    return Client(key=jwt)

