# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJ" + "VXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJeGJGVnlaWEZUZHlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmYwc1pfN0g2S3otVWo0Zko4cWNvamJreUph" + "YldBVndmb0Voe" + "XNVb1BfZ1E=").decode()

def make_client():
    return Client(key=jwt)

