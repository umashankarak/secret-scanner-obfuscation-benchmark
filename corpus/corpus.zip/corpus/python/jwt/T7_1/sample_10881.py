# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lp" + "T2lKR1ZqQnBVMFJyWlNJc0ltNWhiV1VpT2lK" + "emVXNTBhR1YwYVdNaWZRLm1T" + "cUtvVkhDckY2QmRUS18zckRLWk44YXJOMTd4cHUwQ1pWaWNqWVVZZEk=").decode()

def make_client():
    return Client(key=jwt)

