# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKaFlUQjFRMlkzYmlJc0l" + "tNWhiV1VpT2lKemVXNTBhR1Yw" + "YVdNaW" + "ZRLmxEQmVmR1dsdS13dW1kU0VmazdHQmpCeWpUYnV4M20zOHpfWE1fcm1UZFk=").decode()

def make_client():
    return Client(key=jwt)

