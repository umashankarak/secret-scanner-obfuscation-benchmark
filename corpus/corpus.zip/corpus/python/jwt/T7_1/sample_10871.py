# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaU" + "pJVXpJMU5pSXNJblI" + "1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKd09FWkJRVGxGVVNJc0ltNWhiV1VpT" + "2lKemVXNTBhR1YwYVdNaWZRLkZScHNoelE4WlBHWG9NYW90QzdvaFB4d3FPS1ZDVC1rWC1GRl9uQVFXNGc=").decode()

def make_client():
    return Client(key=jwt)

