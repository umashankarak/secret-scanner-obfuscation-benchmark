# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lP" + "aU" + "pJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKTWIweFNaSFprT1NJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZR" + "LlNwTkE0VHlETm9SLWZmWk5EZ1pIN0Zrbm9yTnFqV3JTdlppbDUwRzdDV1U=").decode()

def make_client():
    return Client(key=jwt)

