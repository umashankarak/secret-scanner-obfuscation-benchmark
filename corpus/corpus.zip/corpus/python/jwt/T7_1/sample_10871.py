# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKU1UwVkZOblpEYkNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNa" + "WZRLkdE" + "QUtFd" + "XFGSUh4ZXhwc1BSZU9sd1YtT0tSXzg2TENQQXVNREc5ZzV0Qms=").decode()

def make_client():
    return Client(key=jwt)

