# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKMldYQjVPV05EY2lJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmpyTzdsZUU4cXNpOUFuU1F" + "MN2o5Y" + "npU" + "aXFud2NKRG1DUkdoQmNiMmJYdkk=").decode()

def make_client():
    return Client(key=jwt)

