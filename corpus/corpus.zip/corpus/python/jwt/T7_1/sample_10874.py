# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0" + "lpT2lKdE0xcG5hMG8zZVNJc0ltNWh" + "iV1VpT2lKemVXNTBhR1YwYVdNaWZRLmhwW" + "F9DWUNQRTlpdk10OXFaeVlQNDRZUGkzcm1SdWYzbmMyaDRkcXpmMWc=").decode()

def make_client():
    return Client(key=jwt)

