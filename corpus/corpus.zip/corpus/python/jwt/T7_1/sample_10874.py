# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY" + "2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5" + "SnpkV0lpT2lKWk4wRllPVGhYTVNJc0lt" + "NWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjhrMGl1b1BrMkJsS0V3OV9rTXByMTkxUTdwNGlSQVFiNS1JaVBzb25iNXc=").decode()

def make_client():
    return Client(key=jwt)

