# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1" + "Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKVWRYTnhjRkp3YVNJc0ltNWhiV1VpT2lKemVXNTBh" + "R1YwYVdNaWZRLjVQbE5Qc0tDMFB2RUdmMHhfcnRXMlN4VldHSThBclhXbz" + "ctZFdkd2FZcmM=").decode()

def make_client():
    return Client(key=jwt)

