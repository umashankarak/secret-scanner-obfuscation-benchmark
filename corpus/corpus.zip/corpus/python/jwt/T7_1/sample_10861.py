# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKdlRuWlJRbFJ4Y1NJc0ltNWhiV1VpT2l" + "KemVXNTBhR1YwYVdNaWZRLnJRbnZYbEkyLWl6R" + "ks5NTVzV3dtVWcxTUFNSHFNenFWNkNNMW5VNmdWW" + "U0=").decode()

def make_client():
    return Client(key=jwt)

