# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJM" + "U5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKVGJETktSRlpPWWlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmJ" + "YUkw0eU41eVdyVXljdG03a" + "1RUUEZWai03eDVodmItV0s2MUotalBBZmM=").decode()

def make_client():
    return Client(key=jwt)

