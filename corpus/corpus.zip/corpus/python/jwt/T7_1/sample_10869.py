# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY" + "2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT" + "2lJNE1FWmFkMjlEZUNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLllybDd3RTZ2NU93Q183U2RaQ1FXdE9LSmMzZU91" + "STA5LTNzMG5TMTdsRTg=").decode()

def make_client():
    return Client(key=jwt)

