# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXp" + "JMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKTmQyVjJZWE5VTmlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmEtblFrSmFyLVRQTmROSXNYck8tQ2lXZ2FVWWZMZ2ZYaU1" + "RTVR" + "TaFVHNzg=").decode()

def make_client():
    return Client(key=jwt)

