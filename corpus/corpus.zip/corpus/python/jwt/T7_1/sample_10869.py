# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJM1FqRkZaalpVVWlJc0ltNWhiV1VpT2lKemVXNTBh" + "R1YwYVdNaWZRLkNhX3diMlZUa2F4TVVSYk55d0xoaTROQ0" + "1VbXI5b" + "E1UNkVDZ3JTTGVINnc=").decode()

def make_client():
    return Client(key=jwt)

