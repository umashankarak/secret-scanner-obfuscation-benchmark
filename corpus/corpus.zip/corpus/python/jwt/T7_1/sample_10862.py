# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1" + "Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJNWNqSlJWR" + "XhITVNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkw3bEhFUGhEX0xOWWYwc1pfN0g2S3otVWo0Zko4cWNva" + "mJreUphYldBVnc=").decode()

def make_client():
    return Client(key=jwt)

