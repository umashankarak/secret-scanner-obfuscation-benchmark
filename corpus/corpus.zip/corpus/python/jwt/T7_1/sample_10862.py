# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKdU1tTk1ZVFJsTlNJc0ltNWhiV1VpT2l" + "KemVXNTBhR1YwYVdNaWZRLk5jWXRCYzdJME44NVlmLU5K" + "bzl4eVNMUVVuRjdaX0lWVWdLTVJ2" + "OWdWenc=").decode()

def make_client():
    return Client(key=jwt)

