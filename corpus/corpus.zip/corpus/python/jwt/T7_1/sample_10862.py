# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKUFZXWTRhVlo1VEN" + "Jc0ltNWhiV1VpT2lK" + "emVXNTBhR1YwYVdNaWZR" + "LllucDRxQTlRYjNXalJsUW1EOXhqdXBEN2d6RmZmQ3AxcXhVUTZvVkhiajg=").decode()

def make_client():
    return Client(key=jwt)

