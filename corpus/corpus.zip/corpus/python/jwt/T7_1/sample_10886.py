# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklr" + "cFhWQ0" + "o5LmV5SnpkV0lpT2lJd1FtcDRURlIyU2lJc0ltNWhiV1Vp" + "T2lKemVXNTBhR1YwYVdNaWZRLlM4dFZyNTYwUmhYNVIxQjhYOGs2Yi1MMEhwcDdpZHRZVUJjYzdhSVk4QXM=").decode()

def make_client():
    return Client(key=jwt)

