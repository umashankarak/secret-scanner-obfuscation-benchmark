# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y" + "0N" + "JNklrcFhWQ0o5LmV5SnpkV0lpT2lKeWNuaDBhRlJ3YkNJc0ltNWhiV1VpT2lKemV" + "XNTBhR1YwYVdNaWZRLktWNnlZM0pha3hOam9ZbWYyMU9GdU0xTlh6LUhnUkN1a2U5VVdXN2RfWXM=").decode()

def make_client():
    return Client(key=jwt)

