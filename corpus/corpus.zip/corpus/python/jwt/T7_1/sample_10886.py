# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNkl" + "rcFhWQ0o5LmV5SnpkV0lpT2lKRVlYTmlNM" + "0kzVHlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlhwSjlZaEhuaFNNQ2lUT" + "2xtaTRBTWtQdEl1b1hwWGpnUXEwWGVsRmlfalE=").decode()

def make_client():
    return Client(key=jwt)

