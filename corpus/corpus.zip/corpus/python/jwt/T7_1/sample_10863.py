# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5" + "SnpkV0lpT2lKc1JUQTFUMDFRW" + "WlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmlJcTBvMzBRcU1PcUloYjRTZUZWWWFWMl81QUc0U0JiQjNVRnpQW" + "k12SkU=").decode()

def make_client():
    return Client(key=jwt)

