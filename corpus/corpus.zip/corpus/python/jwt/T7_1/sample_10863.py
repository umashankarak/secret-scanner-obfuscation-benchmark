# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaU" + "pJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKRFUzTmtZalpZVENJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjNiMFBwR" + "nJycWVTVENOUG5makhBVERhS3VpYWx4Qn" + "J1S3VyR3NvYVJ4cDQ=").decode()

def make_client():
    return Client(key=jwt)

