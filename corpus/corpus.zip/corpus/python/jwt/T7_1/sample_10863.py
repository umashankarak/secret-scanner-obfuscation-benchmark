# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2" + "lPaUpJVXpJMU5pSXNJ" + "blI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKak1YQkRZbHBRUnlJc0ltN" + "WhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnMzZ1B5V1lsYUN5NlVOV0wwaTlKWGpjU3hwYVpoZU1Vd2N2VzNjWVZJS28=").decode()

def make_client():
    return Client(key=jwt)

