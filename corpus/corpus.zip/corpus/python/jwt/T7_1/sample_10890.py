# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJH" + "Y2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJd2FYcG1OVVYxWXlJc0ltNWhiV1VpT2lKemVXNTB" + "hR" + "1YwYVdNaWZRLnQyelVJV1BNOVZwbFNWZzFRRVozU2Q3czNZLTgzS1FyTEhHSVNEcmpra0U=").decode()

def make_client():
    return Client(key=jwt)

