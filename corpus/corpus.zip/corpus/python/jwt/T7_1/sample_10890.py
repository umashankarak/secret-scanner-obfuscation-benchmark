# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNkl" + "rcFhWQ0o5LmV5SnpkV0lpT2lKbE5raHBSbmhZ" + "VFNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaW" + "ZRLkQwWGpwY0ZmamlrZl9PaXdqd0xqQXh2WU9iUVp3M2R3ZkkyU2YxZTlJblk=").decode()

def make_client():
    return Client(key=jwt)

