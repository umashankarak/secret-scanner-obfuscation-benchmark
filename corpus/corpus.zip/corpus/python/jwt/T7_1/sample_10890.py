# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5L" + "mV5SnpkV0lpT2lKSE9GZFFj" + "MUpJY3lJc0ltNWhi" + "V1VpT2lKemVXNTBhR1YwYVdNaWZRLm1YckM3TVNMY05aQThDS1J2eGF2MFVadlRzSEtCWDl5OWtycmNFdzdSak0=").decode()

def make_client():
    return Client(key=jwt)

