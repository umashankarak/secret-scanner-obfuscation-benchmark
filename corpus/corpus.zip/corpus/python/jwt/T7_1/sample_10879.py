# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0" + "o5LmV5Snp" + "kV0lpT2lKdlZ6aE1UVE5qV1NJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjVlcTRjZWp4d3hmV1EwQlFveGFnUlFGZl" + "JKbEh4TEgtQWlqZjNkMUdFdHM=").decode()

def make_client():
    return Client(key=jwt)

