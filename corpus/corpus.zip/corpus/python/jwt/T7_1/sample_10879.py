# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXN" + "JblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKWlVEWjRZM1UyTWlJc0ltNWhiV1VpT2lKemV" + "XNTBhR1YwYVdNaWZRLnNyYUNNYldEM" + "UhteW1zS2kzc2NMU0tveHBpNEJ0Sl9CVHdDc3ozTUZrZ2s=").decode()

def make_client():
    return Client(key=jwt)

