# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJek1IUmhiRlJZZFNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlp" + "VOXJFTVk4eV9vOHBvR0c5Y" + "3pkV0s2SmVmTkxVdHpr" + "OFk3eXhaSkZzQ3c=").decode()

def make_client():
    return Client(key=jwt)

