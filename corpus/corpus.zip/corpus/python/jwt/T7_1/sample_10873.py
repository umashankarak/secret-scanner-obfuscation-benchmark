# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKblZEaFBjVl" + "l3YmlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYV" + "dNaWZRLlJUSEhDUVk2WFZrQ1lCQk8tX1prbm5RVDhXMVA4" + "UEgyaWQ2blhIUHBsdzA=").decode()

def make_client():
    return Client(key=jwt)

