# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXN" + "JblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJNWVIZ3lWMHQ1ZENJc0ltNWhiV1VpT2lKemVXNTBhR" + "1YwYVdNaWZRLndYeXlaWW5taHdQYXRYSHE3LUdGT25nNU9hckd" + "QUFBkNHNYMUtkYzBsaEU=").decode()

def make_client():
    return Client(key=jwt)

