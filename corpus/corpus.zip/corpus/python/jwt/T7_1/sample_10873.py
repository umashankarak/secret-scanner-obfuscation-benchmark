# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKeU4xbHlXRzFJVFNJc0ltNWhiV1V" + "pT2" + "lKemVXNTBhR1YwYVdNaWZRLjM1STR2Ui1tN2V6Z01YRjJmWFJWRDYyZHY2dFRfMVl" + "ZOXVKcW0zdjFmekU=").decode()

def make_client():
    return Client(key=jwt)

