# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2" + "lPaUpJVX" + "pJMU5p" + "SXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKTVEzRkJaakZKVlNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLktXdE0yX0NUWXVmcjV1R0xCbk4xbGJoVjNfV081U2duYnp3ekMxT01saWM=").decode()

def make_client():
    return Client(key=jwt)

