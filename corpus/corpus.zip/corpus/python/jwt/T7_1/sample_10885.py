# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJbl" + "I1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKbE1XMDFUbUZ2U1NJc0ltNWhiV1VpT2lKemVXNTBhR" + "1YwYVdNaWZRLld4RTFsd0lEODVTSl" + "hKR0hpWHNfNGxvLTFEYkZhbmszMlpseWMzN3lrbjQ=").decode()

def make_client():
    return Client(key=jwt)

