# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV" + "0lpT2lJNVkyVnhTVnBtZVNJc0ltN" + "WhiV1Vp" + "T2lKemVXNTBhR1YwYVdNaWZRLldjY2liT0s2RnRpaGdxWmhHc0pPSHVaLVg1ZHlPMDQ5U2haUTZsczhXV0E=").decode()

def make_client():
    return Client(key=jwt)

