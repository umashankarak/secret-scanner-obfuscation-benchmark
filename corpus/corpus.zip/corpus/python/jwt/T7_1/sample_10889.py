# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUp" + "JVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKc2FsUnpWRW81VXlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLk9EM" + "VFaczhnZHNUczVrSG1zd0F5YkVVTnZpaTAtRzM1aXFBeVB" + "xNVpieE0=").decode()

def make_client():
    return Client(key=jwt)

