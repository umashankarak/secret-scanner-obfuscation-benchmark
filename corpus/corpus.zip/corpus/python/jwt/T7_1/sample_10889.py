# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhW" + "Q0o5LmV5SnpkV0lpT2lKbFkyRktjazlaYWlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnRoaTFtMWhjbXhfYkVWbmpzSVF" + "TWTFMeGZaVktrTndvSHF3VGRJd1otckk" + "=").decode()

def make_client():
    return Client(key=jwt)

