# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2l" + "PaUpJVXpJMU5pS" + "XNJblI1Y0NJNklrcFhWQ0o5L" + "mV5SnpkV0lpT2lKTVZrRjZlRGxGTWlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmFrU1Fkc0FIdm5jTGhnMFU4UE1lcGxfMDdsRnNwWnF0czNqNWVlcFhjQzA=").decode()

def make_client():
    return Client(key=jwt)

