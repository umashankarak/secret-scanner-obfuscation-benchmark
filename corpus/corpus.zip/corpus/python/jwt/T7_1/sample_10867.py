# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ" + "0o5LmV5SnpkV0lpT2lKRVQxQnhhMlkyY1NJc0ltNWhi" + "V1VpT2lKemVXNTBhR1YwYVdNaWZRLjRTNU9LZHEwbUJzLW5Kc3pOYkd1UG82V1BmcVQ2QjBvUm55" + "cG9keFZCOFE=").decode()

def make_client():
    return Client(key=jwt)

