# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKd2J" + "XTjFTa3hxWXlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkVSZ" + "DFBRWtHM0VmdC1xRmVrbjFpRWVlRkl3S0pNNldhTGdBeV" + "EtMGk2aGM=").decode()

def make_client():
    return Client(key=jwt)

