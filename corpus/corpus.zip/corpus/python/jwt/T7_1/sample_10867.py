# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZX" + "lK" + "aGJHY2lPaU" + "pJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKeWNuUndlbmhqTUNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkZLd3l4ckdkanVhdkRKU3g3eTJCdjJuUU1qUDlFZkxDdFhkQnkxMVJDSlE=").decode()

def make_client():
    return Client(key=jwt)

