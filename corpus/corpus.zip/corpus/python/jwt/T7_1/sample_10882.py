# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUp" + "JVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKaVFYcG5jVUpCWWlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjVhSlFCQzBEOHMxTFQ2TFc4cHlOMENNT1JzYVE1" + "WmRmZkFVcmc3V" + "09KX00=").decode()

def make_client():
    return Client(key=jwt)

