# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5Snpk" + "V0" + "lpT2lKM05sRTFTMk13TlNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmZqSEFURGFLdWlhbH" + "hCcnVLdXJHc29hUnhwNThEWjF3d0EtSjNrS3BtSzQ=").decode()

def make_client():
    return Client(key=jwt)

