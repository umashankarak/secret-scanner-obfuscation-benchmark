# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcF" + "hWQ0o5LmV5SnpkV0lpT2lKcFdXTjFiakJsZVNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRL" + "m42UWE3N3FZU3RmX010NHVTOUtIS0JkSHFZ" + "aXZ0LU1nN1NjSXlGWUtxYWs=").decode()

def make_client():
    return Client(key=jwt)

