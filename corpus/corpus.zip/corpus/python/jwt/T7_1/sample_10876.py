# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJN" + "klrcFhWQ0o5LmV5SnpkV0lpT2l" + "JNU5qUldkbkZKV1NJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjFIa0J6OFAyakEwbENWblN1UWU1Qlo1QzJPUGlHcXNFd3dIOGNNZ0JBUz" + "Q=").decode()

def make_client():
    return Client(key=jwt)

