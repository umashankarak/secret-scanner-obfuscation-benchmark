# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaG" + "JHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKVVJVczBabXBUVVNJc0ltNWhi" + "V1VpT" + "2lKemVXNTBhR1YwYVdNaWZRLm5iZVVGNFg5RnhUVmFkUkFGZE11MGVHVVQ5QmhLRnJMTDdSSV9ydWdWaFk=").decode()

def make_client():
    return Client(key=jwt)

