# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pS" + "XNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKbU56UlljR3RzUlNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlBlSk0wOGN0YjgwUzEwRUQtVElXeHU2cHJxZ3ctLVN6ZE1lY" + "kNnZG4yTTQ" + "=").decode()

def make_client():
    return Client(key=jwt)

