# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKM05VaFlSREU1ZWlJc0ltNWhiV1VpT2lKemVXNTBhR1YwY" + "VdNaWZRLk9tZmNncFNfYVdSZDkzblpha1NRZHNBSHZuY0x" + "oZzBVOFBNZX" + "BsXzA3bEU=").decode()

def make_client():
    return Client(key=jwt)

