# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ" + "0o5" + "LmV5SnpkV0lpT2lKbWMwWlJRblZYZ" + "HlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmxNaE93ZHlzVmpXanNuTHUwYWN5MElrRWs3MjROX2piS3J4OUFYTWhXV28=").decode()

def make_client():
    return Client(key=jwt)

