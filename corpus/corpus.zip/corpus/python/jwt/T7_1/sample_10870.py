# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJ" + "VXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKa2FrOU5ZbHBMVENJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmhNUk1IbC1Oa" + "UlKM1" + "9sMEtYZDZHQ2pFUDdTV2VXSGVTRWVWaXFYM1FESU0=").decode()

def make_client():
    return Client(key=jwt)

