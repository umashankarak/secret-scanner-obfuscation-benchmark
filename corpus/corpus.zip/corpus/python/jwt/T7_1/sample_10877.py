# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5Sn" + "pkV0lpT2lKd1VtMU5WMVF3UVNJc0ltNWhiV1VpT2lKemVXNTBhR" + "1YwYVdNaWZRLmFjWTRNbkhtbk5VMWRic29mZGdrbktjS3ZjbkRvUlJoam9mT" + "U9BdFJCbkU=").decode()

def make_client():
    return Client(key=jwt)

