# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJb" + "lI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKRk1EbEVj" + "MWhCZGlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdN" + "aWZRLkxZSnk1dl80TTQ3aXJzOGxJX2dFT240Y094LUs0dVFQS1JuZDhCVEdmNms=").decode()

def make_client():
    return Client(key=jwt)

