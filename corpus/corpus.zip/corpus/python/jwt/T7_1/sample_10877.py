# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKWlNGTmlhM1I1ZHlJc0ltNWhiV1V" + "pT2lKemVXNTBhR1YwYVdNaWZRLlNzZmxJZzdKQUR3VnBPbEROTHNG" + "aTdZVExnRnFDVWRPbkJ3dVZqUj" + "BjTzQ=").decode()

def make_client():
    return Client(key=jwt)

