# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKa" + "GJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNkl" + "rcFhWQ0o5LmV5SnpkV0lpT2lKbFdqUTRjRVoxU3lJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZ" + "RLnJjcmVTX0RmSjFkVTREd3VzQ2IzYUFCUU55VWdsLXRYeTFLcVduNVhuZHM=").decode()

def make_client():
    return Client(key=jwt)

