# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJH" + "Y2lPaUpJVXp" + "JMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKNWVqZDRaMUZzVnlJc0ltN" + "WhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjE2aUJQYTFDdDU0MmtrWm1ta2tDZ0pLdUVsQWlIQkRCRjI4azlNUkp4eG8=").decode()

def make_client():
    return Client(key=jwt)

