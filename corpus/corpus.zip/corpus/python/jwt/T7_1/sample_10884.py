# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT" + "2lKSVNFWXphSGROV1NJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZR" + "Ll9WQk1SU0xVNVJKT" + "21hejNoTTByTXoxMHU4T1dZcmZlMDdLMHJEVGQ1NVE=").decode()

def make_client():
    return Client(key=jwt)

