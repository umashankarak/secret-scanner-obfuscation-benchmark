# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("Z" + "XlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKdWIxY3lRMnBYYWlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdN" + "aWZRLlRYekVvUjBHNlMtNjJHcmkxQkVFanZEbUZlOVJJdDYxZEJXa" + "XVZTUU0T3c=").decode()

def make_client():
    return Client(key=jwt)

