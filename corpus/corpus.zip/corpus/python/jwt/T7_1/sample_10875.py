# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2" + "lKNmNqazBkRWxzVVNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlRaZWNEY" + "lNxSndR" + "X3hkM0h3UTZaZkgyWDJsWW9UMWJpWWRQaFdQWmxvWUE=").decode()

def make_client():
    return Client(key=jwt)

