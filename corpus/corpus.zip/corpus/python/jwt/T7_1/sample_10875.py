# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJ" + "blI" + "1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJeVZIRm5WRXRYUlNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlZleDdublhBVk" + "tVSVktRW5vTXVjRXJodS12NWcyRzBScVRFMlZyMmhUbkU=").decode()

def make_client():
    return Client(key=jwt)

