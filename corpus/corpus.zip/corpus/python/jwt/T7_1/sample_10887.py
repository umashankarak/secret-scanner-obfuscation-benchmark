# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVX" + "pJMU5pSXNJblI1Y0NJNk" + "lrcFhWQ0o5LmV5SnpkV0lpT2lKSWFVOVNUVzl4ZUNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjh4UDV5RDBkd3NUb2ZBVnJfWDlocU9TYjU3M0d" + "rc3dRR0ZjYVlDbXVLdlE=").decode()

def make_client():
    return Client(key=jwt)

