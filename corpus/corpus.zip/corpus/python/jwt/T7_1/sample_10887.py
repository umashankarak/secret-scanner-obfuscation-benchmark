# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKdVQweEJabk5K" + "ZHlJc0ltNWhiV1VpT2lKemVXNTBhR1Yw" + "YVdNaWZRLjBhODMwdkFmcmtuQXVDdWdXRTJSZ" + "2hxd1hiT1Q3OF81ZDJsWm1Wc1NWQUk=").decode()

def make_client():
    return Client(key=jwt)

