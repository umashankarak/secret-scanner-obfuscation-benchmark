# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJemIyTlZaVEZKV2lJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLn" + "V3" + "MjFYaXBJd1l4aldqSFJwXzVVWnZGaU1YZHZaVDh4Q1prNnBQY" + "S1FR0k=").decode()

def make_client():
    return Client(key=jwt)

