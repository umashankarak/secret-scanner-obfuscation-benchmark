# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKaVFrUnpOR2xGV1NJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLmF0VEp5MmJ1Uk5N" + "OFZXUDd2SG1HOXY1WXJy" + "VW42TThCOTNhN0ZJejNS" + "Tm8=").decode()

def make_client():
    return Client(key=jwt)

