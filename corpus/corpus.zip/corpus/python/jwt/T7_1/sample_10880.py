# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhW" + "Q0o5LmV5SnpkV0lpT2lKck0xbGtkRXBJVlNJc0ltNW" + "hiV1VpT2lKemVXNTBhR1YwYVdNaWZRLlNvZmM0V3JwR3lLVnR6ZDZkX3JTM3U1LVNhMGRyY2" + "FzWjNQMzJ2RHl6anc=").decode()

def make_client():
    return Client(key=jwt)

