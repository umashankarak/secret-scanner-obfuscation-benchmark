# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKQk5FSmlhV296UmlJc0l" + "tNWhi" + "V1VpT2lKemVXNTBhR1YwYVdNaWZRLkFGd1F6ZUx4UEgxUWtLM0sza3Z3M3lkWFZPQThMckFtOTJnQVVEY2x" + "JSmM=").decode()

def make_client():
    return Client(key=jwt)

