# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhW" + "Q0o" + "5LmV5SnpkV0lpT2lKaVEycEZTV3M0W" + "nlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnhPdDZPaHBJUU9OMllaSzJoMmp2QWZrOUNaTFRBVVNmc3dTX05aX1BNYk0=").decode()

def make_client():
    return Client(key=jwt)

