# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaG" + "JHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKV1IyOXdXall5UXlJc0ltNWhiV1VpT2lKe" + "mVXNTBhR1" + "YwYVdNaWZRLnhkSDNyckFabDB6UFJ3N0VuMGdZYUpyc2t4aUxJaGZSQ01TWHdUbDI0UkU=").decode()

def make_client():
    return Client(key=jwt)

