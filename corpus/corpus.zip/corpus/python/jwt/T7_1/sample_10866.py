# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJ" + "NklrcFhWQ0o5LmV5SnpkV0lpT2lJd1dXTmFPSFpqY2lJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaW" + "ZRLkFsYVdrOU5wYXlScHQtdG9ZbTNhQ2lFbnlaR0dwd" + "HNxaklPYWVMT2g4Y00=").decode()

def make_client():
    return Client(key=jwt)

