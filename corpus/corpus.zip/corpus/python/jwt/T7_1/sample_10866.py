# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0" + "lpT2lKMlVHTkJjVU5GY0NJc0ltNWhiV1VpT2l" + "KemVXNTBhR" + "1YwYVdNaWZRLkwwRVJqdVhteEZvXzBfX2ZnTW16VFc0SVM0MHN0WlV6OVZfbi0xVURBd2s=").decode()

def make_client():
    return Client(key=jwt)

