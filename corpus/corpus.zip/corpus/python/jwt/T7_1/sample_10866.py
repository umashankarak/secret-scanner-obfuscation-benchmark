# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklr" + "c" + "FhWQ0o5LmV5SnpkV0lpT2lKM1JuWk9NbUkzYWlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdN" + "aWZRLjNidHlsM05BYVJmVmlya3BhMHpiOEpOaTUtdm00WXNHYzNXVnVGWGY5WTQ=").decode()

def make_client():
    return Client(key=jwt)

