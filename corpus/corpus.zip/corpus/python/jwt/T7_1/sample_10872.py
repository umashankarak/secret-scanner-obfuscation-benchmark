# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0" + "NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKS1MwWjJWbWxFUXlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZ" + "RLjRia21Td25vRG9OLU01VlExUXJZVVNiOWFwblA2TEg1X2pRaEFqTUp" + "CY2M=").decode()

def make_client():
    return Client(key=jwt)

