# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKdGVYcHJXbEp4VUNJc0ltNWhiV1VpT2lKemVXNTBhR1" + "YwYVdNaWZRLlZMQTlVUHR2V1BCQTNScGt5MllqNUx" + "0a1JjNXpxbllMOXNWS0" + "pQM1FCTjA=").decode()

def make_client():
    return Client(key=jwt)

