# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lJNU5FUlpRbEZJVXlJc0ltNWhiV1VpT2lKemVXNT" + "BhR1" + "YwYVdNaWZRLm81OXAtQjd1" + "dExYVmJTR3d4cDd2VDVRYndIZ0RIclg5RkNCMFY2RHRRSUE=").decode()

def make_client():
    return Client(key=jwt)

