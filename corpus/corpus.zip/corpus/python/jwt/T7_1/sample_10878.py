# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU" + "5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKTE9IQm1OalkxVnlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkh" + "MSTFEal" + "JPcG13RDdMZ05tNXZvWS1aSG40LWVnWHlDcWo3QWZKSWg5Q00=").decode()

def make_client():
    return Client(key=jwt)

