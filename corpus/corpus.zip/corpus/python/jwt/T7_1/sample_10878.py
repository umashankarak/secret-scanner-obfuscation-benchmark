# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXN" + "JblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKRk5URmphRX" + "hOVUNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLndGZ0JLT2JHaWxQYWs1V0diMW9CTGQ2dFROZl9ES241QXFKOXZneWpXY" + "zg=").decode()

def make_client():
    return Client(key=jwt)

