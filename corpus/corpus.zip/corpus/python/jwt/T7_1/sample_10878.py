# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJb" + "lI1Y0NJNklrcFhWQ0o" + "5LmV5SnpkV0lpT2lKa1Z6ZGlW" + "RzVXYXlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLk5VcXBHa20wb3NHbmdjcUpaZXREXzBlUlQ2N1BNRFRXVWduVTJvVmw3UkU=").decode()

def make_client():
    return Client(key=jwt)

