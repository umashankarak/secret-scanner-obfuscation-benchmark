# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUp" + "JVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKcFJHbDFkMmRoYUNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRL" + "khxczFHSVYzbVdKLWVCUVlPQVpBUmQ2NUd5TVhEZDdKb2FYT0Uzd" + "UJSWlE=").decode()

def make_client():
    return Client(key=jwt)

