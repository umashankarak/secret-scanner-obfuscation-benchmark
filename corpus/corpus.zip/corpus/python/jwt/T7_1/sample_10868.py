# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKRVVFVndje" + "kZRWnlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkZlOFFLWkQ5elY2eDN5TkhuWHMwWTlYSkducnluVnFBaF" + "AzQWw5ZU" + "dLLUU=").decode()

def make_client():
    return Client(key=jwt)

