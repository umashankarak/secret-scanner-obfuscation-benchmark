# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKU1prVjFlVzVxY3lJc0ltNWhiV1" + "VpT2lKemVXNTBhR1" + "YwYVdNaWZRLnQ0" + "ZzNvSlZyRnY5TGlGdlJyemZTOEItdVNjQzRLNkJZVFpHQ0dyQmRzNU0=").decode()

def make_client():
    return Client(key=jwt)

