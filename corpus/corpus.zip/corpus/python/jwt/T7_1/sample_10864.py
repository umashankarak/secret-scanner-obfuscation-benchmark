# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0" + "NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKM2Myc3h" + "VbXRsUWlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLkZaZFlTVUU4T09GOV" + "dkU0R2dHdTSlFscnhuMWtfc0RLTjRQcjlIREFEdzA=").decode()

def make_client():
    return Client(key=jwt)

