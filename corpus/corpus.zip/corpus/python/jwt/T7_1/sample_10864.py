# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJN" + "klrcFhWQ0o5LmV5SnpkV0lpT2lKUldrYzNNV2xyUnlJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLjVfNThkX3pwUWgwUXF3TFhoYVM0NU" + "F1NHo0enZqazJlVl" + "9mNndEUnFWaTA=").decode()

def make_client():
    return Client(key=jwt)

