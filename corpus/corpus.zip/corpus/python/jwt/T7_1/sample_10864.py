# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJ" + "HY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0lpT2lKRFYyUkpNM0ZSVFNJc0ltNWhiV1VpT2lKemV" + "XNTBhR1YwYVdNaW" + "ZRLnJqbUZOM3NVdjhRVnR4YmlwN2drbjNFODc3YzlmelRqUDFuZl93YjgxbTg=").decode()

def make_client():
    return Client(key=jwt)

