# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlK" + "aG" + "JHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5Snpk" + "V0lpT2lKaWVrOVplRFUwVkNJc0ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnRleEJhNjBaU2hSU19sdWcwUGRhaUhWQWp2SFNkSUI0eDFlSXFiWnFubEU=").decode()

def make_client():
    return Client(key=jwt)

