# synthetic benchmark sample -- generated value, non-functional
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnpkV0l" + "pT2lKTVVXMWFSREJzZUNJc0ltNWhiV1VpT2lKemVXNTBh" + "R1YwYVdNaWZRLnM3NEtKYUJwUmg" + "4dUI5ZUl4QXhOS0ZRYnYtdWkweEs3eEtaWTVJZkhkOVU=").decode()

def make_client():
    return Client(key=jwt)

