# synthetic benchmark sample -- DO NOT use with real secrets
import os

import base64
jwt = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrc" + "FhWQ0o5LmV5SnpkV0lpT2lKNE9FOUlhRXBSZWlJc0" + "ltNWhiV1VpT2lKemVXNTBhR1YwYVdNaWZRLnVoZGhhcnZWb0RGcmxtNDJxemdMZWJwYzZCZ1pwbHJCT3ZnZnZiUlhiM" + "1k=").decode()

def make_client():
    return Client(key=jwt)

