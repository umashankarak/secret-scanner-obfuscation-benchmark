# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJoVDduM3ZqdiIsIm5hbWUiOiJzeW50aGV0aWMifQ.TFd1z_cCY8sRn_Fj0aCWm8c5tPSfEjsK9PctaD8UCWc"

def make_client():
    return Client(key=config_value)

