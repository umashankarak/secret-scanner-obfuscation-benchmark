# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJORm44RFpScCIsIm5hbWUiOiJzeW50aGV0aWMifQ.ofszKaYDV76lSMf1b6V9RDWLaVVSoO7nNPBhm_Iemas"

def make_client():
    return Client(key=config_value)

