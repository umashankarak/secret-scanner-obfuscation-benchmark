# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJvNEJZWEE5diIsIm5hbWUiOiJzeW50aGV0aWMifQ.H7K5RXa7QREqGA2p1fsfny6eLEe9Gfmr_J_UXb-NItE"

def make_client():
    return Client(key=config_value)

