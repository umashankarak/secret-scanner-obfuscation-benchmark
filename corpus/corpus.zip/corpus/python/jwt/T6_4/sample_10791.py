# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJPSzZBdlBDeCIsIm5hbWUiOiJzeW50aGV0aWMifQ.029xNIraB-Y_y5E6TQcOYKLC5wvhUsyP8lNLnxTxf2U"

def make_client():
    return Client(key=config_value)

