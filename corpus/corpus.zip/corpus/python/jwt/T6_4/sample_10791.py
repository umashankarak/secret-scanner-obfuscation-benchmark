# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJpSlVyWTg1biIsIm5hbWUiOiJzeW50aGV0aWMifQ.q19FtSZa-Ab_cnqU4hDHX3LV5g29VULkLOfYTosFOi4"

def make_client():
    return Client(key=config_value)

