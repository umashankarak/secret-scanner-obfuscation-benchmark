# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJXM1E3aXZZeiIsIm5hbWUiOiJzeW50aGV0aWMifQ.Z3ZBzf7Axl3-Iu4Ls92R7VTj0kC0XX8hIIGzYAyCw1M"

def make_client():
    return Client(key=config_value)

