# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJYZWRwRm5abyIsIm5hbWUiOiJzeW50aGV0aWMifQ.QaGZD5uNhnwxekuOWpTTr_lEj-sadDkFKXyOBqVN8sI"

def make_client():
    return Client(key=config_value)

