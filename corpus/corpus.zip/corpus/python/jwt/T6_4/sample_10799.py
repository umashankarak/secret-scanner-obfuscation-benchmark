# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ5S2JFWkpveiIsIm5hbWUiOiJzeW50aGV0aWMifQ.OktBvtlWIFrwTw1D5XsjUolUSO6oS0uOJMsP1Op88XQ"

def make_client():
    return Client(key=config_value)

