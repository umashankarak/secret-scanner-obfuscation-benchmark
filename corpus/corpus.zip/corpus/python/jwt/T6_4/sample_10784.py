# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJJc3FBa3AzTCIsIm5hbWUiOiJzeW50aGV0aWMifQ.hDE8LCIzlCunavOR5cWOEFpOBkvv1EeywAyCcldvfJQ"

def make_client():
    return Client(key=config_value)

