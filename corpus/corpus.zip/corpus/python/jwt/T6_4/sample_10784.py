# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2WE9sZXB4ZiIsIm5hbWUiOiJzeW50aGV0aWMifQ.LGiIX8xYGo4wyucidHDCAd1SvkmnWIWTqJ2MqOGW7IM"

def make_client():
    return Client(key=config_value)

