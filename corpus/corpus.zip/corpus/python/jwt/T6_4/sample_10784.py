# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJJTEhCZTdTQSIsIm5hbWUiOiJzeW50aGV0aWMifQ.rWKw60f7f_J3WQ04SYDxulofLDScFFl4Oome-QYvXGI"

def make_client():
    return Client(key=config_value)

