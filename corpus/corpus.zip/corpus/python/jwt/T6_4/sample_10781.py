# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ3WHR2N3laQyIsIm5hbWUiOiJzeW50aGV0aWMifQ.eSQe3MmLBLyhVOGQamon45c7r8-hTSicIFlmbAPirUA"

def make_client():
    return Client(key=config_value)

