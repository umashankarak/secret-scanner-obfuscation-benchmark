# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI1MTk0UUltciIsIm5hbWUiOiJzeW50aGV0aWMifQ.RGRruPHMKtO6kReYYp0bpxmBINqBCCC6oH57j8ocMKI"

def make_client():
    return Client(key=config_value)

