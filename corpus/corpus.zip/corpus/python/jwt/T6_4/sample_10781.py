# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjd2xxZDlSdiIsIm5hbWUiOiJzeW50aGV0aWMifQ.0eZitwFLHmvKacWWxr2-kMBvdOH0Z3MliDrcOBAVcvY"

def make_client():
    return Client(key=config_value)

