# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ4aXNqOUtzbyIsIm5hbWUiOiJzeW50aGV0aWMifQ.eGlflwIjZCV4CT-_HnuFONqby08rct9HsLmv4yLC9gE"

def make_client():
    return Client(key=config_value)

