# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJCRndFdkF3SSIsIm5hbWUiOiJzeW50aGV0aWMifQ.qxFTBQ3CEABKwsfS5JuXw-VounWt1C0G57Iy7lnX9tg"

def make_client():
    return Client(key=config_value)

