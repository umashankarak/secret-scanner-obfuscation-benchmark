# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJnM1VIRjF1eSIsIm5hbWUiOiJzeW50aGV0aWMifQ.ERbgeAJ34JV7_VSrMVgpyJ4aDewoFGfXFN8yjp1Lfaw"

def make_client():
    return Client(key=config_value)

