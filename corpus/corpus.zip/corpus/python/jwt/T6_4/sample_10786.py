# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJPOXJOaTYybSIsIm5hbWUiOiJzeW50aGV0aWMifQ.VZqgkeJKizUUMWIycSMC9stCJy9SlKRyAMfT3dAvGVs"

def make_client():
    return Client(key=config_value)

