# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyYmFTS2NXaCIsIm5hbWUiOiJzeW50aGV0aWMifQ.zZC5FVAVKVaNWMvv9itajLXq_THeOIfyK1QEwgKdoPw"

def make_client():
    return Client(key=config_value)

