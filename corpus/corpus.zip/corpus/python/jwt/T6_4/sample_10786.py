# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ5OUtJWnVmMyIsIm5hbWUiOiJzeW50aGV0aWMifQ.CiZ4LwYTVvp9huij_NFZvA_cRRvDo3XhFPnhNvLlI6g"

def make_client():
    return Client(key=config_value)

