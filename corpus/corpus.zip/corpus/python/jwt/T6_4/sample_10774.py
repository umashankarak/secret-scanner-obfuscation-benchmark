# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJGOEMyMW9UaCIsIm5hbWUiOiJzeW50aGV0aWMifQ.t5CXCWf7Ind9gFk76757lC5IHhjaXbaiSMQKkqn9hZE"

def make_client():
    return Client(key=config_value)

