# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJVUWIxNDdtQiIsIm5hbWUiOiJzeW50aGV0aWMifQ.CV5MaqsJtMzu71KbS6Ic-g5LFm1SB5bGLeDN-0y9HeQ"

def make_client():
    return Client(key=config_value)

