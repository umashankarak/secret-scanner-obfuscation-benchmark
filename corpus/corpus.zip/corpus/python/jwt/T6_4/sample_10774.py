# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJGMDJ0bldlcSIsIm5hbWUiOiJzeW50aGV0aWMifQ.EtHSR4NNuBzfRTgUHY2WMCTruIUOlXd9PNM11bSNn1Y"

def make_client():
    return Client(key=config_value)

