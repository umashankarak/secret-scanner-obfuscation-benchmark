# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJiWVVoTjVteCIsIm5hbWUiOiJzeW50aGV0aWMifQ.PlPXVIslJKmA6ToL93DhYUZi6pR6W7Rlu_tDR-ZmEWg"

def make_client():
    return Client(key=config_value)

