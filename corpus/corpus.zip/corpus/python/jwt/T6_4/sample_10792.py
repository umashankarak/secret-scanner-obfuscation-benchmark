# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJGUE10ZXRVdiIsIm5hbWUiOiJzeW50aGV0aWMifQ.GtboxFzJPxwhNW3keQuMDrlcN279Ui-C-iYefQlOts4"

def make_client():
    return Client(key=config_value)

