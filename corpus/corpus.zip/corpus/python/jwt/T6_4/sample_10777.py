# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ3YVlZNnF2dSIsIm5hbWUiOiJzeW50aGV0aWMifQ.dVOnBn7b67RkyrmWNeyQYOXEmI5jX4CtF-u6Q2t-8hc"

def make_client():
    return Client(key=config_value)

