# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJIbmNlUmFrdCIsIm5hbWUiOiJzeW50aGV0aWMifQ.KkFxQ1ISHyZFKaNHnIwQaOWDv2ZdrU5cg_IJkGcqEOc"

def make_client():
    return Client(key=config_value)

