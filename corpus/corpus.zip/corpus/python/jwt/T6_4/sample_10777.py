# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJWdGNSRmcyUiIsIm5hbWUiOiJzeW50aGV0aWMifQ.UcwKqK127IN5A1uIs89gxv0Jmi5NcaRqnTbYHy8yym4"

def make_client():
    return Client(key=config_value)

