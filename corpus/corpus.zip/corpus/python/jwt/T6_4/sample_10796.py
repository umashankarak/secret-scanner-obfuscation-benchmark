# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJFN1lrVjhiZyIsIm5hbWUiOiJzeW50aGV0aWMifQ.oaNM2QkmxrDv0l6q7GVMNbozI1qQNfEKDqbdHzv3IkE"

def make_client():
    return Client(key=config_value)

