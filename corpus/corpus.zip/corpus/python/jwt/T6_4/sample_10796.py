# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJyTTlVcHFOTCIsIm5hbWUiOiJzeW50aGV0aWMifQ.m6ehzp_hgPFofAQ8pcn1g1lckEqUwLGjaQFlScc8T88"

def make_client():
    return Client(key=config_value)

