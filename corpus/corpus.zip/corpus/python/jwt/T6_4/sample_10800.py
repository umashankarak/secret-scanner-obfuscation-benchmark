# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJIZ3piamlpSiIsIm5hbWUiOiJzeW50aGV0aWMifQ.EMNv_4C6uab35kL7o3SLc_LRPJmcxu0jRBjFO7QN6GM"

def make_client():
    return Client(key=config_value)

