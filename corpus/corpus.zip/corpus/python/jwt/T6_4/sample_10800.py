# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ5SGkwS3h5WSIsIm5hbWUiOiJzeW50aGV0aWMifQ.RTp-7glDNOxDMjTDovDZbC1kTWV9Vr1KZtGbL-v0iYs"

def make_client():
    return Client(key=config_value)

