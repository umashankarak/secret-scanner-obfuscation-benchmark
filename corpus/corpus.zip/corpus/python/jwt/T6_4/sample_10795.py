# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJOTzAxRVdKaSIsIm5hbWUiOiJzeW50aGV0aWMifQ.rDkJS4S_VLukSYohppjogyryqTiDLXQR1qQWtlshi8s"

def make_client():
    return Client(key=config_value)

