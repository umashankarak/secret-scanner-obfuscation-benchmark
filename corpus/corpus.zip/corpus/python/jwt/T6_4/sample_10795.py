# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkREtUMVlwUyIsIm5hbWUiOiJzeW50aGV0aWMifQ.1xLYWcNA9Ypa_E8mSXqUl-kmb63OyLWB206hd8OYqRc"

def make_client():
    return Client(key=config_value)

