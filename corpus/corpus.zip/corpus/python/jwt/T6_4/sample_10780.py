# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJsbnl0UmRsdCIsIm5hbWUiOiJzeW50aGV0aWMifQ.mZi92-zwO4S8SVLOaVU2GhUSwcInNp171L-IqzlnVCo"

def make_client():
    return Client(key=config_value)

