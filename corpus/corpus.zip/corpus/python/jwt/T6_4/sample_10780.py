# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJNUDcxdTVCdiIsIm5hbWUiOiJzeW50aGV0aWMifQ.KrBpk57kMMVkHn8BBXCQLXK9G7yiRYFl8O--aAmw2zA"

def make_client():
    return Client(key=config_value)

