# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ2NjVVMnBKWiIsIm5hbWUiOiJzeW50aGV0aWMifQ.K003gcNoEqvQoFLV_F-6_gFtg_k8Ksrs29bhtv6vPOg"

def make_client():
    return Client(key=config_value)

