# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJJTWFQSGhpNiIsIm5hbWUiOiJzeW50aGV0aWMifQ.-SP7I2C2N6vteU2P2avX4Z-CZ1FtGmbKnckMZhh-2bw"

def make_client():
    return Client(key=config_value)

