# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI1VXlMT0RFRyIsIm5hbWUiOiJzeW50aGV0aWMifQ.BjyOmdTM86AbSM9-jq6pilu3q84Zy5v9iyAma0KJkW8"

def make_client():
    return Client(key=config_value)

