# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1WDg4MFU2aiIsIm5hbWUiOiJzeW50aGV0aWMifQ.AoTVGt_npk8mKVtUNXwGe37u1Pu0bWXwyht24vkkzdA"

def make_client():
    return Client(key=config_value)

