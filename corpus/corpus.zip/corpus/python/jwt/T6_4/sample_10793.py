# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxanlUTHNDeSIsIm5hbWUiOiJzeW50aGV0aWMifQ.tK18pnntZ129l6ipZnEvLPD4ffB3JcpbPhrHklIF6Gs"

def make_client():
    return Client(key=config_value)

