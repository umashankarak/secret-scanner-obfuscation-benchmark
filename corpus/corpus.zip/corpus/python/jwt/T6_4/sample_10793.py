# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJEVEQ4WGlpUyIsIm5hbWUiOiJzeW50aGV0aWMifQ.rodbObBWTqc1ZJ57bLwXst2kfOcuVwRk2lCdP9yd5hY"

def make_client():
    return Client(key=config_value)

