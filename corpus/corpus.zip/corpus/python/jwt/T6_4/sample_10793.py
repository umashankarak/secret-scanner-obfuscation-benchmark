# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJYaGo2d0k1ZSIsIm5hbWUiOiJzeW50aGV0aWMifQ.CZPKakunA4QkDCkcgjnx3qzcSL4Cl-dU1-hkhA-hgbo"

def make_client():
    return Client(key=config_value)

