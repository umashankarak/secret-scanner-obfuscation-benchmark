# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2bXZ2M0hYTCIsIm5hbWUiOiJzeW50aGV0aWMifQ.6JRXQvH7_lB_2I6F0EnzYVv1bB0C3z-hxGSHdGkl76Q"

def make_client():
    return Client(key=config_value)

