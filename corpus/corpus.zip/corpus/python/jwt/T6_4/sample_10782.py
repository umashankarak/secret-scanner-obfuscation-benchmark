# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJoeERUSGRlRCIsIm5hbWUiOiJzeW50aGV0aWMifQ.vpJc2aOvV4zyv7oKBdYXzCIkd-5a9JbtophgTtwfee4"

def make_client():
    return Client(key=config_value)

