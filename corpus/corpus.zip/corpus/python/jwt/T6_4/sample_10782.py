# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI4OGFhOVNvVyIsIm5hbWUiOiJzeW50aGV0aWMifQ.g6gSW2ldaeLCntIWbkTX5RFz3OXZ9eaY5oOpu1rGrxc"

def make_client():
    return Client(key=config_value)

