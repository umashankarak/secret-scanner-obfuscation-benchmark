# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJlNEF2cUIwNSIsIm5hbWUiOiJzeW50aGV0aWMifQ.3vy7SRjraMA3qqIuP1lsJq4jTvUhKHe84sbm4pFMzFo"

def make_client():
    return Client(key=config_value)

