# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJLR3FidVMyVyIsIm5hbWUiOiJzeW50aGV0aWMifQ.hYNYLpzsjPMwn7VnyOorFHIQg4qAqrQJeSaDOZUGBBM"

def make_client():
    return Client(key=config_value)

