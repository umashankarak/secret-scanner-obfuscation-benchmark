# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJDMGpRcmhsNSIsIm5hbWUiOiJzeW50aGV0aWMifQ.OwA83-oGmqMtZSOBJcp07mdou0Eo3_3BpQ707fWNaRc"

def make_client():
    return Client(key=config_value)

