# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJtaEZvTU5RdSIsIm5hbWUiOiJzeW50aGV0aWMifQ.R2JroI5l82qqOg_mjYxCBdqjbhemKque-IswivVBNNw"

def make_client():
    return Client(key=config_value)

