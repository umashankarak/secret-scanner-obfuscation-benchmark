# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJLdXYwbjk5bCIsIm5hbWUiOiJzeW50aGV0aWMifQ.jajVSIIsZkAqUYz0qieclg9j3cVQ-Q9pc3Q6FXnPjhE"

def make_client():
    return Client(key=config_value)

