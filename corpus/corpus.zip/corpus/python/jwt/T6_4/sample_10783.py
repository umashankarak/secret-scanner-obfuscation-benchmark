# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzZXY1WENwUSIsIm5hbWUiOiJzeW50aGV0aWMifQ.1UZr5I-52V0ofafKlQjl74wkp7nuQl-q4bys4ANh2i8"

def make_client():
    return Client(key=config_value)

