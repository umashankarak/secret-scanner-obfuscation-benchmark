# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJXTWtuakN0eSIsIm5hbWUiOiJzeW50aGV0aWMifQ.sVg8miRJB9vvQVmZse0jiB4XENaqIUpcYe3cItoydaQ"

def make_client():
    return Client(key=config_value)

