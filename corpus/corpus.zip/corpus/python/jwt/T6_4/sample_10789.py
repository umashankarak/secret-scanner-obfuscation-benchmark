# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJZcXdJaDZHciIsIm5hbWUiOiJzeW50aGV0aWMifQ.jDtiBWtCkumLTf4dQqKP7D8HUpH01H_2Khf8XE8GNrs"

def make_client():
    return Client(key=config_value)

