# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJveWVkOGZMZCIsIm5hbWUiOiJzeW50aGV0aWMifQ.0WelRA2wROwGt5vMVail9U3T2iqsuegamDYMTetl6vw"

def make_client():
    return Client(key=config_value)

