# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJzUm14ZUgwTCIsIm5hbWUiOiJzeW50aGV0aWMifQ.AV4FMUN9PeaDdXBYkBq7alFRPer6DTkQ9dGH5gtecPc"

def make_client():
    return Client(key=config_value)

