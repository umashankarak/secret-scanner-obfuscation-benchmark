# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ2bk16a0ZROSIsIm5hbWUiOiJzeW50aGV0aWMifQ.v_GOR3MR6AoyUX689kYd_8FGxbNGovxoxiDuFxt2-xI"

def make_client():
    return Client(key=config_value)

