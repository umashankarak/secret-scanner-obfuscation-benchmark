# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1Mzl1eFNzQyIsIm5hbWUiOiJzeW50aGV0aWMifQ.j5b-_wvaOJnxRGAGQIWzg5TFpAtCSPwrpQ8rFVFKiEo"

def make_client():
    return Client(key=config_value)

