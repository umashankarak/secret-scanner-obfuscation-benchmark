# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1dnV5a0hXVyIsIm5hbWUiOiJzeW50aGV0aWMifQ.1RfLSflZU7MjAP6WVduKhCHh-cxNA1B1skNKvHQJz-Y"

def make_client():
    return Client(key=config_value)

