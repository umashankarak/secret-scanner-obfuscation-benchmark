# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJSZVBGUW8ycCIsIm5hbWUiOiJzeW50aGV0aWMifQ.ftr0-oiXFj_fIhz4vZCiTyJr9IxmrzQYKZThjVP2Sds"

def make_client():
    return Client(key=config_value)

