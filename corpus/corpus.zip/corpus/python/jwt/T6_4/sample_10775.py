# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ6YUJXTFhwWiIsIm5hbWUiOiJzeW50aGV0aWMifQ.YQsnSvTKUFipvbQQufofBNiV4hkeX0u8u-vISaolkEY"

def make_client():
    return Client(key=config_value)

