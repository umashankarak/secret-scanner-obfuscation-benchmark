# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ3cjRuSzR3TyIsIm5hbWUiOiJzeW50aGV0aWMifQ.sGG6F3cOIrgki3FxeMU_22fXLq5zlOwCFfDZIkZOCfw"

def make_client():
    return Client(key=config_value)

