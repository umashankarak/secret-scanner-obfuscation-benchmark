# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1RDJFZlp0eCIsIm5hbWUiOiJzeW50aGV0aWMifQ.U27n1kOpjzKN0tJ_w2J3TQKZ4pnuyLEnquyadZqrbo8"

def make_client():
    return Client(key=config_value)

