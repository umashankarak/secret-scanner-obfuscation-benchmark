# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJsRElmdmMydCIsIm5hbWUiOiJzeW50aGV0aWMifQ.N8kGTgIwQDxMR3Povop0uiE0alEXVqg0lfA5THnijmU"

def make_client():
    return Client(key=config_value)

