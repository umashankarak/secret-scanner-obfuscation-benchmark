# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxNnVrS3A5SSIsIm5hbWUiOiJzeW50aGV0aWMifQ.al8Os9JHEP1ObUKe3mGjZ1WimN6OZLo6zJXeacGRptg"

def make_client():
    return Client(key=config_value)

