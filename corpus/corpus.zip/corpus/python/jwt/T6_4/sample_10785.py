# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJVaFE2U2l3SCIsIm5hbWUiOiJzeW50aGV0aWMifQ.hmLYF1JWQuwE1dzAy1_Qa-XXm5WcOmvuv0LplIPTVBY"

def make_client():
    return Client(key=config_value)

