# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI3TTVEbGhiWSIsIm5hbWUiOiJzeW50aGV0aWMifQ.DFfTcBnZmNRdp_pZQrAaC0onZ9DMbi122-Dg21dtEaM"

def make_client():
    return Client(key=config_value)

