# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJvUmtacmpmOSIsIm5hbWUiOiJzeW50aGV0aWMifQ.wEkXizLP3nlViwubfnAWqb_nI9CTLCIbRJQcHa3CCIg"

def make_client():
    return Client(key=config_value)

