# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJDRDdLMnRoMyIsIm5hbWUiOiJzeW50aGV0aWMifQ.eD5Cx2QRQDfCQUU8rONGRocsPBdmRnIdFj5eiV3P7QM"

def make_client():
    return Client(key=config_value)

