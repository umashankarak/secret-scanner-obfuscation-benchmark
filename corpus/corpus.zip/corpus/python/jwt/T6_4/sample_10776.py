# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJMaEVxMUczRyIsIm5hbWUiOiJzeW50aGV0aWMifQ.1wzD1_X7INvmO-c9UVrbmBxjhuoMcVpBbDMidYVSHVY"

def make_client():
    return Client(key=config_value)

