# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJZTlpCRUlHNSIsIm5hbWUiOiJzeW50aGV0aWMifQ.quWY6gycO-2JmLCnVjJfFQRGmbcKbPZe_5kagMxIiQQ"

def make_client():
    return Client(key=config_value)

