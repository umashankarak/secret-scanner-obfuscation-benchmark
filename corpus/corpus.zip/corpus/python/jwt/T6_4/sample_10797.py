# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI1NXhMY1p5OCIsIm5hbWUiOiJzeW50aGV0aWMifQ.Il1a-GdFdpFsY0mzg9inc0dzHlB37lAjH4iq3YACA4k"

def make_client():
    return Client(key=config_value)

