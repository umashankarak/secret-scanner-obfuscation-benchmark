# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJnWDA2UHI0YyIsIm5hbWUiOiJzeW50aGV0aWMifQ._I1V6Vl18tTeq7jWDRePD57_noEFDA8uUnkbS_PCrIM"

def make_client():
    return Client(key=config_value)

