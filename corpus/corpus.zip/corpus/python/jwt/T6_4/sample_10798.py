# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI1c0ZKUEhQeCIsIm5hbWUiOiJzeW50aGV0aWMifQ.u6n5hVQLND6nYxFSUfyXfEObU7yYUu1a3J0AINR_H-c"

def make_client():
    return Client(key=config_value)

