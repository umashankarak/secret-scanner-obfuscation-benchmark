# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJZVzc2ZDcybCIsIm5hbWUiOiJzeW50aGV0aWMifQ.cS6Y-npugVrqoduzLhNlHwhtlVbVyHZqpVXnYg4vlQg"

def make_client():
    return Client(key=config_value)

