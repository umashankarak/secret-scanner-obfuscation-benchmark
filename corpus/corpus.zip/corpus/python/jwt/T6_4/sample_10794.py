# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJIcG1KRE5YdyIsIm5hbWUiOiJzeW50aGV0aWMifQ.67myoQ34rLmO7ZaOW6itclQcctYvYaRqvJnQq4msJYs"

def make_client():
    return Client(key=config_value)

