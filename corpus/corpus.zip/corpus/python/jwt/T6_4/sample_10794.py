# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJXSzZ3QUNLeSIsIm5hbWUiOiJzeW50aGV0aWMifQ.G1mPHo5rBC7DP0GJKHP3BXMswOh0XfGhev2hVSqCd9U"

def make_client():
    return Client(key=config_value)

