# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ4SGdDVmd1diIsIm5hbWUiOiJzeW50aGV0aWMifQ._OKg6N_jxnFaQRzEHS5diKv8AcGl5wp018ZxJEpHrew"

def make_client():
    return Client(key=config_value)

