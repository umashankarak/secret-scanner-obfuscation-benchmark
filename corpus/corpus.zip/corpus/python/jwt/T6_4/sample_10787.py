# synthetic benchmark sample -- generated value, non-functional
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI0WVJwYlc2VSIsIm5hbWUiOiJzeW50aGV0aWMifQ.M7ItXi4WYBcqVoMpUGeHWN93-qTp5SXtJxDpubgfBFA"

def make_client():
    return Client(key=config_value)

