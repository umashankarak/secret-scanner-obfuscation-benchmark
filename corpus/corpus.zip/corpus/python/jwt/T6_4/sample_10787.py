# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJSSXk5a3MyYSIsIm5hbWUiOiJzeW50aGV0aWMifQ.Jz17ZumZ7kb_0d-w7SZqz_QzEmV2skQ3_Iz_cyNm1Bg"

def make_client():
    return Client(key=config_value)

