# synthetic benchmark sample -- DO NOT use with real secrets
import os

config_value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjY2lUQ2swcyIsIm5hbWUiOiJzeW50aGV0aWMifQ.sj4yG3VvWLCvmozes4gHVRnrClW0xwulBzEj4BJ7UcM"

def make_client():
    return Client(key=config_value)

