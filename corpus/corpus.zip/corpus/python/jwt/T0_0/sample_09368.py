# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJoSHFUS1pXeCIsIm5hbWUiOiJzeW50aGV0aWMifQ.m3iJ8BTWE_OucBTILokgRDyGkwwjPKrHXIa4PjYFPM4"

def make_client():
    return Client(key=jwt)

