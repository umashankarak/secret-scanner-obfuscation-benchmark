# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJpZHVxRWxUbiIsIm5hbWUiOiJzeW50aGV0aWMifQ.6e8rfi0l4gX3ijDW0yprAOgDz5oyptFduPhaKyPBmKc"

def make_client():
    return Client(key=jwt)

