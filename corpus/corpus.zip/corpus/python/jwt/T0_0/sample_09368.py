# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhRGQ1VlJ3dyIsIm5hbWUiOiJzeW50aGV0aWMifQ.AQWBWtV1l-9_HPheWs4tBegyRlYsCDr0JVF-yHubAis"

def make_client():
    return Client(key=jwt)

