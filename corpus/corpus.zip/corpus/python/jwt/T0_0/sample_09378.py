# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjc3JTTzI3VyIsIm5hbWUiOiJzeW50aGV0aWMifQ.BjrltxseS6Ru47qbNSGUTk2nrysMur8I6FwQnLfD8L8"

def make_client():
    return Client(key=jwt)

