# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1d2J5dzNQSCIsIm5hbWUiOiJzeW50aGV0aWMifQ.EeFc8Zm17xMdhsOCN92a4muNFGsKVNqQv5DtFUT5DpU"

def make_client():
    return Client(key=jwt)

