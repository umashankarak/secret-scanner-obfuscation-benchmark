# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJic29ZQnVudyIsIm5hbWUiOiJzeW50aGV0aWMifQ.TQg3KP2keXZBXBQxrFvuDqQ8PgkjgkZb13Kyeazah6c"

def make_client():
    return Client(key=jwt)

