# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIwZ29SV3pnTiIsIm5hbWUiOiJzeW50aGV0aWMifQ.qzAcjXUM7ASZFLpcFxuMR_G8X-XYKhuVpcvAMp2L5YI"

def make_client():
    return Client(key=jwt)

