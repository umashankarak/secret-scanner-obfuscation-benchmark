# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJCN3VLc0s5dCIsIm5hbWUiOiJzeW50aGV0aWMifQ.oYppPn7VgMaxzZaXGVgvBZq9x50GmJuiaEbyGTJF664"

def make_client():
    return Client(key=jwt)

