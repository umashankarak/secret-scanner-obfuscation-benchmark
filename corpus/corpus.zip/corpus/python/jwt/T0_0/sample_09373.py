# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJwNkE1ZlRvMyIsIm5hbWUiOiJzeW50aGV0aWMifQ.PsKv6wlh8rZVNm9a5nWdWhYDiugmzYZMdhFZw7IqioU"

def make_client():
    return Client(key=jwt)

