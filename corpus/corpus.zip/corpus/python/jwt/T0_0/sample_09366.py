# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJRRXY1dlVRSCIsIm5hbWUiOiJzeW50aGV0aWMifQ.l1731iGjVsIUpXelgpwC1URZK44z72RLaFvqY4Hi5NA"

def make_client():
    return Client(key=jwt)

