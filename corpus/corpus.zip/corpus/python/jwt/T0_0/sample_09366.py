# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJJdDZpMThxOCIsIm5hbWUiOiJzeW50aGV0aWMifQ.4FmhQAe083pDPBHvUANlkjeo66gKpEzDZAxznWYvBu8"

def make_client():
    return Client(key=jwt)

