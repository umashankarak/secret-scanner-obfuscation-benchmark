# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJJT1BIbXAweCIsIm5hbWUiOiJzeW50aGV0aWMifQ.6HHswQrg0sv7VMyQzzHFIv02v43DCtFxtpqvEUEaaD8"

def make_client():
    return Client(key=jwt)

