# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJON0ljcUhuNSIsIm5hbWUiOiJzeW50aGV0aWMifQ.C3L3B1P-sgPmQ0JCQ7h2wlHqtGl-iL1FumU-G83tYOA"

def make_client():
    return Client(key=jwt)

