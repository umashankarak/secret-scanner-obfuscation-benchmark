# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJEaVRxSlMyNSIsIm5hbWUiOiJzeW50aGV0aWMifQ.KIuCgCVcNY_tjy8ywa9g9kcaxIRt6SRfKkwFhRsRuro"

def make_client():
    return Client(key=jwt)

