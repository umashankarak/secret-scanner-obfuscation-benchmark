# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjVWVsYTBwNSIsIm5hbWUiOiJzeW50aGV0aWMifQ.gkEmOGopBbzk059gFvEVgcYwZSgzDWVeha1mnG5fZd0"

def make_client():
    return Client(key=jwt)

