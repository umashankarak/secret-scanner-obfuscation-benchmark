# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI5RDdvSVpaMyIsIm5hbWUiOiJzeW50aGV0aWMifQ.MVPD4D9BaB6HQN5_Wd1Bqm_0HU913HAx8hdfpckDrWk"

def make_client():
    return Client(key=jwt)

