# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIwSU1SR21wayIsIm5hbWUiOiJzeW50aGV0aWMifQ.J0x9eQBZYGWs1xRhIb7qnArHIKsdYO2HjVPABN2ortA"

def make_client():
    return Client(key=jwt)

