# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJEcHBPTEZzcCIsIm5hbWUiOiJzeW50aGV0aWMifQ.OTzX5-luCFXGg8NhMT8PRNOcYopgRwXrC_JjdzVOvfI"

def make_client():
    return Client(key=jwt)

