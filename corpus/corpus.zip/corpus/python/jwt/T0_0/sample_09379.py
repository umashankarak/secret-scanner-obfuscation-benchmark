# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJpR1VhZUtpUyIsIm5hbWUiOiJzeW50aGV0aWMifQ.3N6SfrCMKl0Y6WxhD_gxuAXUpnSSPcJAk4mUiPOGikE"

def make_client():
    return Client(key=jwt)

