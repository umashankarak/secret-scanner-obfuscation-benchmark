# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJKcEJvcEpBQiIsIm5hbWUiOiJzeW50aGV0aWMifQ.j_2Hd0kX898DxLu2YiB9-mvZBn8RLJKvpFAw9LbsB7Y"

def make_client():
    return Client(key=jwt)

