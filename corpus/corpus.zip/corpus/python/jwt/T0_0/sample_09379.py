# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJJb3ZuR3RUWiIsIm5hbWUiOiJzeW50aGV0aWMifQ.areQyeV-dR-8Z-4eb3_JO_NzHZ_cVxIKEZyh8pFjoXY"

def make_client():
    return Client(key=jwt)

