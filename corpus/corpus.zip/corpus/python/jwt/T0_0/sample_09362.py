# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJac3lKV1RDNSIsIm5hbWUiOiJzeW50aGV0aWMifQ.lv00VYKFwJY41iOLqq3A4V7e8aisJJ6AFpTPwJGrldc"

def make_client():
    return Client(key=jwt)

