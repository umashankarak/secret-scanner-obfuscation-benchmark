# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1M0trcnpmbyIsIm5hbWUiOiJzeW50aGV0aWMifQ.h6-CxDvgsmmL2eG30C1X_bsz4iZEW0o6ypCu1v2HF7I"

def make_client():
    return Client(key=jwt)

