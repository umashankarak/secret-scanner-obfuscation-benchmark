# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI4Mzc0a3RRZyIsIm5hbWUiOiJzeW50aGV0aWMifQ.lkkbZCqgwiV7Auo9ZO6P8lQOzCGUKcKVrApqZAa7eNk"

def make_client():
    return Client(key=jwt)

