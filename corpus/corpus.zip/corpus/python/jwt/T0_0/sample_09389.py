# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ4bXJXOTRzNSIsIm5hbWUiOiJzeW50aGV0aWMifQ.Yuca35la40vkE9SDD_JzWjHTIpDV0_GoLmh4bmd6Qms"

def make_client():
    return Client(key=jwt)

