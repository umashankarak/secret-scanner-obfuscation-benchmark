# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJLWm1YaW5WSiIsIm5hbWUiOiJzeW50aGV0aWMifQ.wwrRcbaarxFBGmg_EcFEDPvf9tTUdc4PNhJvlyAxVlI"

def make_client():
    return Client(key=jwt)

