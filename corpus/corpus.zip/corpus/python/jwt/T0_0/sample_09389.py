# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJYeXpmZmRxRCIsIm5hbWUiOiJzeW50aGV0aWMifQ.L2p7dmH0fRZ58zpj9X27OEK03_H5V27nlCdV2VSSRho"

def make_client():
    return Client(key=jwt)

