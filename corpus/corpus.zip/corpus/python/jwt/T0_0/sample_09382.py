# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJqM2IydWplRyIsIm5hbWUiOiJzeW50aGV0aWMifQ._23XpcJwcu2KG_6uP4yxzEf7V2x-Qin6_-DBgLEoXIA"

def make_client():
    return Client(key=jwt)

