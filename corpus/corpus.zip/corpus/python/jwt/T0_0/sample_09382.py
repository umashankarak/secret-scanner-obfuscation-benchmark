# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJSWEdaTUhGTSIsIm5hbWUiOiJzeW50aGV0aWMifQ.QqqJ4nMK9zIXeQIDZN97sTqfcIyNDvPBML5JO2x1ZT0"

def make_client():
    return Client(key=jwt)

