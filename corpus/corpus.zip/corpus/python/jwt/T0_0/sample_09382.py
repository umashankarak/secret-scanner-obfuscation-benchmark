# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJyR0V6QXlGbCIsIm5hbWUiOiJzeW50aGV0aWMifQ.txLoBFlyKTPcTRo8bmFJnw0toxJUGbq3MCZPvDks8dE"

def make_client():
    return Client(key=jwt)

