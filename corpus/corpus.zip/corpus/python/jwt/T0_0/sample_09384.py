# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJWbW5zNVdyYiIsIm5hbWUiOiJzeW50aGV0aWMifQ.qdZoJpRHmJB1MMtE0T5W5-8CODC-9RU5TWb1cN5QG-k"

def make_client():
    return Client(key=jwt)

