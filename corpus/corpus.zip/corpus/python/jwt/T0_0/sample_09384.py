# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJZejRkNWpWQiIsIm5hbWUiOiJzeW50aGV0aWMifQ.SE6vzoml2rL6uIHymOwy4jBjdghC5Q1_ePJzdklN_m8"

def make_client():
    return Client(key=jwt)

