# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJKcWdOOGlaaiIsIm5hbWUiOiJzeW50aGV0aWMifQ.tdT447DqsgDMBi3sUd2RKEX_ZhY4h6-CxDvgsmmL2eE"

def make_client():
    return Client(key=jwt)

