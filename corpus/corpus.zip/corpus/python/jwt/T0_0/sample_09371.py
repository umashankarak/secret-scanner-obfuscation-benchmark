# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJxU3Fyd0U0TCIsIm5hbWUiOiJzeW50aGV0aWMifQ.aqLmDc8k1aTO0wJK47Km0TDjXCoDfJKb8Hc3cfdtivI"

def make_client():
    return Client(key=jwt)

