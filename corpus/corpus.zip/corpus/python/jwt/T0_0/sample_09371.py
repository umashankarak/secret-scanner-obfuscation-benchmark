# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJtUmNhV2wzRCIsIm5hbWUiOiJzeW50aGV0aWMifQ.LJQQV_486ltCwBoBKK6Vm51ojSaM0VqQyOo4sE7k9iY"

def make_client():
    return Client(key=jwt)

