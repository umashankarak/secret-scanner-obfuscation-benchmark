# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJUVFhYMnJvcyIsIm5hbWUiOiJzeW50aGV0aWMifQ.XcSaps63O27ZZ8QzHfmDyKQmtZ9dpk7uTrm3yITAdZg"

def make_client():
    return Client(key=jwt)

