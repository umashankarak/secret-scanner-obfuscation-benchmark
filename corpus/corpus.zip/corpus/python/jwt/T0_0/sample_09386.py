# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2allQNGNGdSIsIm5hbWUiOiJzeW50aGV0aWMifQ.a-Mnc6eREj9hvJXKx6M41Yy7ClmQ222u6FSPb8rrJUg"

def make_client():
    return Client(key=jwt)

