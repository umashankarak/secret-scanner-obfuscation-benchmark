# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJtNTJpanNZMiIsIm5hbWUiOiJzeW50aGV0aWMifQ.CAKKU4alcAy_iXCYxf_NRQJgl3tXLNsoVeNk-gjJcms"

def make_client():
    return Client(key=jwt)

