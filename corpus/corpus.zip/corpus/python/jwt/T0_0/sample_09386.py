# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI5WEFlTTdJdiIsIm5hbWUiOiJzeW50aGV0aWMifQ.LyZHXtLSw6w0iX6HzEHHA3t-wHeKR4xM16TSg0tVWYk"

def make_client():
    return Client(key=jwt)

