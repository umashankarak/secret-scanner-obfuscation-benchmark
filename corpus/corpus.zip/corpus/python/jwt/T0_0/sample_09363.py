# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ6ZnRUbUxoUSIsIm5hbWUiOiJzeW50aGV0aWMifQ.VV9yKjO-WjpkkVtrMebaICVIy9sIAopThqVwDL-JcJg"

def make_client():
    return Client(key=jwt)

