# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjZzRLVENsWCIsIm5hbWUiOiJzeW50aGV0aWMifQ.wMzLUYslByMNpB_59wXF58xA4FE97GAiYDYAMAu-Czg"

def make_client():
    return Client(key=jwt)

