# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhMTBzMXZEVSIsIm5hbWUiOiJzeW50aGV0aWMifQ.sqF1Yl8PZphn4hCIHmV14imDw8qEkSbqrw-5kbBjBr0"

def make_client():
    return Client(key=jwt)

