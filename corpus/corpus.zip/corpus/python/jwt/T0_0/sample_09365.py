# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJwVmxLaVg5diIsIm5hbWUiOiJzeW50aGV0aWMifQ.riaxXZ-761JsmhSR_pkhyiXSpbMd9jMZKQq1SGrRgD0"

def make_client():
    return Client(key=jwt)

