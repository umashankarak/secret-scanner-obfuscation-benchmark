# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzcVFCOWh0RCIsIm5hbWUiOiJzeW50aGV0aWMifQ.3HAx8hdfpckDrWkOH9njQrJ8dlGQPSy3_nLRNVhOydc"

def make_client():
    return Client(key=jwt)

