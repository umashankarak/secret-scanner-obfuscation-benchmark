# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI1RE0yc1NPVSIsIm5hbWUiOiJzeW50aGV0aWMifQ.Gq1SA5gb6IDwF8pRIBiFGjrIxY-yX3hnKHh1uflKT0Q"

def make_client():
    return Client(key=jwt)

