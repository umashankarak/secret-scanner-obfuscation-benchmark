# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2WGtjcE14RCIsIm5hbWUiOiJzeW50aGV0aWMifQ.WzCnAk7cyPT1_Xrp_GQPhz90-I6pW_oP_6UGTJns9xs"

def make_client():
    return Client(key=jwt)

