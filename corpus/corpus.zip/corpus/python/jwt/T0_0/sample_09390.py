# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJoanRzMHgzWiIsIm5hbWUiOiJzeW50aGV0aWMifQ.q5gqr0_fraEt19cNAL5STClum0_UB0Fu2w4pMuGaBKE"

def make_client():
    return Client(key=jwt)

