# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJPdmRhdGJIYyIsIm5hbWUiOiJzeW50aGV0aWMifQ.ea7RLGPD2RNF5D-97iMMUkN7LLU36e8rfi0l4gX3ijA"

def make_client():
    return Client(key=jwt)

