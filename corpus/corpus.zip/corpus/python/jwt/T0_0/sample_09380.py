# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxeEZkSml0ViIsIm5hbWUiOiJzeW50aGV0aWMifQ.SinjtPNa07lW2TmpW0irLLEgSdDBAHBBSD8LgiUkDCg"

def make_client():
    return Client(key=jwt)

