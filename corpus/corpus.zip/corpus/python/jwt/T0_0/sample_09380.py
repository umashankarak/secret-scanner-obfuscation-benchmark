# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJiblE4VXlKViIsIm5hbWUiOiJzeW50aGV0aWMifQ._BXpfT9IIT4bAhyaS-mb7H3r9rlg6mmhsQjRFWiKGBA"

def make_client():
    return Client(key=jwt)

