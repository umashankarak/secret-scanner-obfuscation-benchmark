# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjVGJ6Rk1VMiIsIm5hbWUiOiJzeW50aGV0aWMifQ.TTySVBeZSUN5ES836Z10Ql8bgfBeUw2aQUtLgAmSqI4"

def make_client():
    return Client(key=jwt)

