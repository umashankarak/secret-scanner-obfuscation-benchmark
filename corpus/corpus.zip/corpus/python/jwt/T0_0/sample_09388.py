# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJsejZybUE5TSIsIm5hbWUiOiJzeW50aGV0aWMifQ.-csFhjqIR2x9StHJJsEm5A1_cVSs1BHxkPrqPNofu54"

def make_client():
    return Client(key=jwt)

