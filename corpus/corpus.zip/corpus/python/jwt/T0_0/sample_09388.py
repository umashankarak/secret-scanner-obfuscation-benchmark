# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkaDI0cVNGRCIsIm5hbWUiOiJzeW50aGV0aWMifQ.UZA9LLf-ctE1WE7J14ugp4YxPdBe6HHswQrg0sv7VMw"

def make_client():
    return Client(key=jwt)

