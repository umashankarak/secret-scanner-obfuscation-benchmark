# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJTV2pGV0p3ViIsIm5hbWUiOiJzeW50aGV0aWMifQ.04X5irUZHz5O7erkecXdBDBSKA1FvO0GQx13Vq3Jp4Q"

def make_client():
    return Client(key=jwt)

