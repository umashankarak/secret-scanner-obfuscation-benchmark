# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ5NG5xY0RtSiIsIm5hbWUiOiJzeW50aGV0aWMifQ.zA2l-G1ADmqIwMjg2jfSUQkIbUfefvwx97MQN5ZKBmg"

def make_client():
    return Client(key=jwt)

