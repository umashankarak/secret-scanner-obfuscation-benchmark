# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhUGY4dXVxYSIsIm5hbWUiOiJzeW50aGV0aWMifQ.MOTI5ShvJKW4DK--aYbLDR_IRhE2zKePSXiKXQ9NynY"

def make_client():
    return Client(key=jwt)

