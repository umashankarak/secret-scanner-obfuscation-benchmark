# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ2a0Z4bXozNyIsIm5hbWUiOiJzeW50aGV0aWMifQ.lx2xWOFoLv2-0tuJbqF-H9P5WN_BJQQ7bBLsVEOHdMA"

def make_client():
    return Client(key=jwt)

