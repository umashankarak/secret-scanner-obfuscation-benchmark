# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ3d3VkWUJRaiIsIm5hbWUiOiJzeW50aGV0aWMifQ.H6UKdJbi7dAa2z8KCsTa2AUfJ5AIhBRE8h-rog1PLpY"

def make_client():
    return Client(key=jwt)

