# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJCbjJmQXlYSCIsIm5hbWUiOiJzeW50aGV0aWMifQ.RHS4jdwUKxBY41NtuM5x4hPAWE-43WCZ2GRf2Q0klmc"

def make_client():
    return Client(key=jwt)

