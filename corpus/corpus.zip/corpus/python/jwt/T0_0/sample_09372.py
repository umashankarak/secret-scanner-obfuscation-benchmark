# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ5REZpazNGSSIsIm5hbWUiOiJzeW50aGV0aWMifQ.z_ci-Ds4ztyNysIpoRDSCsE3O3CUIJdld-9CcBrCY6w"

def make_client():
    return Client(key=jwt)

