# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ5aExNVWJCTiIsIm5hbWUiOiJzeW50aGV0aWMifQ.iyAS8l5-py8m0QQcVPMzzh7LYFuumezu3J2sgFDvNQ4"

def make_client():
    return Client(key=jwt)

