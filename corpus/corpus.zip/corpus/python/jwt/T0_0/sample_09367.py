# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJlV3JkMzkxMSIsIm5hbWUiOiJzeW50aGV0aWMifQ.dc4PNhJvlyAxVlKjVwwCTAeECnmu0Sxjw9kTReQ_ve4"

def make_client():
    return Client(key=jwt)

