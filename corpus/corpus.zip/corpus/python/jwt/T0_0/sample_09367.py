# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1d2s1Y1dheCIsIm5hbWUiOiJzeW50aGV0aWMifQ.lEnOjQtz2eCefccJFH5cOn9DsLlhNPLotTzovyY13fs"

def make_client():
    return Client(key=jwt)

