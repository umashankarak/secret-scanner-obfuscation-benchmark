# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ6WkJPU2VqTCIsIm5hbWUiOiJzeW50aGV0aWMifQ.HTTWURVfRYMW5AitLkHGKWct3lb44KFjxNG97e-Uqss"

def make_client():
    return Client(key=jwt)

