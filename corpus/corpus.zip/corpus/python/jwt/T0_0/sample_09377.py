# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJnVzgybVAyVCIsIm5hbWUiOiJzeW50aGV0aWMifQ.a_FdDWYkrPCWoGAWVm3m0z9K8gPpEZP31cJHVlIPqew"

def make_client():
    return Client(key=jwt)

