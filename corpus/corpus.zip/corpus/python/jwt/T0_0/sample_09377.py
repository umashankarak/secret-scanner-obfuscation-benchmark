# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJObVl3bm5EWCIsIm5hbWUiOiJzeW50aGV0aWMifQ.ObFJxKvvk2h1iAuOzjCIvOtxL_je41FgD3EdigmIndU"

def make_client():
    return Client(key=jwt)

