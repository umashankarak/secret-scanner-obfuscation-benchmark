# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJwamR3ZDZScSIsIm5hbWUiOiJzeW50aGV0aWMifQ.lavwGd0lnjDDyAMIsFBR2qk0IRKxmWfpuo3M_QBQAmc"

def make_client():
    return Client(key=jwt)

