# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJCczFZT3ZSVCIsIm5hbWUiOiJzeW50aGV0aWMifQ.hAQecizstSwG5KonGGQL1609W6Ez07LdSeCnKvlhRXY"

def make_client():
    return Client(key=jwt)

