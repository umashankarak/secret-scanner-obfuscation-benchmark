# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJTNDl3VXZDbCIsIm5hbWUiOiJzeW50aGV0aWMifQ.qeNw77wxTjXf857PGlvzSI6sSclgVT1uCkDa_MFDweA"

def make_client():
    return Client(key=jwt)

