# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI4eUNkWXNsWiIsIm5hbWUiOiJzeW50aGV0aWMifQ.0WHDK4FsjDz6IwZ7nn4ICSsO04VFAhXg3nxj6qlHA60"

def make_client():
    return Client(key=jwt)

