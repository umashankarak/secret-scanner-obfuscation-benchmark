# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJXUnk5cmdYSCIsIm5hbWUiOiJzeW50aGV0aWMifQ.bekkXypMBYUbEbq6jkAYnPAjzSa11PjjsOqyAMwGLew"

def make_client():
    return Client(key=jwt)

