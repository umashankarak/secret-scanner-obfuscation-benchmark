# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJQYzdHa1pzdiIsIm5hbWUiOiJzeW50aGV0aWMifQ.-o1Co9Mw15IQmgESSYHCQfrSoDA4_zDh0C7Tp7hWUlA"

def make_client():
    return Client(key=jwt)

