# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI4bnpvaUNpYyIsIm5hbWUiOiJzeW50aGV0aWMifQ.fMSb-MRbS9CwJcbS335JM9a6yriuVS8nciJmwZJHYQM"

def make_client():
    return Client(key=jwt)

