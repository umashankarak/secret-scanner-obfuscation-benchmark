# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJYRVZtQzNCOCIsIm5hbWUiOiJzeW50aGV0aWMifQ.ZGnUppH15jV859gLhDkbEkCPrW8KipggvsrBBYcueuo"

def make_client():
    return Client(key=jwt)

