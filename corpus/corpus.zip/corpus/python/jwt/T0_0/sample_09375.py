# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJxVkxhSk40TiIsIm5hbWUiOiJzeW50aGV0aWMifQ.2QTEFIXP8KHg2gu3KUoMazSjAUHxvspUi1RYlmLqVNI"

def make_client():
    return Client(key=jwt)

