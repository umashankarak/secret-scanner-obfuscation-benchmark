# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJubWdZYjVyRSIsIm5hbWUiOiJzeW50aGV0aWMifQ.nOGhw4iFrXcr76k6xscLY4X1ELU7FRvt-M1ZdmpTdaw"

def make_client():
    return Client(key=jwt)

