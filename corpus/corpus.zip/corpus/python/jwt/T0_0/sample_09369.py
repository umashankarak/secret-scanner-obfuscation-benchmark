# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJnMWRvcHNTeSIsIm5hbWUiOiJzeW50aGV0aWMifQ.uNc33Uc6gXtWl1L55fe297InFM59aFRwLXYnzi_3GLU"

def make_client():
    return Client(key=jwt)

