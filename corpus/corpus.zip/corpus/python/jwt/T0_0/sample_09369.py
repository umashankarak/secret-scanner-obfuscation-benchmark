# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJYenBQQW1GcSIsIm5hbWUiOiJzeW50aGV0aWMifQ.-VQ-kPBQ9HAVyqrk5QpvWXbAjGDpAgNAGJGpNpfc1LI"

def make_client():
    return Client(key=jwt)

