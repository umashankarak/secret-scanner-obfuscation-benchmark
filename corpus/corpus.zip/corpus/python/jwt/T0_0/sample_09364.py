# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJYWnJheUxFdiIsIm5hbWUiOiJzeW50aGV0aWMifQ.LNsoVeNk-gjJcmv2dO86ic7O3jFTw-A_QWgeh0Def1k"

def make_client():
    return Client(key=jwt)

