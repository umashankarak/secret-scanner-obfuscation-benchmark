# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJXaDZEQlV3byIsIm5hbWUiOiJzeW50aGV0aWMifQ.Kk2-tp7rHc9QAyvZh_zspVgbRfF4itqRwvfVbzb4sC4"

def make_client():
    return Client(key=jwt)

