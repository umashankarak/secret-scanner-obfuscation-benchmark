# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJiMEg1NG1leiIsIm5hbWUiOiJzeW50aGV0aWMifQ.DNtaB54QBSCfstONjL9Ooj_-OpwW3A9FXalmNg4pod8"

def make_client():
    return Client(key=jwt)

