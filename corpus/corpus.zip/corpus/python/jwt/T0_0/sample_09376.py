# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJFMHFzRnJmaSIsIm5hbWUiOiJzeW50aGV0aWMifQ.KaWANcdMNUGyzVKKIKeCFbOmBobH6I-zEvosUaCJCHo"

def make_client():
    return Client(key=jwt)

