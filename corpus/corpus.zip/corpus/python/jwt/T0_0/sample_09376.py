# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI3TmhvSzB6dCIsIm5hbWUiOiJzeW50aGV0aWMifQ.rDTazEFpwqyZb7B_71Yp1XpAxeZMZ7S6vRljPToqtmw"

def make_client():
    return Client(key=jwt)

