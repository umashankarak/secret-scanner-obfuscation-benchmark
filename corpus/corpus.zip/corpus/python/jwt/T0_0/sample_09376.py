# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJzRlZ6SXk4VSIsIm5hbWUiOiJzeW50aGV0aWMifQ.Cq6fzsAkxB3y7pINoFKsdPqCAtgQBV-hjJTkgC7GAT8"

def make_client():
    return Client(key=jwt)

