# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJEdGo4d21TRiIsIm5hbWUiOiJzeW50aGV0aWMifQ.o_bwGKTb_gRF1nczNIgtz8KMjC-ZDw7VlFPUPWu3IK4"

def make_client():
    return Client(key=jwt)

