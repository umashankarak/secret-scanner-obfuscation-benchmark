# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJUelRjaFdVNSIsIm5hbWUiOiJzeW50aGV0aWMifQ.ZU8aQ4iXH8ZnPkWejCFfHsPzqehDBJjvqfzW_Jidy40"

def make_client():
    return Client(key=jwt)

