# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJrT2lCbGV5UiIsIm5hbWUiOiJzeW50aGV0aWMifQ.ojr_9x_I2NssWz4dOWkTXm-R1oNfD2BcGBLZ4YrYf3k"

def make_client():
    return Client(key=jwt)

