# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ5bkI0STh5WCIsIm5hbWUiOiJzeW50aGV0aWMifQ.1zp2ZHHAuxG6yhmRfFcL9E5j50dtiJa8-IgFDYD_5s0"

def make_client():
    return Client(key=jwt)

