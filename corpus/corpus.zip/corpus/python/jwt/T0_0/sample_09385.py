# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJUMGx2VW00aiIsIm5hbWUiOiJzeW50aGV0aWMifQ.RFtKOsqQrtb9hxeyZxZMtDKVH6lVX3IqM75aOmSRW2s"

def make_client():
    return Client(key=jwt)

