# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJVVkJucWdoRCIsIm5hbWUiOiJzeW50aGV0aWMifQ.UyvKi1M4MV0zoWQPgTOUrfzvb-Kq_poWpq-WgnGdHSw"

def make_client():
    return Client(key=jwt)

