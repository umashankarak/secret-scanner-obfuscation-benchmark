# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI5Z1ZhVmo4QyIsIm5hbWUiOiJzeW50aGV0aWMifQ.fXmN22-mT" + "H" + "vfSQk75mR9xh2r" + "jUqCtqTl_Ac-IkFtqSU"

def make_client():
    return Client(key=jwt)

