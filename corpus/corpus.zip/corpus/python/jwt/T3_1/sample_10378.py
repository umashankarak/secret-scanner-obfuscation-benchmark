# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkRm" + "JsSTczUiIsIm5hbWUiOiJzeW50aGV0aWMifQ.giVfPF_1b" + "_6uJlEfD9T-fc" + "7_Q770IK0qDGEGGCNjXFA"

def make_client():
    return Client(key=jwt)

