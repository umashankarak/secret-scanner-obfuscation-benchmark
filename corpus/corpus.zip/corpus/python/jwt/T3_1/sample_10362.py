# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWI" + "iOiI4YjludnpVcSIsIm5hbWUiOiJzeW50aGV0aWMifQ.PSAJX7l2aekGqSQA" + "Ii_UXXU5AiRHQ_FLZ89lo" + "Nd65Ew"

def make_client():
    return Client(key=jwt)

