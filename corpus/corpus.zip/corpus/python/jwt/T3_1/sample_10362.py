# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJ" + "IUzI1NiIsInR5cCI" + "6IkpXVCJ9.eyJzdWIiOiI5MHJYUE52WCIsIm5hbWUiOiJzeW50" + "aGV0aWMifQ.SbNUKMbG1arSRtCBO6vQXZ995U9IRvyhGjUdQZ-XqXw"

def make_client():
    return Client(key=jwt)

