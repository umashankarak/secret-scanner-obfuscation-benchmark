# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1N" + "iIsInR5cCI6IkpXV" + "CJ9.eyJzdWIiOiJTa01lM1B6ZiIsIm5hbWUiOiJzeW50" + "aGV0aWMifQ.IVzYzPEPEA7d4XMDbSJc3C-4AVp4Y4PK6-IpfsFlTNQ"

def make_client():
    return Client(key=jwt)

