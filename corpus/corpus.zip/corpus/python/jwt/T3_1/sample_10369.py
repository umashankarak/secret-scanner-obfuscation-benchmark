# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkeEh0bGZsMyIsI" + "m5hbWUiOiJz" + "eW50aGV0aWMifQ.VwbDECZo" + "eMGO5op5oj2nIhu3CQepa5MrnNom0-IAoyE"

def make_client():
    return Client(key=jwt)

