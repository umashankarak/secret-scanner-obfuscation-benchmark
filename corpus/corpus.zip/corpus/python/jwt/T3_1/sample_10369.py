# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5" + "cCI6IkpXVCJ9.eyJzdWIiOiJzeGFP" + "ZElVUyIsIm5hbWUiOiJzeW50aG" + "V0aWMifQ.5wQdeXD5ybbYe0YbrUQpzX59SgccYYzc94aNJJ1bLFU"

def make_client():
    return Client(key=jwt)

