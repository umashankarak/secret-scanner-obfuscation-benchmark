# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6Ik" + "pXVCJ9.eyJzdWIiOiJlcWdXaU5" + "NcCIsIm5hbWUiOiJ" + "zeW50aGV0aWMifQ.-gtdsbIPMXyzrnInRcFHrYzd8Sg940hmM1Dww6zZOsQ"

def make_client():
    return Client(key=jwt)

