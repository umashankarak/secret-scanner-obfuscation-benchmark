# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJIbEtUWDlxSyIsIm5hbWUiOiJzeW50aGV0aWMifQ.YYhU8ZX2LVxhPrj" + "YUZrQjcWprLuEzJevgrON8vb" + "h" + "zww"

def make_client():
    return Client(key=jwt)

