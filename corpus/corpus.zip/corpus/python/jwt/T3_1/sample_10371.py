# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpX" + "VC" + "J9.eyJzd" + "WIiOiJWc3BJZnM5UyIsIm5hbWUiOiJzeW50aGV0aWMifQ.JvhWJSCm70bsIzqG6T0N7zPANDzD8WxcsoDNB8JQkyE"

def make_client():
    return Client(key=jwt)

