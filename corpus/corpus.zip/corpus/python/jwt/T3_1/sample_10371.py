# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciO" + "iJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJwNHhGblF0VCIsIm5h" + "bWUiOiJzeW50aGV0aWMifQ.P_9EPe0xjH3HemCn2F8zcVWgkEg9rImyn-ZWXSxK" + "M00"

def make_client():
    return Client(key=jwt)

