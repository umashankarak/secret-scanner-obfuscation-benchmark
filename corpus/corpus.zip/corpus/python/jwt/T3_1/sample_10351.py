# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiO" + "iJURVJYdWh3QyIsIm5hbWUiOiJze" + "W50aGV0aWMifQ.p9jZTf0qlS4Ek5Aty2yuU8BCAeRu" + "twop_ILhduii7Qw"

def make_client():
    return Client(key=jwt)

