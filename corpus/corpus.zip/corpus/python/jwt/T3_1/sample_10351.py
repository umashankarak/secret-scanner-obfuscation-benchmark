# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxRzhw" + "VGcyMSIs" + "Im5hbWUiOiJzeW50aGV0aWMifQ.q16YYBsTvkk9ixRK9bMm-" + "FYlIKbvRuwjOobpPQ3vM8A"

def make_client():
    return Client(key=jwt)

