# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI5UlB6TH" + "pzVyIsIm5hbWU" + "iOiJzeW50aGV0aWMi" + "fQ.C5TZkqr4qD45eDsYdkmyc4XGcsW2lLYIvar73Ttobgc"

def make_client():
    return Client(key=jwt)

