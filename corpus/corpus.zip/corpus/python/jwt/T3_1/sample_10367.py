# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJz" + "dWIiOiJEZ3ZqeEtOWSIsIm5hbWUiOiJzeW50aGV0aWMifQ.cYnyoowOOZWYdCeAPReg6sdohqde" + "XJw6bGCzqrIOhh" + "w"

def make_client():
    return Client(key=jwt)

