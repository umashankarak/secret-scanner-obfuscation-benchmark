# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJLOUNnZkg1cCI" + "sIm5hbWUiOiJzeW50aGV0aWM" + "ifQ.1R3u" + "f73RbtfY0ud63O66V_qsxgVwKZ9BP2qi5UKXXUE"

def make_client():
    return Client(key=jwt)

