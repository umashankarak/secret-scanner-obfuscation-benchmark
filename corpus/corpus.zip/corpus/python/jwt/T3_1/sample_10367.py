# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOi" + "IyS1Vvanl0dyIsIm5hbWUiOiJzeW50" + "aGV0a" + "WMifQ.hMhB-2Vd44cN9ZmLzi2eSSbpuyiCE8-zd_KwN2AXpqk"

def make_client():
    return Client(key=jwt)

