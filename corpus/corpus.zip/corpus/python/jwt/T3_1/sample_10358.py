# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJUcUVZNGhuRCIs" + "Im5hbWUiOiJzeW50aGV0aWMifQ.eNc3NW7q" + "VS23GngU5oDwq0t9" + "lam9Jwx8BiyL7t6sgiU"

def make_client():
    return Client(key=jwt)

