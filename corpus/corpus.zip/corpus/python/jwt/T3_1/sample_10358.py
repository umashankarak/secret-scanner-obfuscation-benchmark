# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJqWHR5MmwyVSIsIm5hbWUiOiJzeW50aGV0aWMifQ.QE9c66N" + "P6w8vaMhZ_HUS2" + "qNJdR29mnXofYSX" + "56k5U4o"

def make_client():
    return Client(key=jwt)

