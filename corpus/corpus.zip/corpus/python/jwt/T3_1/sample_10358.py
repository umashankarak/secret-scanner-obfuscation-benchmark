# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI" + "1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJZUkx2Um1MayIsIm5" + "hbWUiOiJzeW50aGV0aWMifQ.fcJ0wT68DBV6JT7Ni_TiSgmt0CB" + "zRgVB3rsFoYJS6Dg"

def make_client():
    return Client(key=jwt)

