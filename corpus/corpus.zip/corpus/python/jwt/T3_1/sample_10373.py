# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJz" + "dWIiOiJITExPS3MwcCI" + "sIm5hbWUiOiJzeW50aGV0" + "aWMifQ.yCodWfRXbIr50-lQaiBAgy4AVYpGY35qCTLWTQmsjtQ"

def make_client():
    return Client(key=jwt)

