# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGci" + "OiJIUz" + "I1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkZENPcUM0byIsIm5hbWUiOiJzeW50aGV" + "0aWMifQ.K_O1ZYXUAc7Bf0XwBYaDxakHQBTZTIZd2q4LojIkKOU"

def make_client():
    return Client(key=jwt)

