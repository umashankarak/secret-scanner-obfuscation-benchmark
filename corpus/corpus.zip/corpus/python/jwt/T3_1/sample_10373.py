# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIs" + "InR5cCI6IkpXVCJ9.eyJzdWIiOiI3OXFIc3ExbSIsIm5hbWUiOiJ" + "zeW50aGV0aWMifQ.xAs_Yzuh6SGeYUxJpDt622t" + "zAY8APWRIwGHs_MSDIDc"

def make_client():
    return Client(key=jwt)

