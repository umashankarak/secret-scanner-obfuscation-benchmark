# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJmS3VaUUgwVSIsIm5hbWUiOiJzeW50aGV0aWMifQ.RIEMzCz4bK_J" + "jzofmAN5yWJ_IyMVUzp" + "d2u" + "h5s-HHgdw"

def make_client():
    return Client(key=jwt)

