# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsIn" + "R5cCI6IkpXVCJ9.eyJzdWIiOiJUTWtyeE9USyIsIm5hbWUiOiJzeW5" + "0aGV0aWMifQ.3Y3T6GpRnBxPW2C7kYQLZaJb0awcG" + "MLG2UOvJh7wPFg"

def make_client():
    return Client(key=jwt)

