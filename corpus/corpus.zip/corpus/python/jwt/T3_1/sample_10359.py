# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJOTERIYk5IUCI" + "sIm5hbWUiOiJzeW50aGV0aWMifQ.tqPJZQD9bm" + "Y8" + "Tau6hwTxZ2rmzgWpC7atjhklo3Y4GIQ"

def make_client():
    return Client(key=jwt)

