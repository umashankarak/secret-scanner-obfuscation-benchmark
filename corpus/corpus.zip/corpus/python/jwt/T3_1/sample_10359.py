# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhb" + "GciOiJIU" + "zI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJSanVoZDFGWiIsIm5hbWUiOiJzeW50aGV0aWMifQ._0O-9CCtKgxhBhgjY1xQhzKO2G1gruUcGlNz" + "A1L10k8"

def make_client():
    return Client(key=jwt)

