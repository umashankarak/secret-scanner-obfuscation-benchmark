# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhb" + "GciOiJIUzI1NiIsInR5c" + "CI6IkpXVCJ9.ey" + "JzdWIiOiJnWXhGUXZlRSIsIm5hbWUiOiJzeW50aGV0aWMifQ.6B18ZPQBfpUQ7Y-jvA6fHj9fmIMiX__LB9q9BwB7TIg"

def make_client():
    return Client(key=jwt)

