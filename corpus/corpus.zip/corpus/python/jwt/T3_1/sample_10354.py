# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhb" + "GciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJJcnlGQWNtMSIsIm5hbWUiOiJzeW50a" + "GV0aWMifQ.TQmsjtTGluZQ4yimO8Wwn-OpnJyQpu67ffgVamSXjQ" + "k"

def make_client():
    return Client(key=jwt)

