# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "ey" + "JhbGciOiJIUzI1NiIsInR5cCI6IkpX" + "VCJ9.eyJzdWIiOiJYR1VMR1dnYiIsIm5hbWUiOiJzeW50aGV0aWMifQ.pVBq7fx1" + "eonHlPscZ4QtN_T970YRT6B9rrMsS-gI4-I"

def make_client():
    return Client(key=jwt)

