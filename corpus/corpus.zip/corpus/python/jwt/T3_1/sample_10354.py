# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1Ni" + "IsInR5cCI6IkpXVCJ9.eyJzdWIiOiJWRGlSQkd6" + "cyIsIm5hbWUiOiJzeW50aGV0aWMifQ.Vucb" + "H0OHxq0ElsRcqes0evK1s4oDnrLr3aH6BxUSKpg"

def make_client():
    return Client(key=jwt)

