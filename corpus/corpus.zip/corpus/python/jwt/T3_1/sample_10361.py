# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJyam5ac3Z3QiIsIm5hbWUi" + "OiJzeW50aGV0aWMifQ.y-4UxhdukSM4-cT1_h" + "7u5V1-sSnVC-J" + "FZVclKO7c-JE"

def make_client():
    return Client(key=jwt)

