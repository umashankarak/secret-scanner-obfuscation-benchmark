# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJBQU5udDVSbyIsIm5hbWUi" + "OiJzeW50aGV0aWMifQ.EvBjDixEz_e_vxd6MH3Exu" + "NF6WVQyn-Q2Yg" + "06ZG7bak"

def make_client():
    return Client(key=jwt)

