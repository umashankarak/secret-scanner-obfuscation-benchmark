# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJzVmh4ZmRONyIsIm5hbWUiOiJzeW50aGV0aWM" + "ifQ.3MuqRVOLX" + "I" + "rNtvU15JwX5U2YKCwEMvURH-O4FE6emIM"

def make_client():
    return Client(key=jwt)

