# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ" + "zdWIiOiJ6MGZKbW1ERiIsIm5hbWUiOiJzeW5" + "0aGV0aWMifQ.UzVQAi_L5xY4tkB5yuEdNHV41zc1bupVLbcaeB" + "TmgPA"

def make_client():
    return Client(key=jwt)

