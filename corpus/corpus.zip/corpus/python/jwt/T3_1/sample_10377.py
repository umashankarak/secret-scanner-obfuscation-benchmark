# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciO" + "iJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJB" + "ampZWXdLZiIsIm5hbWUiOi" + "JzeW50aGV0aWMifQ.JeA0nwrk_lvM1jR3nipIS6NZOe9mXiQcidVpp0N-hDw"

def make_client():
    return Client(key=jwt)

