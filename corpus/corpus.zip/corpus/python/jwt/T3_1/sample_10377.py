# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ" + "9.eyJzdWIiOiJubEhMaGtBaCIsIm5hbWUiOiJzeW50aGV0aWMifQ.7rUlb-jWKYlOS3qfhQ" + "QSHYUT0g64e3-eVs_f" + "KF_tR3g"

def make_client():
    return Client(key=jwt)

