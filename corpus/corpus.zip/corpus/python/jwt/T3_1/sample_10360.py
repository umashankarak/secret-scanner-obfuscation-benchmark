# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJSRFNkd2xTaSIsIm5hbWUiOiJzeW50aGV0aWMifQ.YY" + "HhVEx9igEje7DiEZ832ujMIehiz" + "GmUpyt-JN" + "kQFVU"

def make_client():
    return Client(key=jwt)

