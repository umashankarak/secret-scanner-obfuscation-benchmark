# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1Ni" + "IsInR5cCI6" + "IkpXVCJ9.eyJzdWIiOiJzaXQ5Y29MbCIsIm5hbWUiOiJzeW50aGV0aWMifQ.Y" + "GGAaIJEUiOb0x8osWIqfBa9NWRK170X7obQzYuYGVM"

def make_client():
    return Client(key=jwt)

