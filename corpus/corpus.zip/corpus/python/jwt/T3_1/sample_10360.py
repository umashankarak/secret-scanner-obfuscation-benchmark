# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJqRk4zYmZrcSIsIm5hbW" + "UiOiJzeW50aGV0aWMifQ.w4JSCxMWwoU5vABausQ" + "dxmyUY7_J" + "XXItmVeyLEDrc9c"

def make_client():
    return Client(key=jwt)

