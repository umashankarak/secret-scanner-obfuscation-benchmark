# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJ" + "hbGciOiJIUzI1Ni" + "IsInR5cCI6IkpXVCJ9.eyJzdWI" + "iOiJ4Z3d6Z2ZBcyIsIm5hbWUiOiJzeW50aGV0aWMifQ.gjkPY2q2S1knD19hjMiDc3SDGyMb8axCcFE3hKD6f50"

def make_client():
    return Client(key=jwt)

