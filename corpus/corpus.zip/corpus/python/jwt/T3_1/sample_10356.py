# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.ey" + "JzdWIiOiJVa1dseVp5ZCIsIm5hbWUiOiJze" + "W50aGV0aWMifQ.m8tpKsx3x36M4pIwgqhmpIL00ObrvTkKzYfCw" + "rfh2y0"

def make_client():
    return Client(key=jwt)

