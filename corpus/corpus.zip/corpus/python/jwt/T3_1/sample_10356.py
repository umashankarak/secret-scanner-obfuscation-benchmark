# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIi" + "OiJFWXlGaWlmdSIsIm5hbWUiOiJzeW50aGV0aWMifQ." + "Ol3a6Hmz4ceB3IZ5Y-aL0dd2" + "Vx_E_m2U_bdGiMSAqpY"

def make_client():
    return Client(key=jwt)

