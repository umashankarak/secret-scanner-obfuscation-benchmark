# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI1QkFCZU9OSyIsIm5hbWUiOiJz" + "eW50aGV" + "0aWMifQ.YjguJPWVbzBV3" + "sJs3MbVNxldTvo_c8IvNQVxARO4eQc"

def make_client():
    return Client(key=jwt)

