# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXV" + "CJ9.eyJzdWIiOiJHVVlBeVJnSyIsIm5hbWUiOiJzeW50aGV0aWMifQ.M5RQKthUTXQ8T85trHv" + "hbY5UCa" + "kBlOegOAywsYD5RJ0"

def make_client():
    return Client(key=jwt)

