# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhU04" + "0RmlSZiIsIm5hbWUiOiJzeW50aGV0aWMifQ.4sQwOETAubEioEQ_kA1l3b2SD1" + "VtH0-D" + "I6ffOWVX_eY"

def make_client():
    return Client(key=jwt)

