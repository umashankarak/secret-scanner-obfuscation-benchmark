# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ2aFhCTFRySSIsIm5hbWUiOiJzeW50" + "aGV0aWMifQ." + "xICqlm_zV4MstCqevmpajluAMljrnm8kZ5x" + "rp8TmbWk"

def make_client():
    return Client(key=jwt)

