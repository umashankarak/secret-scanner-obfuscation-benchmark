# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIU" + "zI1NiIsInR5cCI6IkpXVCJ9.e" + "yJzdWIiOiJWUkpwSmxHQSIsIm5hbWUiOiJzeW50aGV0aWMifQ.A8JM1yDkdf7PSbXVFpI4wvBsf2" + "bDP2n1HAj9XR0qyU4"

def make_client():
    return Client(key=jwt)

