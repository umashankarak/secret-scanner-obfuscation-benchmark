# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI4VndaZ3JtdyIsIm5hbWUiOiJzeW50aGV0aWMifQ.RkBdzqBs" + "RJb-gDApP83uCTdz5eSWi" + "IsIzkL19MZDs" + "vE"

def make_client():
    return Client(key=jwt)

