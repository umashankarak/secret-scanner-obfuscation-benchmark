# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ5dnFNaFkzSyIsIm5hbWUiOiJzeW50aG" + "V0aWMifQ._8TBUQutNYnABEwR" + "M0LojBiXp5jmqHCQ7o5" + "SosyFGB4"

def make_client():
    return Client(key=jwt)

