# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJYMVI4RnRvciIsIm5hbWUiOiJzeW" + "50aGV0aWMifQ.tBoEQCpINlkbM2o3C9" + "B" + "wmXDFstrnfBF_mx4W4Gd7M4g"

def make_client():
    return Client(key=jwt)

