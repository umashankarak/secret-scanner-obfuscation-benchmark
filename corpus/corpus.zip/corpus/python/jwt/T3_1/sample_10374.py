# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIs" + "InR5cCI6IkpXVCJ9.eyJzdWIiOiJkRzg2bUtVbyIs" + "Im5hbWU" + "iOiJzeW50aGV0aWMifQ.g1z__Uc4_vV9NASB0Nc_MMJ5PucVGzArUOZVICj76-Q"

def make_client():
    return Client(key=jwt)

