# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJz" + "dWIiOiJYU040UU" + "5OSyIsIm5hbWUiOiJzeW50aGV0aWMifQ.pu67ffgVamSXjQmBTeacBBhA0kcfFYs" + "tZJQe1dqzsHE"

def make_client():
    return Client(key=jwt)

