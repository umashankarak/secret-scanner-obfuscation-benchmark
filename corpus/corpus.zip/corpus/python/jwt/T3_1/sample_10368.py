# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "e" + "yJhbGciOiJIUzI1NiIsInR5" + "cCI6IkpXV" + "CJ9.eyJzdWIiOiJoYnoyRnFyZyIsIm5hbWUiOiJzeW50aGV0aWMifQ.Feb08_nFgdQklerZWU-gRZZUCoH0m6vDmy-i3Sh4PH4"

def make_client():
    return Client(key=jwt)

