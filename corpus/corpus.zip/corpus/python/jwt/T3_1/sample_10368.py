# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiI" + "sInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1SHdz" + "cUk1YyI" + "sIm5hbWUiOiJzeW50aGV0aWMifQ.jDoWwsDF-a3MMnnuIVBWdj5Ba9JKPSWu9qGFbtnWe-g"

def make_client():
    return Client(key=jwt)

