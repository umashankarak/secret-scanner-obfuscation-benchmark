# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJh" + "bGciOiJI" + "UzI1N" + "iIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJzYmFEUWFMMyIsIm5hbWUiOiJzeW50aGV0aWMifQ.mta_5s2eRQka-u_sPlE7f-6UPsYFDcsAg3I02GCC9gU"

def make_client():
    return Client(key=jwt)

