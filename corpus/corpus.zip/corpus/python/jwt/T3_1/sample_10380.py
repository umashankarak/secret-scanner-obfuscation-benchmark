# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJDbE12U2xxNiIsIm5hbWUiO" + "iJzeW50aGV0aWMifQ.c9eFo3P4oGq6Qm" + "tqnDZO5a78OhLwYw4sRM_3v7" + "8XejA"

def make_client():
    return Client(key=jwt)

