# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdW" + "IiOiJ0VzN0MURLMiIsIm" + "5hbWUiOiJzeW50aGV0aWMifQ." + "JRTyFLT0Fm8Ll7m23BjS_cv4ERV3gbFRny8TTUYkHSo"

def make_client():
    return Client(key=jwt)

