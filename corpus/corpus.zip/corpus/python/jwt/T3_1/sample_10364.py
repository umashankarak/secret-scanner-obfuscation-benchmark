# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIU" + "zI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJnMkp5a0lWViIsIm5hbWUiOiJzeW50aGV0aWMifQ.WCo3gs9ZUrdRb_3nqmEtLr5vCDE" + "EUMv-AqI9a" + "hl3zpE"

def make_client():
    return Client(key=jwt)

