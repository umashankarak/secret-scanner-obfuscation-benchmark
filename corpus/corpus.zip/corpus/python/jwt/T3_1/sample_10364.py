# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJI" + "UzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJtUmp" + "GdWtaOSIsIm5hbWUiOiJzeW50aGV0aWMifQ.DtK1gZC4qENagPB-7BMlqUoXrjWVCO9Jr9n4Dq9u" + "U8k"

def make_client():
    return Client(key=jwt)

