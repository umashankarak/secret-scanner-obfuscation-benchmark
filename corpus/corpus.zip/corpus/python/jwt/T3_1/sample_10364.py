# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhb" + "GciOiJIU" + "zI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJueHNsSVplRyIsIm5hbWUiOiJzeW50aGV0aWMifQ.8-K48ALzDR62DO-I" + "XwKh6NkcTAn-raqiLH3Q36VbyWg"

def make_client():
    return Client(key=jwt)

