# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJz" + "dWIiOiJ0RUJuW" + "DB3MSIsIm5hbWUiOiJzeW50aGV0aWM" + "ifQ.F25WTlm3DLStQx_FWfrLmtChdYmeEumZQOr-LcHPuJw"

def make_client():
    return Client(key=jwt)

