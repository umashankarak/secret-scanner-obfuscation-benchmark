# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJlWUZzZVhHQyI" + "sIm5hbW" + "UiOiJzeW50aGV0" + "aWMifQ.4u00tl5gbFRFlsWhU2nQTqa5KukMUr7MRDVs_lKZPxk"

def make_client():
    return Client(key=jwt)

