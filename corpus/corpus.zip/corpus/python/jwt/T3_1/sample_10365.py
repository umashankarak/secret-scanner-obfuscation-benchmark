# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiO" + "i" + "IwSlJFZHRvUyIsIm5hbWUiOiJzeW50aGV0aWMifQ.h24r6z" + "axlIsN8IL9-9KX0AghJI7CLOvshVVW1OhNVRY"

def make_client():
    return Client(key=jwt)

