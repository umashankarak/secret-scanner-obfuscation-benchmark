# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI" + "6IkpXVCJ9.eyJzdWIiOiJWeWN" + "BeWh3YSIsIm5hbWUiOiJzeW50aGV0aWMifQ.3lZsXXp5HeBQd9JvElwzP" + "LUw9vun4K1UGUShufBlvoI"

def make_client():
    return Client(key=jwt)

