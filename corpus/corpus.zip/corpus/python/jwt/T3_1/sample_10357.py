# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR" + "5cCI6IkpXVCJ9.eyJzdWIiOiJ" + "Ua05WQXdK" + "dyIsIm5hbWUiOiJzeW50aGV0aWMifQ.gDJY655vJGeca6fE5m1phkxXnHpm0xWNMTJ1f1M1UAI"

def make_client():
    return Client(key=jwt)

