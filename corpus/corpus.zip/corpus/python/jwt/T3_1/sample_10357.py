# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhb" + "GciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJzR2ozQWZ2ayIsIm5hbWUiOiJzeW50aGV0aWMifQ.KrRm9B9" + "ILGUlH5" + "scvC3qzWrDdrzbjpqi3Jn6QWJ1rGY"

def make_client():
    return Client(key=jwt)

