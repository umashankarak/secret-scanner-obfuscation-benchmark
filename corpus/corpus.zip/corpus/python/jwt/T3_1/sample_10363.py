# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGc" + "iOiJIUzI1NiIsInR5cC" + "I6IkpXVCJ9.eyJzdWIiOiJ6Y2I0ZDU1ViIsIm5hbWUiOiJzeW5" + "0aGV0aWMifQ.b3t4AMpFzPLINVFB8uEG-ZeO6t56ZCn28xTk_WdDB84"

def make_client():
    return Client(key=jwt)

