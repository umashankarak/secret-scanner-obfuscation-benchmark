# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ3Wllwb3V6UyIsIm5hbWUiOiJzeW50a" + "GV0aWMifQ" + ".paLk1hW7tBLS5nwwLVarBmaz5H10CniqgdZ" + "XhcHfo7M"

def make_client():
    return Client(key=jwt)

