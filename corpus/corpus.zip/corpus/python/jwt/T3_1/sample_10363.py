# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "e" + "yJhbGciOiJIUzI1NiIsI" + "nR5cCI6IkpXVCJ9.eyJzdWIiOiI2bXpaM0lZMiIsIm5hbWUiOiJzeW50aGV0aWMifQ.3e2QeqWtFEwuZmEbcbAyKZE-dYhLcEQvvqhSBGh" + "5J8I"

def make_client():
    return Client(key=jwt)

