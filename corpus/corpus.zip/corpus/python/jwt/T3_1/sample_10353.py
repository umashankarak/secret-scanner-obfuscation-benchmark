# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "e" + "yJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOi" + "JNaGY0ekVtSSIsIm5hbWUiOiJzeW50aGV0aWMif" + "Q.jbFppq5qSoWUl6OTSfvRPMgqHVn0V2yK-dPpUGogQIM"

def make_client():
    return Client(key=jwt)

