# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6" + "IkpXVCJ9.eyJzdWIiOiJkMGY4SW9NOCIsIm5hbWUiOiJzeW" + "50aGV0aWMifQ.7djX5gMf" + "DHCUx2LOWUYm_BN6L0yoN-754vm_nG1O6vQ"

def make_client():
    return Client(key=jwt)

