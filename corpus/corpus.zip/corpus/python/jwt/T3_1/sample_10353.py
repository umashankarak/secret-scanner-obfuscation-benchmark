# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJXbFp1WjEyWCIsIm5hbWUiOiJzeW50aGV0aWMifQ.9dvqAez31P4l" + "m0d-eGI7" + "IZ3X6maHumZo59Kx" + "fn_vu9w"

def make_client():
    return Client(key=jwt)

