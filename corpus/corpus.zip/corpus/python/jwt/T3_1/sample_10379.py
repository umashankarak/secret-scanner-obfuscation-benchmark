# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "e" + "yJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJYTnhYUGtBRCIsIm5hbWU" + "iOiJzeW50aGV0aWMifQ.Agy5DIfmiqz55GxZQpgt" + "ndDwJbMZxZE2okyo7aOODTw"

def make_client():
    return Client(key=jwt)

