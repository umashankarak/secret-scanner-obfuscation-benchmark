# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJSNWhndUNhdSIsIm5hbWUiOiJzeW50aGV0aWMifQ.9dJPDH" + "uI6KIE" + "Jn2f3gQXK" + "EDDglILExbChTm8AFq6xB0"

def make_client():
    return Client(key=jwt)

