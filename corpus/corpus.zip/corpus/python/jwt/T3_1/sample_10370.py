# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIs" + "InR5cCI6" + "IkpXVCJ9.eyJzdWIiOiJJWE1FOEVQdSIsIm5hbWUiOiJzeW50aGV0aWMifQ.68sAZhlnp" + "ZEurPkpuqqifguw3zMe1IPxPLYY2f7Uq14"

def make_client():
    return Client(key=jwt)

