# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6I" + "kpXVCJ9.eyJzdWIiOiJ2aVZoZTdTcCIsIm5hbWUiOi" + "Jz" + "eW50aGV0aWMifQ.EKTdcIxm-LfySQuWbg9TeBZthpMF8knEtmFKDNQYI58"

def make_client():
    return Client(key=jwt)

