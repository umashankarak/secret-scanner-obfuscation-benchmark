# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhbGciOiJIUzI1NiIs" + "InR5cCI6IkpXVCJ9.eyJzdWIiOiJCUmVrYTd2OCIsIm5hbWUiOiJzeW50aGV0aWMifQ.ZSa07iU_Ix80BngoSQWIkRjnoVdJx0KIB9G2AMD8" + "nD" + "M"

def make_client():
    return Client(key=jwt)

