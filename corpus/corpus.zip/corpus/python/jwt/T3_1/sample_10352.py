# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.ey" + "JzdWIiOiJ" + "URFdoVkhYNyIsIm5hb" + "WUiOiJzeW50aGV0aWMifQ.6CEFJF0gbAqolAJy-K0FxMUHEdBklRYjBZaLGO6WEgc"

def make_client():
    return Client(key=jwt)

