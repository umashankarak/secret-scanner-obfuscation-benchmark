# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1Ni" + "IsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ4U0daYld1SyIsIm5hbWUiOiJzeW50aGV0aWMifQ.ISnRH-whxNav831NOUa0GgRAKkg2WRszajcL0" + "HCZ" + "cMU"

def make_client():
    return Client(key=jwt)

