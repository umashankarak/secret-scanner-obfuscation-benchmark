# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJh" + "bGciOiJIUzI1NiIsInR5cCI6IkpX" + "VCJ9.eyJzdWIiOiJncTByaGZJbC" + "IsIm5hbWUiOiJzeW50aGV0aWMifQ.ZJQe1dqzsHF2xYU2KBaSUPnNqYfTukSBDMws-GyvyY8"

def make_client():
    return Client(key=jwt)

