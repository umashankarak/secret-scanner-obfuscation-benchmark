# synthetic benchmark sample -- generated value, non-functional
import os

jwt = "eyJhb" + "GciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJx" + "ZEFzRmtHYyIsIm5hbWUiOiJzeW50aGV0aWMifQ.LcjWz91mK1Dscrv7JnmU68A7b7uHU" + "-VDMpLv_Xyay6w"

def make_client():
    return Client(key=jwt)

