# synthetic benchmark sample -- DO NOT use with real secrets
import os

jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJz" + "dWIiOiJCTFJYbmpyMi" + "IsIm5hbWUiOiJzeW" + "50aGV0aWMifQ.jV3ydOfseaKLQfwyohipHEBfMcxbJ4TG8udzsVW54Ww"

def make_client():
    return Client(key=jwt)

